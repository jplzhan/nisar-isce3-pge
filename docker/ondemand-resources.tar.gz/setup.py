from setuptools import find_packages, setup

setup(
    name="nisar-products",
    version="0.1.0",
    description=(
        "Object model for NISAR products: parse granule names, derive metadata "
        "from static references, resolve/download from S3, and trace product lineage."
    ),
    long_description=open("src/nisar_products/README.md").read(),
    long_description_content_type="text/markdown",
    python_requires=">=3.9",
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    install_requires=[
        "boto3",
        "geopandas",
        "numpy",
        "pyyaml",
        "shapely",
    ],
    extras_require={
        "earthaccess": ["earthaccess"],
        "test": ["pytest", "pyyaml"],
    },
)
