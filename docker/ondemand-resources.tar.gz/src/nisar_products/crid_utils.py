"""CRID (Composite Release ID) comparison and utility functions."""
from __future__ import annotations

import logging
from typing import Optional

logger = logging.getLogger(__name__)


def compare_crids(crid1: str, crid2: str) -> int:
    """Compare two CRIDs, ignoring the first letter.

    CRIDs are compared numerically after discarding the first character
    (which is typically a letter like 'P', 'X', etc.).

    Args:
        crid1: First CRID (e.g., "P05023")
        crid2: Second CRID (e.g., "X05012")

    Returns:
        int: -1 if crid1 < crid2, 0 if equal, 1 if crid1 > crid2

    Raises:
        ValueError: If CRIDs cannot be parsed as integers after removing first char
    """
    if not crid1 or not crid2:
        raise ValueError("CRIDs cannot be empty")

    # Remove first character and convert to int
    try:
        num1 = int(crid1[1:])
        num2 = int(crid2[1:])
    except (ValueError, IndexError) as e:
        raise ValueError(
            f"Invalid CRID format: {crid1!r} or {crid2!r}. "
            "Expected format: letter followed by digits"
        ) from e

    if num1 < num2:
        return -1
    elif num1 > num2:
        return 1
    else:
        return 0


def find_latest_crid(crids: list[str]) -> Optional[str]:
    """Find the latest (highest numeric value) CRID from a list.

    Args:
        crids: List of CRID strings

    Returns:
        str | None: The latest CRID, or None if the list is empty or contains only invalid CRIDs

    Example:
        >>> find_latest_crid(["P05020", "X05012", "P05023"])
        "P05023"
    """
    if not crids:
        return None

    valid_crids = []

    for crid in crids:
        try:
            # Validate that this CRID can be parsed
            if len(crid) > 1:
                int(crid[1:])
                valid_crids.append(crid)
        except (ValueError, IndexError):
            logger.warning(f"Skipping invalid CRID: {crid!r}")
            continue

    if not valid_crids:
        return None

    # Sort using compare_crids logic
    latest = max(valid_crids, key=lambda c: int(c[1:]))
    return latest


def extract_crid_from_granule(granule_name: str) -> Optional[str]:
    """Extract CRID from a NISAR granule name.

    Args:
        granule_name: NISAR product granule name

    Returns:
        str | None: Extracted CRID, or None if not found

    Example:
        >>> extract_crid_from_granule("NISAR_L1_PR_RSLC_024_025_D_086_4005_DHDH_A_20260627T224736_20260627T224743_P05023_N_P_J_001")
        "P05023"
    """
    tokens = granule_name.split('_')

    # For single products (18 tokens), CRID is at index 13
    # For RRSD (14 tokens), CRID is at index 10
    # For INSAR (20 tokens), CRID is at index 15

    if len(tokens) == 18:
        # Single product
        return tokens[13] if len(tokens) > 13 else None
    elif len(tokens) == 14:
        # RRSD
        return tokens[10] if len(tokens) > 10 else None
    elif len(tokens) == 20:
        # INSAR
        return tokens[15] if len(tokens) > 15 else None

    logger.warning(
        f"Could not extract CRID from granule: unexpected token count "
        f"({len(tokens)} tokens): {granule_name}"
    )
    return None
