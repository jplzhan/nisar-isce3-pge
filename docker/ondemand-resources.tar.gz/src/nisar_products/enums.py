"""Enumerations describing NISAR product naming components and S3 buckets."""
from __future__ import annotations

from enum import Enum


class RadarBand(Enum):
    """Radar band. L is the operational default; S is future-proofing."""
    L = "L"
    S = "S"


class ProcessingType(Enum):
    """Processing/urgency type token (positions the ``PR``/``UR``/``OD`` field)."""
    PR = "PR"
    UR = "UR"
    OD = "OD"


class ProductAccuracy(Enum):
    """Product accuracy, ordered from more precise (top) to less precise (bottom)."""
    P = "P"  # Precise
    M = "M"  # Medium
    N = "N"  # Near Real-Time
    F = "F"  # Forecast


class Polarization(Enum):
    SH = "SH"
    SV = "SV"
    DH = "DH"
    DV = "DV"
    CL = "CL"
    CR = "CR"
    QP = "QP"
    NA = "NA"


class FrequencyA(Enum):
    F00 = "00"
    F05 = "05"
    F20 = "20"
    F40 = "40"
    F77 = "77"


class FrequencyB(Enum):
    F00 = "00"
    F05 = "05"


class NISARProductType(Enum):
    """NISAR product types carrying integer level and directory-string level tag.

    Members: ``(level_int, level_tag, code)``.
    - ``level_int``: integer processing level (0-3), monotonically increasing along a lineage.
    - ``level_tag``: string used in S3 directory paths (e.g. ``L0B``, ``L1``, ``L2``, ``L3``).
    - ``code``: the 4-char product type token in a granule name.
    """
    # L0 products
    RRST = (0, "L0A", "RRST")
    CRSD = (0, "L0B", "CRSD")
    RRSD = (0, "L0B", "RRSD")
    HST_DRT = (0, "L0B", "HST_DRT")

    # L1 products
    RSLC = (1, "L1", "RSLC")
    RIFG = (1, "L1", "RIFG")
    ROFF = (1, "L1", "ROFF")
    RUNW = (1, "L1", "RUNW")

    # L2 products
    GSLC = (2, "L2", "GSLC")
    GCOV = (2, "L2", "GCOV")
    GUNW = (2, "L2", "GUNW")
    GOFF = (2, "L2", "GOFF")

    # L3 products
    SME2 = (3, "L3", "SME2")

    def __init__(self, level: int, level_tag: str, code: str):
        self.level = level
        self.level_tag = level_tag
        self.code = code

    @classmethod
    def from_code(cls, code: str) -> "NISARProductType":
        for member in cls:
            if member.code == code:
                return member
        raise ValueError(f"Unknown NISAR product type code: {code!r}")

    def get_doi(self) -> "str | None":
        """Return the product DOI, or None for INSAR products and L0 products.

        Returns:
            str | None: The DOI string for this product type, or None if not applicable.
        """
        DOI_MAP = {
            NISARProductType.RSLC: "10.5067/NIL1RSLC-B1",
            NISARProductType.GCOV: "10.5067/NIL2GCOV-B1",
            NISARProductType.GSLC: "10.5067/NIL2GSLC-B1",
            NISARProductType.SME2: "10.5067/NIL3SME2-B1",
            # INSAR products (GUNW/RIFG/ROFF/GOFF/RUNW) return None per requirements
            # L0 products return None (no DOI)
        }
        return DOI_MAP.get(self)


# INSAR family: pairwise products built from two RSLCs (2 cycles).
INSAR_PRODUCT_TYPES = frozenset(
    {NISARProductType.GUNW, NISARProductType.RUNW, NISARProductType.ROFF,
     NISARProductType.RIFG, NISARProductType.GOFF}
)


class BucketType(Enum):
    JPL = "jpl"
    DAAC = "daac"


class S3Bucket(Enum):
    """Known NISAR S3 buckets and their path/credential configuration.

    Members: ``(bucket_name, bucket_type, path_format)``.
    ``path_format`` is the product-directory template. ``{level}`` maps to the
    ``level_tag`` and ``{product_type}`` maps to the ``code``. The ``ORIGINAL``
    format embeds a ``YYYY/MM/DD`` date path that must be filled in separately.
    """
    DAAC_EA = ("sds-n-cumulus-prod-nisar-products-ea", BucketType.DAAC,
               "EA_{level}_L_{product_type}/")
    DAAC_PRODUCTS_PROVISIONAL = ("sds-n-cumulus-prod-nisar-products", BucketType.DAAC,
                                 "NISAR_{level}_{product_type}_PROVISIONAL_V1/")
    DAAC_PRODUCTS = ("sds-n-cumulus-prod-nisar-products", BucketType.DAAC,
                     "NISAR_{level}_{product_type}_BETA_V1/")
    OPS_FWD = ("nisar-ops-rs-fwd", BucketType.JPL,
               "products/{level}_L_{product_type}/{date_path}/")
    OPS_POP1 = ("nisar-ops-rs-pop1", BucketType.JPL,
                "products/{level}_L_{product_type}/{date_path}/")
    OPS_POP2 = ("nisar-ops-rs-pop2", BucketType.JPL,
                "products/{level}_L_{product_type}/{date_path}/")
    DAAC_PRIVATE = ("sds-n-cumulus-prod-nisar-jpl-private-data", BucketType.DAAC,
                    "NISAR_{level}_{product_type}_BETA_V1/")
    DAAC_BROWSE = ("sds-n-cumulus-prod-nisar-browse", BucketType.DAAC,
                   "NISAR_{level}_{product_type}_BETA_V1/")

    def __init__(self, bucket_name: str, bucket_type: BucketType, path_format: str):
        self.bucket_name = bucket_name
        self.bucket_type = bucket_type
        self.path_format = path_format

    @property
    def uses_date_path(self) -> bool:
        """True if the path format needs a ``{date_path}`` (YYYY/MM/DD) segment."""
        return "{date_path}" in self.path_format

    @classmethod
    def jpl_buckets(cls) -> "list[S3Bucket]":
        return [b for b in cls if b.bucket_type is BucketType.JPL]

    @classmethod
    def daac_buckets(cls) -> "list[S3Bucket]":
        return [b for b in cls if b.bucket_type is BucketType.DAAC]

    def get_metadata_companion_bucket(self) -> "S3Bucket | None":
        """Return the companion bucket for .met.json files, if one exists.

        Some DAAC buckets store .h5 product files in one bucket and their
        corresponding .met.json metadata files in a companion bucket.

        Returns:
            The companion S3Bucket enum member, or None if this bucket has
            no companion.
        """
        # DAAC_PRODUCTS and DAAC_PRODUCTS_PROVISIONAL share the same companion
        if self in (S3Bucket.DAAC_PRODUCTS, S3Bucket.DAAC_PRODUCTS_PROVISIONAL):
            return S3Bucket.DAAC_PRIVATE
        return None

    def get_browse_companion_bucket(self) -> "S3Bucket | None":
        """Return the companion bucket for .png browse images, if one exists.

        Some DAAC buckets store .h5 product files in one bucket and their
        corresponding .png browse images in a companion bucket.

        Returns:
            The companion S3Bucket enum member, or None if this bucket has
            no companion.
        """
        # DAAC_PRODUCTS and DAAC_PRODUCTS_PROVISIONAL share the same browse companion
        if self in (S3Bucket.DAAC_PRODUCTS, S3Bucket.DAAC_PRODUCTS_PROVISIONAL):
            return S3Bucket.DAAC_BROWSE
        return None
