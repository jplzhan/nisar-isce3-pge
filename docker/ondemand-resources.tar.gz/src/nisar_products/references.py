"""Static reference data: the track-frame geopackage and cycle-times array.

Both are loaded lazily and cached. Paths default to the files under ``scripts/``
relative to the repo root and may be overridden by :func:`configure` or by the
``NISAR_TRACKFRAME_DB`` / ``NISAR_CYCLE_TIMES`` environment variables.
"""
from __future__ import annotations

import os
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, Tuple

_REPO_ROOT = Path(__file__).resolve().parents[2]
_DEFAULT_TRACKFRAME_DB = _REPO_ROOT / "scripts" / "NISAR_TrackFrame_L_20260618.gpkg"
_DEFAULT_CYCLE_TIMES = _REPO_ROOT / "scripts" / "nisar_cycle_times.npy"

_trackframe_db_path: Optional[Path] = None
_cycle_times_path: Optional[Path] = None

_trackframe_db = None      # geopandas.GeoDataFrame
_cycle_times = None        # numpy.ndarray of datetime64[us]


def configure(trackframe_db: Optional[os.PathLike] = None,
              cycle_times: Optional[os.PathLike] = None) -> None:
    """Override reference-data paths and clear cached data."""
    global _trackframe_db_path, _cycle_times_path, _trackframe_db, _cycle_times
    if trackframe_db is not None:
        _trackframe_db_path = Path(trackframe_db)
        _trackframe_db = None
    if cycle_times is not None:
        _cycle_times_path = Path(cycle_times)
        _cycle_times = None


def _resolve_trackframe_path() -> Path:
    if _trackframe_db_path is not None:
        return _trackframe_db_path
    env = os.environ.get("NISAR_TRACKFRAME_DB")
    return Path(env) if env else _DEFAULT_TRACKFRAME_DB


def _resolve_cycle_times_path() -> Path:
    if _cycle_times_path is not None:
        return _cycle_times_path
    env = os.environ.get("NISAR_CYCLE_TIMES")
    return Path(env) if env else _DEFAULT_CYCLE_TIMES


def get_trackframe_db():
    """Return the cached track-frame GeoDataFrame, loading it on first use."""
    global _trackframe_db
    if _trackframe_db is None:
        import geopandas as gpd
        _trackframe_db = gpd.read_file(_resolve_trackframe_path())
    return _trackframe_db


def get_cycle_times():
    """Return the cached cycle-zero-times array, loading it on first use."""
    global _cycle_times
    if _cycle_times is None:
        import numpy as np
        _cycle_times = np.load(_resolve_cycle_times_path(), allow_pickle=True)
    return _cycle_times


def get_trackframe_row(track: int, frame: int):
    """Return the single track-frame DB row for ``(track, frame)``."""
    db = get_trackframe_db()
    subset = db[(db["track"] == track) & (db["frame"] == frame)]
    if subset.empty:
        raise KeyError(f"No track-frame DB row for track={track}, frame={frame}")
    return subset.iloc[0]


def pass_direction(track: int, frame: int) -> str:
    """Return ``'A'`` (Ascending) or ``'D'`` (Descending) for a track-frame."""
    value = get_trackframe_row(track, frame)["passDirection"]
    if value == "Ascending":
        return "A"
    if value == "Descending":
        return "D"
    raise RuntimeError(
        f"Corrupted pass direction in track-frame DB: track={track}, "
        f"frame={frame}, passDirection={value!r}"
    )


def cycle_zero_time(cycle: int) -> datetime:
    """Return the cycle-zero datetime for a 1-based cycle number."""
    times = get_cycle_times()
    idx = cycle - 1
    if idx < 0 or idx >= len(times):
        raise IndexError(f"Cycle {cycle} out of range (1..{len(times)})")
    value = times[idx]
    # numpy.datetime64 -> python datetime
    if hasattr(value, "astype"):
        import numpy as np
        return value.astype("datetime64[us]").astype(datetime)
    return value


def estimated_time_range(track: int, frame: int, cycle: int) -> Tuple[datetime, datetime]:
    """Estimate (start, end) from startCY/endCY offsets plus the cycle-zero time."""
    row = get_trackframe_row(track, frame)
    zero = cycle_zero_time(cycle)
    start = zero + timedelta(seconds=float(row["startCY"]))
    end = zero + timedelta(seconds=float(row["endCY"]))
    return start, end


def get_insar_psf_criteria(track: int, frame: int) -> str:
    """Get INSAR PSF criteria from the Track Frame Database.

    Args:
        track: Track number
        frame: Frame number

    Returns:
        str: The INSAR PSF criteria for this track/frame
            (e.g., "solid_earth", "ice_sheets", "mountain_glaciers")

    Raises:
        KeyError: If the track/frame is not found or insarPSFCriteria is missing
    """
    row = get_trackframe_row(track, frame)

    if "insarPSFCriteria" not in row:
        raise KeyError(
            f"insarPSFCriteria field not found for track={track}, frame={frame}"
        )

    return str(row["insarPSFCriteria"])
