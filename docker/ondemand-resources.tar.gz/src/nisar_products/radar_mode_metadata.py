"""Radar mode metadata analysis from RRSD lineage.

This module provides RadarModeMetadata, which analyzes radar configuration
from RRSD (Radar Raw Signal Data) products in a lineage tree using the NISAR
mixed modes configuration.
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass
from typing import List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from .products.observation import NisarRRSD

from .enums import Polarization, RadarBand


# Module-level cache for mixed modes configuration
_MIXED_MODES_CONFIG: Optional[dict] = None


def _load_mixed_modes_config() -> dict:
    """Load the NISAR mixed modes configuration JSON.

    Lazily loads and caches the configuration file. The path is resolved
    relative to the package root.

    Returns:
        dict: The mixed modes configuration mapping mode IDs to config strings.

    Raises:
        FileNotFoundError: If the config file cannot be found.
        json.JSONDecodeError: If the config file is not valid JSON.
    """
    global _MIXED_MODES_CONFIG

    if _MIXED_MODES_CONFIG is not None:
        return _MIXED_MODES_CONFIG

    # Find the config file relative to the package root
    # This module is at src/nisar_products/radar_mode_metadata.py
    # Config is at scripts/NISAR_MIXED_MODES_CONFIG_20200101T000000_54.json
    package_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    config_path = os.path.join(
        package_dir,
        "scripts",
        "NISAR_MIXED_MODES_CONFIG_20200101T000000_54.json"
    )

    if not os.path.exists(config_path):
        raise FileNotFoundError(
            f"Mixed modes configuration file not found at: {config_path}"
        )

    with open(config_path, 'r') as f:
        _MIXED_MODES_CONFIG = json.load(f)

    return _MIXED_MODES_CONFIG


def _parse_mode_config_string(config_str: str, radar_band: RadarBand) -> dict:
    """Parse a mixed mode configuration string.

    Parses the format: {band}_{frequencyA}_{polarizationA}_{frequencyB}_{polarizationB}

    Example:
        "L_80_SH_00_NA" → {frequencyA: 77, frequencyB: 0, polarizationA: SH, polarizationB: NA}

    Note: The configuration uses "80" to represent frequencyA=77 (a specific quirk
    of the NISAR naming convention).

    Args:
        config_str: The config string to parse (e.g., "L_80_SH_00_NA").
        radar_band: The expected radar band for validation.

    Returns:
        dict: Parsed configuration with keys: frequencyA, frequencyB,
              polarizationA, polarizationB.

    Raises:
        ValueError: If the config string is not in the expected format, or if
                   invalid values are encountered.
    """
    # Check for invalid config formats that shouldn't be parsed
    invalid_configs = ["cal", "idle", "DM1", "DM2"]
    if config_str in invalid_configs:
        raise ValueError(
            f"Invalid config format '{config_str}' - not parseable in this workflow. "
            f"Config must match format: {{band}}_{{freqA}}_{{polA}}_{{freqB}}_{{polB}}"
        )

    # Split by underscore
    tokens = config_str.split('_')

    if len(tokens) != 5:
        raise ValueError(
            f"Config string '{config_str}' does not match expected format "
            f"{{band}}_{{freqA}}_{{polA}}_{{freqB}}_{{polB}} (got {len(tokens)} tokens)"
        )

    band_str, freq_a_str, pol_a_str, freq_b_str, pol_b_str = tokens

    # Validate band matches expected
    if band_str != radar_band.value:
        raise ValueError(
            f"Config band '{band_str}' does not match expected band '{radar_band.value}'"
        )

    # Parse frequency A with special case: "80" means 77
    try:
        freq_a = int(freq_a_str)
        if freq_a == 80:
            freq_a = 77
    except ValueError:
        raise ValueError(f"Invalid frequencyA value '{freq_a_str}' in config '{config_str}'")

    # Parse frequency B
    try:
        freq_b = int(freq_b_str)
    except ValueError:
        raise ValueError(f"Invalid frequencyB value '{freq_b_str}' in config '{config_str}'")

    # Validate polarization values
    try:
        pol_a = Polarization(pol_a_str)
    except ValueError:
        raise ValueError(f"Invalid polarizationA value '{pol_a_str}' in config '{config_str}'")

    try:
        pol_b = Polarization(pol_b_str)
    except ValueError:
        raise ValueError(f"Invalid polarizationB value '{pol_b_str}' in config '{config_str}'")

    return {
        "frequencyA": freq_a,
        "frequencyB": freq_b,
        "polarizationA": pol_a,
        "polarizationB": pol_b,
    }


@dataclass
class RadarModeMetadata:
    """Radar mode configuration metadata aggregated from RRSD products.

    This class aggregates radar mode information from all RRSD products in a
    lineage and parses their configurations using the NISAR mixed modes table.

    Attributes:
        radar_band: The radar band (L or S) for this product lineage.
        radar_modes: Unique sorted list of radar mode IDs from RRSD products.
        frequencyA: List of frequency A values (parallel to radar_modes).
        frequencyB: List of frequency B values (parallel to radar_modes).
        polarizationA: List of polarization A values (parallel to radar_modes).
        polarizationB: List of polarization B values (parallel to radar_modes).
    """

    radar_band: RadarBand
    radar_modes: List[int]
    frequencyA: List[int]
    frequencyB: List[int]
    polarizationA: List[Polarization]
    polarizationB: List[Polarization]

    def __init__(self, rrsd_products: List[NisarRRSD], radar_band: RadarBand):
        """Construct RadarModeMetadata from a list of RRSD products.

        Args:
            rrsd_products: List of NisarRRSD products from which to extract
                          radar mode configurations.
            radar_band: The radar band for this product lineage.

        Raises:
            ValueError: If radar mode configurations are invalid or missing.
            FileNotFoundError: If the mixed modes configuration file is not found.
        """
        self.radar_band = radar_band

        # Extract unique radar modes, filtering out None values
        modes = []
        for product in rrsd_products:
            if product.radar_mode is not None:
                modes.append(product.radar_mode)

        # Get unique sorted modes
        self.radar_modes = sorted(set(modes))

        # Initialize parallel lists
        self.frequencyA = []
        self.frequencyB = []
        self.polarizationA = []
        self.polarizationB = []

        # Load configuration
        config = _load_mixed_modes_config()

        # Parse each radar mode
        for mode in self.radar_modes:
            mode_key = str(mode)

            if mode_key not in config:
                raise ValueError(f"Radar mode {mode} not found in mixed modes configuration")

            config_list = config[mode_key]

            if not isinstance(config_list, list):
                raise ValueError(
                    f"Expected list of config strings for mode {mode}, got {type(config_list)}"
                )

            # Filter by radar band - find first config string starting with band letter
            matching_config = None
            for config_str in config_list:
                if config_str.startswith(radar_band.value):
                    matching_config = config_str
                    break

            if matching_config is None:
                raise ValueError(
                    f"No configuration found for radar band '{radar_band.value}' "
                    f"in mode {mode} (available: {config_list})"
                )

            # Parse the config string
            parsed = _parse_mode_config_string(matching_config, radar_band)

            # Append to parallel lists
            self.frequencyA.append(parsed["frequencyA"])
            self.frequencyB.append(parsed["frequencyB"])
            self.polarizationA.append(parsed["polarizationA"])
            self.polarizationB.append(parsed["polarizationB"])

    def get_max_frequency(self) -> int:
        """Get the maximum frequency value across both A and B channels.

        Returns:
            int: The maximum frequency value.
        """
        return max(self.frequencyA + self.frequencyB)

    def get_max_frequencyA(self) -> int:
        """Get the maximum frequency value from channel A only.

        Returns:
            int: The maximum frequency A value.
        """
        return max(self.frequencyA)

    def get_max_frequencyB(self) -> int:
        """Get the maximum frequency value from channel B only.

        Returns:
            int: The maximum frequency B value.
        """
        return max(self.frequencyB)

    def get_max_config_frequency(self) -> str:
        """Get the maximum frequency formatted for NISAR filename matching.

        This applies the reverse of the parsing quirk: if the max frequency is 77,
        it returns "80" (as used in filenames). All values are zero-padded to 2 digits.

        Returns:
            str: Two-digit zero-padded frequency string (e.g., "05", "80").
        """
        max_freq = self.get_max_frequency()

        # Apply reverse quirk: 77 → 80
        if max_freq == 77:
            max_freq = 80

        # Format as zero-padded 2-digit string
        return f"{max_freq:02d}"

    def get_max_config_frequencyA(self) -> str:
        """Get the maximum frequency A formatted for NISAR filename matching.

        This applies the reverse of the parsing quirk: if the max frequency is 77,
        it returns "80" (as used in filenames). All values are zero-padded to 2 digits.

        Returns:
            str: Two-digit zero-padded frequency A string (e.g., "05", "80").
        """
        max_freq = self.get_max_frequencyA()

        # Apply reverse quirk: 77 → 80
        if max_freq == 77:
            max_freq = 80

        # Format as zero-padded 2-digit string
        return f"{max_freq:02d}"

    def get_max_config_frequencyB(self) -> str:
        """Get the maximum frequency B formatted for NISAR filename matching.

        This applies the reverse of the parsing quirk: if the max frequency is 77,
        it returns "80" (as used in filenames). All values are zero-padded to 2 digits.

        Returns:
            str: Two-digit zero-padded frequency B string (e.g., "05", "80").
        """
        max_freq = self.get_max_frequencyB()

        # Apply reverse quirk: 77 → 80
        if max_freq == 77:
            max_freq = 80

        # Format as zero-padded 2-digit string
        return f"{max_freq:02d}"

    def to_dict(self) -> dict:
        """Serialize to a JSON-compatible dictionary.

        Enum values are converted to their string representations.

        Returns:
            dict: Serialized representation of this metadata.
        """
        return {
            "radar_band": self.radar_band.value,
            "radar_modes": self.radar_modes,
            "frequencyA": self.frequencyA,
            "frequencyB": self.frequencyB,
            "polarizationA": [p.value for p in self.polarizationA],
            "polarizationB": [p.value for p in self.polarizationB],
        }

    @classmethod
    def from_dict(cls, data: dict) -> "RadarModeMetadata":
        """Deserialize from a JSON-compatible dictionary.

        Reconstructs enum types from their string representations.

        Args:
            data: Dictionary representation from to_dict().

        Returns:
            RadarModeMetadata: Reconstructed metadata object.

        Raises:
            KeyError: If required fields are missing.
            ValueError: If enum values are invalid.
        """
        # Create an empty instance (bypass __init__)
        instance = cls.__new__(cls)

        # Reconstruct radar_band enum
        instance.radar_band = RadarBand(data["radar_band"])

        # Copy simple lists
        instance.radar_modes = data["radar_modes"]
        instance.frequencyA = data["frequencyA"]
        instance.frequencyB = data["frequencyB"]

        # Reconstruct polarization enums
        instance.polarizationA = [Polarization(p) for p in data["polarizationA"]]
        instance.polarizationB = [Polarization(p) for p in data["polarizationB"]]

        return instance
