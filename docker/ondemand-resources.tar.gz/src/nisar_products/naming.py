"""Granule-name tokenizing, validation, and formatting.

This module is the single source of truth for how NISAR granule names map to
identifiers, including the CRID "dumb exception" cycle offset.
"""
from __future__ import annotations

import re
from datetime import datetime
from typing import List, Optional

from .enums import (
    FrequencyA,
    FrequencyB,
    NISARProductType,
    Polarization,
    ProcessingType,
    ProductAccuracy,
    RadarBand,
)

FIXED_HEAD = "NISAR"
TIME_FORMAT = "%Y%m%dT%H%M%S"
TIME_TOKEN_RE = re.compile(r"^\d{8}T\d{6}$")

# Token counts by naming family.
SINGLE_PRODUCT_TOKEN_COUNT = 18   # RSLC/GSLC/GCOV/SME2
INSAR_PRODUCT_TOKEN_COUNT = 20    # GUNW/RUNW/GOFF/ROFF/RIFG
RRSD_PRODUCT_TOKEN_COUNT = 14     # L0B RRSD

RADAR_MODE_RE = re.compile(r"^(\d+)([SM])$")

# CRIDs affected by the operational cycle-naming mistake.
_DUMB_EXCEPTION_SUFFIXES = frozenset({"5001", "5002", "5003", "5004", "5005", "5006"})


def crid_cycle_offset(composite_release_id: str) -> int:
    """Return the cycle offset caused by the operational CRID naming mistake.

    For affected CRIDs the on-disk cycle token is 5 higher than the true cycle,
    so name-building adds this offset and name-parsing subtracts it.
    """
    crid = composite_release_id
    if crid and crid[0] in ("P", "X") and crid[-4:] in _DUMB_EXCEPTION_SUFFIXES:
        return 5
    return 0


def candidate_cycle_offsets(composite_release_id: Optional[str]) -> List[int]:
    """Return the cycle offset(s) to try when building a search prefix.

    With a known CRID the offset is fully determined, so a single value is
    returned. With no CRID the on-disk cycle token could reflect either a normal
    granule (offset 0) or a dumb-exception one (offset 5), so both are searched;
    callers validate matches by re-parsing (which applies the correct offset from
    each matched granule's own CRID) and comparing the recovered cycle.
    """
    if composite_release_id:
        return [crid_cycle_offset(composite_release_id)]
    return [0, 5]


def split_granule_name(name: str) -> List[str]:
    """Strip any extension/path and split a granule name into ``_`` tokens."""
    clean = name.strip().split(".")[0]
    clean = clean.rsplit("/", 1)[-1]
    return clean.split("_")


def parse_time_token(token: str) -> datetime:
    if not TIME_TOKEN_RE.match(token):
        raise ValueError(f"Invalid time token: {token!r}")
    return datetime.strptime(token, TIME_FORMAT)


def parse_frequency_pair(token: str) -> "tuple[FrequencyA, FrequencyB]":
    if len(token) != 4:
        raise ValueError(f"Invalid frequency token: {token!r}")
    return FrequencyA(token[:2]), FrequencyB(token[2:])


def parse_polarization_pair(token: str) -> "tuple[Polarization, Polarization]":
    if len(token) != 4:
        raise ValueError(f"Invalid polarization token: {token!r}")
    return Polarization(token[:2]), Polarization(token[2:])


def parse_mixed_mode(token: str) -> bool:
    """``M`` -> mixed (True), ``A`` -> single (False)."""
    if token == "M":
        return True
    if token == "A":
        return False
    raise ValueError(f"Invalid mixed-mode token: {token!r}")


def format_mixed_mode(is_mixed_mode: bool) -> str:
    return "M" if is_mixed_mode else "A"


def parse_partial_coverage(token: str) -> bool:
    """``P`` -> partial (True), ``F`` -> full (False)."""
    if token == "P":
        return True
    if token == "F":
        return False
    raise ValueError(f"Invalid coverage token: {token!r}")


def format_partial_coverage(is_partial_coverage: bool) -> str:
    return "P" if is_partial_coverage else "F"


def parse_band_level(token: str) -> "tuple[RadarBand, int]":
    """Parse the ``L1`` style token into (RadarBand, level_int)."""
    if len(token) < 2:
        raise ValueError(f"Invalid band/level token: {token!r}")
    band = RadarBand(token[0])
    try:
        level = int(token[1:])
    except ValueError as exc:
        raise ValueError(f"Invalid level in token: {token!r}") from exc
    return band, level


def parse_radar_mode(token: str) -> "tuple[int, bool]":
    """Parse an RRSD radar-mode token like ``150S`` -> (150, is_mixed_mode).

    Suffix ``S`` -> single mode (False), ``M`` -> mixed mode (True).
    """
    match = RADAR_MODE_RE.match(token)
    if not match:
        raise ValueError(f"Invalid radar-mode token: {token!r}")
    radar_mode = int(match.group(1))
    is_mixed_mode = match.group(2) == "M"
    return radar_mode, is_mixed_mode


def build_partial_granule_name(
    radar_band: RadarBand,
    product_type: NISARProductType,
    processing_type: ProcessingType,
    cycle: int,
    track: int,
    frame: int,
    pass_direction: str,
    composite_release_id: Optional[str],
    cycle_offset: Optional[int] = None,
) -> str:
    """Build the identifier-only prefix, applying the CRID cycle offset.

    Format:
        ``NISAR_{band}{level}_{proc}_{type}_{cycle:03}_{track:03}_{pass}_{frame:03}_``

    ``cycle_offset`` overrides the offset derived from the CRID; pass it when the
    CRID is unknown and each candidate offset must be searched (see
    :func:`candidate_cycle_offsets`).
    """
    offset = cycle_offset if cycle_offset is not None else crid_cycle_offset(composite_release_id)
    named_cycle = cycle + offset
    return (
        f"{FIXED_HEAD}_{radar_band.value}{product_type.level}_"
        f"{processing_type.value}_{product_type.code}_"
        f"{named_cycle:03d}_{track:03d}_{pass_direction}_{frame:03d}_"
    )


def build_insar_partial_granule_name(
    radar_band: RadarBand,
    product_type: NISARProductType,
    processing_type: ProcessingType,
    reference_cycle: int,
    track: int,
    frame: int,
    secondary_cycle: int,
    pass_direction: str,
    composite_release_id: Optional[str],
    cycle_offset: Optional[int] = None,
) -> str:
    """Build the identifier-only prefix for an INSAR (pairwise) product.

    Format:
        ``NISAR_{band}{level}_{proc}_{type}_{refcy:03}_{track:03}_{pass}_{frame:03}_{seccy:03}_``

    Both the reference and secondary cycle tokens receive the CRID cycle offset
    (see :func:`crid_cycle_offset`). ``cycle_offset`` overrides the offset derived
    from the CRID; pass it when the CRID is unknown and each candidate offset must
    be searched (see :func:`candidate_cycle_offsets`).
    """
    offset = cycle_offset if cycle_offset is not None else crid_cycle_offset(composite_release_id)
    named_ref = reference_cycle + offset
    named_sec = secondary_cycle + offset
    return (
        f"{FIXED_HEAD}_{radar_band.value}{product_type.level}_"
        f"{processing_type.value}_{product_type.code}_"
        f"{named_ref:03d}_{track:03d}_{pass_direction}_{frame:03d}_{named_sec:03d}_"
    )
