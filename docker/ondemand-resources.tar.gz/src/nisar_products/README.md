# nisar_products

An importable object model for NISAR products. Given a granule name it parses the
unique identifiers `(cycle, track, frame, composite_release_id)`, derives values
from static reference data (the track-frame geopackage and the 12-day cycle-times
array), resolves/downloads the matching granule from S3, and traces a product's
lineage back through the processing chain.

## Install

```bash
pip install -e ".[test]"
```

## Quick start

```python
from nisar_products import from_granule_name

p = from_granule_name(
    "NISAR_L1_PR_RSLC_024_126_D_082_4005_DHDH_A_"
    "20260704T225410_20260704T225416_P05023_N_P_J_001"
)
print(type(p).__name__)          # NisarRSLC
print(p.cycle, p.track, p.frame) # 24 126 82
print(p.get_partial_granule_name())

# trace_lineage returns a LineageNode tree (relationships are explicit).
root = p.trace_lineage()
print(root)                                   # RSLC <- RRSD
print([type(x).__name__ for x in root.flatten()])  # ['NisarRRSD']
```

## Exact lineage from a `.met.json`

When a product's metadata file is available, `trace_lineage` reads the exact
predecessor granules from its `accountability` block instead of guessing:

```python
import json
from nisar_products import from_granule_name

met = json.load(open("NISAR_L2_PR_GCOV_..._001.met.json"))
gcov = from_granule_name("NISAR_L2_PR_GCOV_..._001")
root = gcov.trace_lineage(met_json=met)   # GCOV <- RSLC <- RRSD
print(root.inputs[0].granule_name)        # exact RSLC granule
print(root.inputs[0].inputs[0].granule_name)  # exact RRSD granule

# Which predecessors were searched-for but not found (resolve mode):
root.unprocessed_products()               # {NISARProductType: [products...]}
```

## Reference data

By default the library reads the files under `scripts/`:
- `scripts/NISAR_TrackFrame_L_20260618.gpkg`
- `scripts/nisar_cycle_times.npy`

Override via `nisar_products.configure(trackframe_db=..., cycle_times=...)` or the
`NISAR_TRACKFRAME_DB` / `NISAR_CYCLE_TIMES` environment variables.

## Tests

Offline tests run with no credentials:

```bash
pytest -q
```

Live S3-resolution tests read `tests/fixtures/s3_expectations.yaml` and only run
when credentials and `--run-live` are provided:

```bash
pytest --run-live -m live
```

Add your own example granules to `tests/fixtures/granules.yaml` (parsing + lineage)
and `tests/fixtures/s3_expectations.yaml` (expected download URLs).
