"""Parsed granule metadata containers and parsers.

``NisarSingleProductMetadata`` holds the optional metadata subset of a granule.
The parse helpers return a full breakdown (identifiers + metadata) used by the
factory and by ``find_granule`` once a real product is matched.

Validation that needs the track-frame database (e.g. pass-direction consistency)
is deferred to the product constructors; parsing here validates only what can be
checked from the name alone (fixed head, token count, level vs product type).
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import List

from . import naming
from .enums import (
    FrequencyA,
    FrequencyB,
    NISARProductType,
    Polarization,
    ProcessingType,
    ProductAccuracy,
    RadarBand,
)


@dataclass
class NisarSingleProductMetadata:
    """Optional metadata attachable to a NisarSingleProduct."""
    product_counter: int
    processing_location: str
    processing_type: ProcessingType
    frequencyA: FrequencyA
    frequencyB: FrequencyB
    polarizationA: Polarization
    polarizationB: Polarization
    is_mixed_mode: bool
    is_partial_coverage: bool
    product_accuracy: ProductAccuracy
    start_time: datetime
    end_time: datetime


@dataclass
class ParsedSingleGranule:
    """Full breakdown of a single-product (18-token) granule name."""
    radar_band: RadarBand
    product_type: NISARProductType
    processing_type: ProcessingType
    cycle: int
    track: int
    frame: int
    pass_direction: str
    composite_release_id: str
    metadata: NisarSingleProductMetadata


@dataclass
class ParsedRRSDGranule:
    """Full breakdown of a 14-token L0B RRSD granule name.

    RRSD names carry a track but no frame (they span multiple frames).
    """
    radar_band: RadarBand
    product_type: NISARProductType
    processing_type: ProcessingType
    cycle: int
    track: int
    pass_direction: str
    radar_mode: int
    is_mixed_mode: bool
    start_time: datetime
    end_time: datetime
    composite_release_id: str
    product_accuracy: ProductAccuracy
    processing_location: str
    product_counter: int


@dataclass
class ParsedInsarGranule:
    """Full breakdown of an INSAR (20-token) pairwise granule name."""
    radar_band: RadarBand
    product_type: NISARProductType
    processing_type: ProcessingType
    reference_cycle: int
    secondary_cycle: int
    track: int
    frame: int
    pass_direction: str
    composite_release_id: str
    frequencyA: FrequencyA
    frequencyB: FrequencyB
    polarization: Polarization
    reference_start_time: datetime
    reference_end_time: datetime
    secondary_start_time: datetime
    secondary_end_time: datetime
    product_accuracy: ProductAccuracy
    is_partial_coverage: bool
    processing_location: str
    product_counter: int


def _validate_head_and_level(tokens: List[str], product_type: NISARProductType,
                             radar_band: RadarBand, level: int) -> None:
    if tokens[0] != naming.FIXED_HEAD:
        raise ValueError(f"Granule must start with {naming.FIXED_HEAD!r}: {tokens[0]!r}")
    if level != product_type.level:
        raise ValueError(
            f"Level token {level} inconsistent with product type "
            f"{product_type.code} (expected {product_type.level})"
        )


def parse_single_granule(name: str) -> ParsedSingleGranule:
    """Parse and validate an 18-token single-product granule name.

    Applies the CRID cycle offset (subtracts it to recover the true cycle).
    """
    tokens = naming.split_granule_name(name)
    if len(tokens) != naming.SINGLE_PRODUCT_TOKEN_COUNT:
        raise ValueError(
            f"Expected {naming.SINGLE_PRODUCT_TOKEN_COUNT} tokens for a single "
            f"product, got {len(tokens)}: {name!r}"
        )

    radar_band, level = naming.parse_band_level(tokens[1])
    processing_type = ProcessingType(tokens[2])
    product_type = NISARProductType.from_code(tokens[3])
    _validate_head_and_level(tokens, product_type, radar_band, level)

    named_cycle = int(tokens[4])
    track = int(tokens[5])
    pass_direction = tokens[6]
    frame = int(tokens[7])
    frequencyA, frequencyB = naming.parse_frequency_pair(tokens[8])
    polarizationA, polarizationB = naming.parse_polarization_pair(tokens[9])
    is_mixed_mode = naming.parse_mixed_mode(tokens[10])
    start_time = naming.parse_time_token(tokens[11])
    end_time = naming.parse_time_token(tokens[12])
    composite_release_id = tokens[13]
    product_accuracy = ProductAccuracy(tokens[14])
    is_partial_coverage = naming.parse_partial_coverage(tokens[15])
    processing_location = tokens[16]
    product_counter = int(tokens[17])

    cycle = named_cycle - naming.crid_cycle_offset(composite_release_id)

    metadata = NisarSingleProductMetadata(
        product_counter=product_counter,
        processing_location=processing_location,
        processing_type=processing_type,
        frequencyA=frequencyA,
        frequencyB=frequencyB,
        polarizationA=polarizationA,
        polarizationB=polarizationB,
        is_mixed_mode=is_mixed_mode,
        is_partial_coverage=is_partial_coverage,
        product_accuracy=product_accuracy,
        start_time=start_time,
        end_time=end_time,
    )
    return ParsedSingleGranule(
        radar_band=radar_band,
        product_type=product_type,
        processing_type=processing_type,
        cycle=cycle,
        track=track,
        frame=frame,
        pass_direction=pass_direction,
        composite_release_id=composite_release_id,
        metadata=metadata,
    )


def parse_rrsd_granule(name: str) -> ParsedRRSDGranule:
    """Parse and validate a 14-token L0B RRSD granule name.

    Layout:
        ``NISAR_L0_PR_RRSD_024_025_D_150S_<start>_<end>_P05023_F_J_001``
    Applies the CRID cycle offset (subtracts it to recover the true cycle).
    """
    tokens = naming.split_granule_name(name)
    if len(tokens) != naming.RRSD_PRODUCT_TOKEN_COUNT:
        raise ValueError(
            f"Expected {naming.RRSD_PRODUCT_TOKEN_COUNT} tokens for an RRSD "
            f"product, got {len(tokens)}: {name!r}"
        )

    radar_band, level = naming.parse_band_level(tokens[1])
    processing_type = ProcessingType(tokens[2])
    product_type = NISARProductType.from_code(tokens[3])
    _validate_head_and_level(tokens, product_type, radar_band, level)
    if product_type is not NISARProductType.RRSD:
        raise ValueError(f"Not an RRSD granule: {tokens[3]!r}")

    named_cycle = int(tokens[4])
    track = int(tokens[5])
    pass_direction = tokens[6]
    radar_mode, is_mixed_mode = naming.parse_radar_mode(tokens[7])
    start_time = naming.parse_time_token(tokens[8])
    end_time = naming.parse_time_token(tokens[9])
    composite_release_id = tokens[10]
    product_accuracy = ProductAccuracy(tokens[11])
    processing_location = tokens[12]
    product_counter = int(tokens[13])

    cycle = named_cycle - naming.crid_cycle_offset(composite_release_id)

    return ParsedRRSDGranule(
        radar_band=radar_band,
        product_type=product_type,
        processing_type=processing_type,
        cycle=cycle,
        track=track,
        pass_direction=pass_direction,
        radar_mode=radar_mode,
        is_mixed_mode=is_mixed_mode,
        start_time=start_time,
        end_time=end_time,
        composite_release_id=composite_release_id,
        product_accuracy=product_accuracy,
        processing_location=processing_location,
        product_counter=product_counter,
    )


def parse_insar_granule(name: str) -> ParsedInsarGranule:
    """Parse and validate a 20-token INSAR pairwise granule name."""
    tokens = naming.split_granule_name(name)
    if len(tokens) != naming.INSAR_PRODUCT_TOKEN_COUNT:
        raise ValueError(
            f"Expected {naming.INSAR_PRODUCT_TOKEN_COUNT} tokens for an INSAR "
            f"product, got {len(tokens)}: {name!r}"
        )

    radar_band, level = naming.parse_band_level(tokens[1])
    processing_type = ProcessingType(tokens[2])
    product_type = NISARProductType.from_code(tokens[3])
    _validate_head_and_level(tokens, product_type, radar_band, level)

    crid = tokens[15]
    offset = naming.crid_cycle_offset(crid)
    reference_cycle = int(tokens[4]) - offset
    track = int(tokens[5])
    pass_direction = tokens[6]
    frame = int(tokens[7])
    secondary_cycle = int(tokens[8]) - offset
    frequencyA, frequencyB = naming.parse_frequency_pair(tokens[9])
    polarization = Polarization(tokens[10])
    reference_start_time = naming.parse_time_token(tokens[11])
    reference_end_time = naming.parse_time_token(tokens[12])
    secondary_start_time = naming.parse_time_token(tokens[13])
    secondary_end_time = naming.parse_time_token(tokens[14])
    product_accuracy = ProductAccuracy(tokens[16])
    is_partial_coverage = naming.parse_partial_coverage(tokens[17])
    processing_location = tokens[18]
    product_counter = int(tokens[19])

    return ParsedInsarGranule(
        radar_band=radar_band,
        product_type=product_type,
        processing_type=processing_type,
        reference_cycle=reference_cycle,
        secondary_cycle=secondary_cycle,
        track=track,
        frame=frame,
        pass_direction=pass_direction,
        composite_release_id=crid,
        frequencyA=frequencyA,
        frequencyB=frequencyB,
        polarization=polarization,
        reference_start_time=reference_start_time,
        reference_end_time=reference_end_time,
        secondary_start_time=secondary_start_time,
        secondary_end_time=secondary_end_time,
        product_accuracy=product_accuracy,
        is_partial_coverage=is_partial_coverage,
        processing_location=processing_location,
        product_counter=product_counter,
    )
