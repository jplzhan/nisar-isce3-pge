"""Localize a NISAR runconfig whose ancillary fields already contain S3 links.

This is the leaner sibling of ``scripts/localize_runconfig.py``. That script is
the "exact reproduction" path: it *searches* the S3 buckets to discover a
granule's sidecar files. Here the S3 links are already known (they were written
into the runconfig by the generation step), so there is no bucket-search step --
we simply download every ``s3://`` URL found under the ``input_file_group`` and
``dynamic_ancillary_file_group`` groups, rewrite each to a local absolute path,
and stage the DEM (and optional water mask) from the runconfig geometry.

Credential handling is delegated to :mod:`nisar_products.s3_search`
(``download_url`` -> ``get_s3_client_for_bucket`` -> DAAC profile / earthaccess
fallback / expired-token refresh), exactly as the backprocessor does.

Downloads land in a shared cache directory keyed by the S3 ``bucket/key`` path so
repeated runs -- and different runconfigs referencing the same ancillary file --
reuse the cached copy instead of re-downloading.
"""
from __future__ import annotations

import json
import logging
import os
import subprocess
import sys
from typing import Any, List, Optional, Tuple
from urllib.parse import urlparse

import yaml

from . import s3_search
from .runconfig_reference import dump_runconfig_yaml

logger = logging.getLogger(__name__)

# Margin (km) passed to ISCE3 stage_dem / stage_watermask.
DEM_MARGIN_KM = 60

# Shared, cross-run download cache. Env-overridable, mirroring the
# ``NISAR_DAAC_PROFILE`` convention in s3_search.
DEFAULT_CACHE_DIR = os.environ.get(
    "NISAR_LOCALIZE_CACHE",
    os.path.expanduser("~/.cache/nisar_runconfig_localize"),
)

# Groups whose subtrees are walked for S3 links. Same targets as
# ``localize_runconfig.py`` (``target_groups``).
_TARGET_GROUPS = ("input_file_group", "dynamic_ancillary_file_group")

# Ancillary keys set by DEM/watermask staging rather than the S3 walk.
_DEM_FILE_KEY = "dem_file"
_WATER_MASK_KEY = "water_mask_file"


# ---------------------------------------------------------------------------
# YAML load: keep timestamps as plain strings so output_grid times round-trip.
# ---------------------------------------------------------------------------
class _NoTimestampLoader(yaml.SafeLoader):
    """SafeLoader that leaves ``!!timestamp`` scalars as strings."""


_NoTimestampLoader.add_constructor(
    "tag:yaml.org,2002:timestamp", lambda loader, node: node.value)


def _load_yaml(path: str) -> dict:
    with open(path, "r") as f:
        return yaml.load(f, Loader=_NoTimestampLoader)


# ---------------------------------------------------------------------------
# Download caching
# ---------------------------------------------------------------------------
def _cache_download(url: str, cache_dir: str, force_redownload: bool) -> str:
    """Download ``url`` into a per-URL subdirectory of the shared cache.

    The subdirectory is derived from the S3 ``bucket`` + key *dirname* so two
    different URLs that happen to share a basename never collide in the cache.
    ``s3_search.download_url`` no-ops when the target file already exists (and
    ``force_redownload`` is False), which is what gives cross-run caching.
    """
    parsed = urlparse(url)
    key_dir = os.path.dirname(parsed.path.lstrip("/"))
    dest_dir = os.path.join(cache_dir, parsed.netloc, key_dir)
    return s3_search.download_url(url, dest_dir, force_redownload)


# ---------------------------------------------------------------------------
# Recursive S3 -> local rewrite
# ---------------------------------------------------------------------------
def _localize_s3_paths(node: Any, cache_dir: str, force_redownload: bool) -> Any:
    """Recursively rewrite every ``s3://`` string in ``node`` to a local path.

    No hardcoded field allow-list: every string in the subtree is visited, and
    only those starting with ``s3://`` are downloaded. Non-S3 strings (e.g.
    ``dem_file_description`` free text) are returned unchanged.
    """
    if isinstance(node, dict):
        return {
            k: _localize_s3_paths(v, cache_dir, force_redownload)
            for k, v in node.items()
        }
    if isinstance(node, list):
        return [
            _localize_s3_paths(item, cache_dir, force_redownload)
            for item in node
        ]
    if isinstance(node, str) and node.startswith("s3://"):
        logger.info("Downloading S3 input: %s", node)
        try:
            local_path = _cache_download(node, cache_dir, force_redownload)
        except Exception as exc:
            # Re-raise with the offending URL attached: the default boto3
            # ClientError ("An error occurred (403) ... HeadObject") does not
            # name which S3 object failed, which makes multi-input runconfigs
            # impossible to debug. See s3_search.download_url for the bucket +
            # credential-path detail added to the message.
            logger.error("Failed to localize S3 input %s: %s", node, exc)
            raise
        logger.info("Localized %s -> %s", node, local_path)
        return local_path
    return node


# ---------------------------------------------------------------------------
# Geometry -> bounding box
# ---------------------------------------------------------------------------
def _bbox_from_geometry(groups: dict) -> Optional[Tuple[float, float, float, float]]:
    """Return ``(x_min, y_min, x_max, y_max)`` from ``geometry.track_frame_polygon``.

    ``track_frame_polygon`` is a GeoJSON string (a ``MultiPolygon``). Returns
    None if geometry or the polygon is absent/unparseable.
    """
    geometry = groups.get("geometry")
    if not isinstance(geometry, dict):
        # Expected for INSAR products (no geometry group); the caller falls back
        # to the track-frame DB via partial_granule_id.
        logger.debug("No 'geometry' group; will try track-frame DB fallback.")
        return None

    polygon_str = geometry.get("track_frame_polygon")
    if not polygon_str:
        logger.debug(
            "No 'track_frame_polygon' in geometry; will try track-frame DB "
            "fallback.")
        return None

    try:
        from shapely.geometry import shape

        geojson = json.loads(polygon_str)
        bounds = shape(geojson).bounds  # (minx, miny, maxx, maxy)
    except (ValueError, TypeError, KeyError) as exc:
        logger.warning("Could not parse track_frame_polygon: %s", exc)
        return None

    return (bounds[0], bounds[1], bounds[2], bounds[3])


def _bbox_from_partial_granule_id(
    groups: dict,
) -> Optional[Tuple[float, float, float, float]]:
    """Return the DEM bbox from the track-frame DB via ``partial_granule_id``.

    Fallback for products (INSAR) that carry no ``geometry`` group. The track and
    frame occupy the same token positions in every NISAR partial granule id
    (``NISAR_{band}{level}_{proc}_{type}_{cycle}_{track}_{pass}_{frame}_...``):
    track at index 5, frame at index 7 -- so they are read directly and used to
    look up the footprint polygon in the track-frame database. Returns None if the
    id is missing/placeholder or the track-frame row cannot be found.
    """
    pe = groups.get("primary_executable")
    if not isinstance(pe, dict):
        logger.warning(
            "No 'primary_executable' group; cannot derive DEM bbox from "
            "partial_granule_id.")
        return None

    pgid = pe.get("partial_granule_id")
    if not isinstance(pgid, str) or not pgid:
        logger.warning(
            "No 'partial_granule_id'; cannot derive DEM bbox from track-frame DB.")
        return None

    tokens = pgid.split("_")
    if len(tokens) < 8:
        logger.warning(
            "partial_granule_id %r too short to contain track/frame.", pgid)
        return None

    try:
        track = int(tokens[5])
        frame = int(tokens[7])
    except ValueError:
        logger.warning(
            "Could not parse track/frame from partial_granule_id %r "
            "(unfilled placeholders?).", pgid)
        return None

    try:
        from . import references

        row = references.get_trackframe_row(track, frame)
        bounds = row.geometry.bounds  # (minx, miny, maxx, maxy)
    except (KeyError, AttributeError) as exc:
        logger.warning(
            "No track-frame DB footprint for track=%d frame=%d: %s",
            track, frame, exc)
        return None

    logger.info(
        "Derived DEM bbox from track-frame DB (track=%d, frame=%d).", track, frame)
    return (bounds[0], bounds[1], bounds[2], bounds[3])


def _derive_bbox(groups: dict) -> Optional[Tuple[float, float, float, float]]:
    """Derive the DEM bbox: prefer geometry polygon, fall back to track-frame DB.

    Single products carry ``geometry.track_frame_polygon``; INSAR products do not,
    so their track/frame are read from ``partial_granule_id`` and the footprint is
    looked up in the track-frame database.
    """
    bbox = _bbox_from_geometry(groups)
    if bbox is not None:
        return bbox
    return _bbox_from_partial_granule_id(groups)


# ---------------------------------------------------------------------------
# DEM / watermask staging via ISCE3
# ---------------------------------------------------------------------------
def _run_stage(
    module: str,
    bbox: Tuple[float, float, float, float],
    out_vrt: str,
) -> str:
    """Run ``nisar.workflows.<module>`` for a bbox, returning the VRT path.

    Always regenerates: the VRT filenames (``dem.vrt`` / ``WATERMASK.vrt``) are
    frame-agnostic, so an existing file from a previous run may cover a different
    track-frame. Skipping on existence would silently reuse the wrong footprint,
    so we overwrite unconditionally.
    """
    x_min, y_min, x_max, y_max = bbox
    cmd = [
        sys.executable,
        "-m", f"nisar.workflows.{module}",
        "-o", out_vrt,
        "-b", str(x_min), str(y_min), str(x_max), str(y_max),
        "-m", str(DEM_MARGIN_KM),
    ]
    logger.info("Running %s: %s", module, " ".join(cmd))
    try:
        subprocess.run(cmd, check=True, capture_output=True, text=True)
    except subprocess.CalledProcessError as exc:
        logger.error("Error running %s. STDERR: %s", module, exc.stderr)
        logger.warning(
            "This usually happens when ISCE3 is not installed. Verify your "
            "environment or install ISCE3 via: ondemand-help install-isce3")
        raise
    logger.info("%s completed: %s", module, out_vrt)
    return out_vrt


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------
def localize_runconfig(
    runconfig_path: str,
    output_path: str,
    cache_dir: str = DEFAULT_CACHE_DIR,
    *,
    force_redownload: bool = False,
    stage_dem: bool = True,
    output_dir: Optional[str] = None,
    scratch_dir: Optional[str] = None,
) -> str:
    """Localize a runconfig that already contains S3 links.

    Downloads every ``s3://`` URL under ``input_file_group`` and
    ``dynamic_ancillary_file_group`` into ``cache_dir``, rewrites each to its
    local absolute path, stages the DEM (and water mask, if present in the
    template) from the runconfig geometry, and writes the localized runconfig to
    ``output_path``.

    Args:
        runconfig_path: Path to the input runconfig yaml (with S3 links).
        output_path: Where to write the localized runconfig yaml.
        cache_dir: Shared download cache directory (reused across runs).
        force_redownload: Re-download files / regenerate VRTs even if present.
        stage_dem: When False, skip DEM/watermask staging (download+rewrite only).
        output_dir: Override for product_path_group output paths (absolute path).
        scratch_dir: Override for scratch_path (absolute path).

    Returns:
        ``output_path``.
    """
    config = _load_yaml(runconfig_path)

    # Locate the working group container: the RSLC example nests groups under
    # runconfig.groups; tolerate a bare top-level mapping too.
    if isinstance(config.get("runconfig"), dict):
        rc = config["runconfig"]
        groups = rc.get("groups", rc)
    else:
        groups = config

    # Log netrc state up front: DAAC-bucket downloads need earthaccess creds
    # fetched from ~/.netrc (machine urs.earthdata.nasa.gov). A missing/empty
    # netrc means DAAC buckets silently fall back to the default AWS credential
    # chain, which typically yields a bare 403 with no clue why.
    netrc_path = os.path.expanduser("~/.netrc")
    if os.path.exists(netrc_path):
        try:
            size = os.path.getsize(netrc_path)
        except OSError:
            size = -1
        logger.info("~/.netrc present (%s bytes) for DAAC/earthaccess auth", size)
    else:
        logger.warning(
            "~/.netrc NOT found; DAAC-bucket downloads will fall back to the "
            "default AWS credential chain and likely 403")

    # 1. Download + rewrite S3 links in the two target groups.
    for group in _TARGET_GROUPS:
        if group in groups:
            logger.info("Localizing S3 links in group: %s", group)
            groups[group] = _localize_s3_paths(
                groups[group], cache_dir, force_redownload)

    # 2. Stage DEM / water mask from geometry bbox (always regenerated).
    if stage_dem:
        _stage_dem_and_watermask(groups, output_path)

    # 3. Override output/scratch directories if requested.
    if output_dir is not None or scratch_dir is not None:
        _override_output_scratch_dirs(groups, output_dir, scratch_dir)

    # 4. Write the localized runconfig.
    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    with open(output_path, "w") as f:
        dump_runconfig_yaml(config, f)
    logger.info("Wrote localized runconfig to %s", output_path)
    return output_path


def _stage_dem_and_watermask(groups: dict, output_path: str) -> None:
    """Stage dem.vrt (and WATERMASK.vrt if present) beside ``output_path``.

    Always regenerated (never cached on existence) -- the VRT names are
    frame-agnostic, so a stale file could describe a different footprint.
    """
    ancillary = groups.get("dynamic_ancillary_file_group")
    if not isinstance(ancillary, dict):
        logger.info(
            "No dynamic_ancillary_file_group; skipping DEM/watermask staging.")
        return

    bbox = _derive_bbox(groups)
    if bbox is None:
        logger.warning("No bounding box available; leaving DEM fields as-is.")
        return

    out_dir = os.path.dirname(os.path.abspath(output_path))
    os.makedirs(out_dir, exist_ok=True)

    # DEM: always staged and set.
    dem_vrt = os.path.join(out_dir, "dem.vrt")
    ancillary[_DEM_FILE_KEY] = _run_stage("stage_dem", bbox, dem_vrt)

    # Water mask: only when the template already references it.
    if _WATER_MASK_KEY in ancillary:
        watermask_vrt = os.path.join(out_dir, "WATERMASK.vrt")
        try:
            ancillary[_WATER_MASK_KEY] = _run_stage(
                "stage_watermask", bbox, watermask_vrt)
        except subprocess.CalledProcessError:
            logger.error(
                "Failed to stage watermask; removing field to prevent run "
                "failure.")
            del ancillary[_WATER_MASK_KEY]


def _override_output_scratch_dirs(
    groups: dict,
    output_dir: Optional[str],
    scratch_dir: Optional[str],
) -> None:
    """Override product_path_group output/scratch paths and logging.path.

    Creates directories if they don't exist. Rewrites paths as absolute.

    Fields overridden (when output_dir is set):
    - product_path_group.product_path
    - product_path_group.sas_output_file (replaces 'output/' prefix)
    - product_path_group.sas_config_file (replaces 'output/' prefix)

    Fields overridden (when scratch_dir is set):
    - product_path_group.scratch_path
    - worker.logging.path (if present; replaces 'scratch/' prefix)
    """
    ppg = groups.get("product_path_group")
    if not isinstance(ppg, dict):
        logger.warning("No product_path_group; cannot override output/scratch dirs.")
        return

    # Output directory overrides
    if output_dir is not None:
        output_abs = os.path.abspath(output_dir)
        os.makedirs(output_abs, exist_ok=True)
        logger.info("Overriding output directory to: %s", output_abs)

        ppg["product_path"] = output_abs

        # Rewrite sas_output_file / sas_config_file: replace 'output/' prefix
        for key in ("sas_output_file", "sas_config_file"):
            if key in ppg and isinstance(ppg[key], str):
                old_val = ppg[key]
                basename = os.path.basename(old_val)
                ppg[key] = os.path.join(output_abs, basename)
                logger.info("Rewrote %s: %s -> %s", key, old_val, ppg[key])

    # Scratch directory overrides
    if scratch_dir is not None:
        scratch_abs = os.path.abspath(scratch_dir)
        os.makedirs(scratch_abs, exist_ok=True)
        logger.info("Overriding scratch directory to: %s", scratch_abs)

        ppg["scratch_path"] = scratch_abs

        # Rewrite logging.path if present (INSAR products): replace 'scratch/' prefix
        worker = groups.get("worker")
        if isinstance(worker, dict):
            logging_group = worker.get("logging")
            if isinstance(logging_group, dict) and "path" in logging_group:
                old_val = logging_group["path"]
                basename = os.path.basename(old_val)
                logging_group["path"] = os.path.join(scratch_abs, basename)
                logger.info(
                    "Rewrote logging.path: %s -> %s", old_val, logging_group["path"]
                )
