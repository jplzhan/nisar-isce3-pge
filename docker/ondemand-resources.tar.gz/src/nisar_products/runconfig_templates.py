"""S3 template discovery for NISAR runconfig generation.

This module handles finding and downloading default runconfig templates from the
s3://nisar-static-repo/LSAR_PARAMETER_SET/ bucket structure.
"""
from __future__ import annotations

import logging
import re
from typing import TYPE_CHECKING, Optional

import boto3
import yaml
from botocore.exceptions import ClientError

if TYPE_CHECKING:
    from .enums import NISARProductType
    from .radar_mode_metadata import RadarModeMetadata

logger = logging.getLogger(__name__)

# S3 configuration
PARAMETER_SET_BUCKET = "nisar-static-repo"
PARAMETER_SET_PREFIX = "LSAR_PARAMETER_SET/"

# Product type to subdirectory mapping
PRODUCT_TYPE_TO_SUBDIR = {
    "RSLC": "RSLC/",
    "GSLC": "GSLC/",
    "GCOV": "GCOV/",
    "RIFG": "INSAR/",
    "ROFF": "INSAR/",
    "RUNW": "INSAR/",
    "GUNW": "INSAR/",
    "GOFF": "INSAR/",
    "SME2": "L3_SM/",
}


def _parse_version_string(version_dir: str) -> Optional[float]:
    """Parse version directory name to a comparable float.

    Handles formats:
    - "05020" -> 5020.0
    - "05008_patch3" -> 5008.3
    - "05010_dev_branch" -> None (ignored unless it has 'patch')

    Args:
        version_dir: Directory name (e.g., "05020", "05008_patch3")

    Returns:
        float: Comparable version number, or None if invalid/should be ignored
    """
    # Check for patch version
    if "_patch" in version_dir:
        match = re.match(r"^(\d+)_patch(\d+)$", version_dir)
        if match:
            base = int(match.group(1))
            patch = int(match.group(2))
            return float(f"{base}.{patch}")
        return None

    # Check if it's a pure numeric version (possibly with leading zeros)
    match = re.match(r"^(\d+)$", version_dir)
    if match:
        return float(int(match.group(1)))

    # Otherwise, ignore (e.g., "05010_dev_branch")
    return None


def get_latest_parameter_set_version() -> str:
    """Find the latest parameter set version directory from S3.

    Queries s3://nisar-static-repo/LSAR_PARAMETER_SET/ and returns the
    subdirectory with the highest version number, handling patch versions.

    Returns:
        str: The latest version directory name (e.g., "05020" or "05008_patch3")

    Raises:
        FileNotFoundError: If no valid parameter set directories are found
        ClientError: If S3 access fails
    """
    s3 = boto3.client('s3')

    try:
        response = s3.list_objects_v2(
            Bucket=PARAMETER_SET_BUCKET,
            Prefix=PARAMETER_SET_PREFIX,
            Delimiter='/'
        )
    except ClientError as e:
        logger.error(f"Failed to list parameter set versions from S3: {e}")
        raise

    if 'CommonPrefixes' not in response:
        raise FileNotFoundError(
            f"No parameter set directories found at s3://{PARAMETER_SET_BUCKET}/{PARAMETER_SET_PREFIX}"
        )

    # Parse all version directories
    versions = []
    for prefix_obj in response['CommonPrefixes']:
        prefix = prefix_obj['Prefix']
        # Extract directory name (remove prefix and trailing slash)
        dir_name = prefix[len(PARAMETER_SET_PREFIX):].rstrip('/')

        version_num = _parse_version_string(dir_name)
        if version_num is not None:
            versions.append((version_num, dir_name))

    if not versions:
        raise FileNotFoundError(
            "No valid parameter set version directories found "
            f"at s3://{PARAMETER_SET_BUCKET}/{PARAMETER_SET_PREFIX}"
        )

    # Sort by version number and return the latest
    versions.sort(key=lambda x: x[0], reverse=True)
    latest_version = versions[0][1]

    logger.info(f"Found latest parameter set version: {latest_version}")
    return latest_version


def _select_template_file(
    s3_files: list[str],
    product_type_code: str,
    radar_mode_metadata: Optional[RadarModeMetadata],
    insar_psf_criteria: Optional[str]
) -> Optional[str]:
    """Select the correct template file from a list of S3 file keys.

    Args:
        s3_files: List of S3 file keys (full paths)
        product_type_code: Product type code (e.g., "RSLC", "GCOV")
        radar_mode_metadata: Radar mode metadata for frequency matching
        insar_psf_criteria: INSAR PSF criteria for INSAR products

    Returns:
        str | None: Selected file key, or None if no match found
    """
    # Filter out _ur_ variants and non-YAML files
    candidates = [
        f for f in s3_files
        if f.endswith('.yaml') and '_ur_' not in f
    ]

    if not candidates:
        return None

    # Product-specific selection logic
    if product_type_code in ["GCOV", "GSLC"]:
        # Match by date and frequency
        if radar_mode_metadata is None:
            logger.warning("No radar mode metadata provided for GCOV/GSLC template selection")
            return None

        freq_str = radar_mode_metadata.get_max_config_frequency()
        # Find files matching the frequency pattern
        freq_pattern = f"_{freq_str}_"
        matching = [f for f in candidates if freq_pattern in f]

        if not matching:
            logger.warning(f"No templates found matching frequency {freq_str}")
            return None

        # Select the one with the latest date in filename
        dated_files = []
        for file_key in matching:
            date_match = re.search(r'_(\d{8})_', file_key)
            if date_match:
                date_str = date_match.group(1)
                dated_files.append((date_str, file_key))

        if dated_files:
            dated_files.sort(reverse=True)
            return dated_files[0][1]

        return matching[0]  # Fallback to first match

    elif product_type_code in ["RIFG", "ROFF", "RUNW", "GUNW", "GOFF"]:
        # INSAR products - match by PSF criteria and frequency
        if not insar_psf_criteria or not radar_mode_metadata:
            logger.warning("Missing criteria or metadata for INSAR template selection")
            return None

        freq_a = radar_mode_metadata.get_max_config_frequencyA()
        freq_b = radar_mode_metadata.get_max_config_frequencyB()

        # Default to CPU over GPU
        processor_type = "cpu"

        # Build pattern: {psf_criteria}_cpu_{freqA}_{freqB}_
        # Handle special case where ice_sheets_fast/veryfast might not exist
        # Try exact match first, then fall back to base criteria
        patterns_to_try = [
            f"{insar_psf_criteria}_{processor_type}_{freq_a}_{freq_b}_",
        ]

        # If trying ice_sheets_fast or ice_sheets_veryfast, also try ice_sheets
        if insar_psf_criteria.startswith("ice_sheets_"):
            patterns_to_try.append(f"ice_sheets_{processor_type}_{freq_a}_{freq_b}_")

        for pattern in patterns_to_try:
            matching = [f for f in candidates if pattern in f]
            if matching:
                # Select the one with the latest date
                dated_files = []
                for file_key in matching:
                    date_match = re.search(r'_(\d{8})_', file_key)
                    if date_match:
                        date_str = date_match.group(1)
                        dated_files.append((date_str, file_key))

                if dated_files:
                    dated_files.sort(reverse=True)
                    return dated_files[0][1]

                return matching[0]

        logger.warning(f"No INSAR templates found for {insar_psf_criteria}, {freq_a}, {freq_b}")
        return None

    else:
        # For RSLC, SME2, etc. - just pick the latest date, no _ur_
        dated_files = []
        for file_key in candidates:
            date_match = re.search(r'_(\d{8})_', file_key)
            if date_match:
                date_str = date_match.group(1)
                dated_files.append((date_str, file_key))

        if dated_files:
            dated_files.sort(reverse=True)
            return dated_files[0][1]

        # Fallback to first candidate
        return candidates[0] if candidates else None


def get_default_template_s3_path(
    product_type: "NISARProductType",
    radar_mode_metadata: Optional["RadarModeMetadata"] = None,
    insar_psf_criteria: Optional[str] = None,
    version: Optional[str] = None
) -> str:
    """Get the S3 path to the default template for a product type.

    Args:
        product_type: NISAR product type enum
        radar_mode_metadata: Optional radar mode metadata for frequency matching
        insar_psf_criteria: Optional INSAR PSF criteria from Track Frame Database
        version: Optional specific version to use. If None, uses latest.

    Returns:
        str: Full S3 key (path within bucket) to the template file

    Raises:
        FileNotFoundError: If no suitable template is found
        ClientError: If S3 access fails
    """
    # Get version if not specified
    if version is None:
        version = get_latest_parameter_set_version()

    # Get subdirectory for this product type
    product_code = product_type.code
    subdir = PRODUCT_TYPE_TO_SUBDIR.get(product_code)

    if subdir is None:
        raise ValueError(f"No template subdirectory mapping for product type {product_code}")

    # Build S3 prefix for listing
    s3_prefix = f"{PARAMETER_SET_PREFIX}{version}/{subdir}"

    # List files in this directory
    s3 = boto3.client('s3')

    try:
        response = s3.list_objects_v2(
            Bucket=PARAMETER_SET_BUCKET,
            Prefix=s3_prefix
        )
    except ClientError as e:
        logger.error(f"Failed to list templates from s3://{PARAMETER_SET_BUCKET}/{s3_prefix}: {e}")
        raise

    if 'Contents' not in response:
        raise FileNotFoundError(
            f"No template files found at s3://{PARAMETER_SET_BUCKET}/{s3_prefix}"
        )

    # Extract file keys
    file_keys = [obj['Key'] for obj in response['Contents']]

    # Select the appropriate template
    selected_file = _select_template_file(
        file_keys,
        product_code,
        radar_mode_metadata,
        insar_psf_criteria
    )

    if selected_file is None:
        raise FileNotFoundError(
            f"No suitable template file found for {product_code} "
            f"at s3://{PARAMETER_SET_BUCKET}/{s3_prefix}"
        )

    logger.info(f"Selected template: s3://{PARAMETER_SET_BUCKET}/{selected_file}")
    return selected_file


def download_and_parse_template(s3_key: str) -> dict:
    """Download template from S3 and parse as YAML.

    Args:
        s3_key: Full S3 key (path within nisar-static-repo bucket)

    Returns:
        dict: Parsed YAML content

    Raises:
        ClientError: If S3 download fails
        yaml.YAMLError: If YAML parsing fails
    """
    s3 = boto3.client('s3')

    try:
        logger.info(f"Downloading template from s3://{PARAMETER_SET_BUCKET}/{s3_key}")
        response = s3.get_object(Bucket=PARAMETER_SET_BUCKET, Key=s3_key)
        content = response['Body'].read()

        # Parse YAML
        template = yaml.safe_load(content)
        logger.info("Successfully parsed template YAML")
        return template

    except ClientError as e:
        logger.error(f"Failed to download template from S3: {e}")
        raise
    except yaml.YAMLError as e:
        logger.error(f"Failed to parse template YAML: {e}")
        raise
