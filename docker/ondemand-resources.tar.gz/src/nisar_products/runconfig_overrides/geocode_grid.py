"""Shared geocode-grid override for geocoded products (GCOV, GSLC, INSAR).

When a runconfig is built from a reference product of a *different* track/frame
(e.g. the GCOV radar-mode fallback), the reference's ``geocode`` corners and
``output_epsg`` describe the wrong map footprint. This module overwrites those
acquisition-specific fields from the track-frame database so they match the
product actually being generated.

Reused by :class:`InsarWorkflow`, :class:`GcovWorkflow`, and :class:`GslcWorkflow`;
NOT by :class:`FocusWorkflow` (RSLC is a radar-geometry product with no geocode
grid).
"""
from __future__ import annotations

import logging

from .. import references

logger = logging.getLogger(__name__)


def apply_geocode_grid_from_trackframe(
    groups: dict,
    track: int,
    frame: int,
    set_radar_grid_cubes_epsg: bool = True
) -> None:
    """Overwrite geocode corners + every ``output_epsg`` from the track-frame DB.

    Sets, under ``processing``:
      - ``geocode.output_epsg``            <- DB ``epsg``
      - ``geocode.top_left.x_abs``         <- DB ``mapTopLeftX``
      - ``geocode.top_left.y_abs``         <- DB ``mapTopLeftY``
      - ``geocode.bottom_right.x_abs``     <- DB ``mapBottomRightX``
      - ``geocode.bottom_right.y_abs``     <- DB ``mapBottomRightY``
      - ``radar_grid_cubes.output_epsg``   <- DB ``epsg`` (conditional)

    The ``radar_grid_cubes.output_epsg`` field is only set when
    ``set_radar_grid_cubes_epsg`` is True. This preserves reference templates
    that omit this field (it should only be set when the reference includes it).

    All EPSG occurrences are set to the same DB value. The reference template's
    other geocode fields (posting, wrapped_interferogram, radar_grid_cubes
    corners) are left untouched. Mutates ``groups`` in place; no-op with a warning
    if the track-frame row cannot be read.

    Args:
        groups: The mutable runconfig ``groups`` dict (from ``_groups``).
        track: Track number of the product being generated.
        frame: Frame number of the product being generated.
        set_radar_grid_cubes_epsg: Whether to set ``radar_grid_cubes.output_epsg``.
            Default True for backward compatibility. Set False to preserve templates
            that omit this field.
    """
    try:
        row = references.get_trackframe_row(track, frame)
    except Exception as e:  # noqa: BLE001 - DB miss shouldn't abort generation
        logger.warning(
            "No track-frame DB row for track=%s frame=%s; leaving geocode "
            "grid/EPSG as-is: %s", track, frame, e)
        return

    epsg = int(row["epsg"])
    top_left_x = float(row["mapTopLeftX"])
    top_left_y = float(row["mapTopLeftY"])
    bottom_right_x = float(row["mapBottomRightX"])
    bottom_right_y = float(row["mapBottomRightY"])

    processing = groups.setdefault("processing", {})

    geocode = processing.setdefault("geocode", {})
    geocode["output_epsg"] = epsg
    top_left = geocode.setdefault("top_left", {})
    top_left["x_abs"] = top_left_x
    top_left["y_abs"] = top_left_y
    bottom_right = geocode.setdefault("bottom_right", {})
    bottom_right["x_abs"] = bottom_right_x
    bottom_right["y_abs"] = bottom_right_y

    if set_radar_grid_cubes_epsg:
        radar_grid_cubes = processing.setdefault("radar_grid_cubes", {})
        radar_grid_cubes["output_epsg"] = epsg

    logger.info(
        "Set geocode grid from track-frame DB (track=%s frame=%s): epsg=%s, "
        "top_left=(%s, %s), bottom_right=(%s, %s), radar_grid_cubes.output_epsg=%s",
        track, frame, epsg, top_left_x, top_left_y, bottom_right_x, bottom_right_y,
        "set" if set_radar_grid_cubes_epsg else "skipped")
