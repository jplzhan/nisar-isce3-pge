"""InSAR workflow runconfig overrides.

Handles product-specific parameter overrides for the nisar.workflows.insar
script that converts 2 RSLCs -> GUNW/RUNW/GOFF/ROFF/RIFG. All five INSAR
product types share this single implementation.

Fields filled (when a source value is available):

    input_file_group:
        reference_rslc_file    <- ctx.reference_rslc_file (t0 RSLC .h5)
        secondary_rslc_file    <- ctx.secondary_rslc_file (t1 RSLC .h5)
    dynamic_ancillary_file_group:
        orbit_files:
            reference_orbit_file   <- ancillary_files.orbit_ephemeris_t0
            secondary_orbit_file   <- ancillary_files.orbit_ephemeris_t1
        troposphere_weather_model_files:
            reference_troposphere_file  <- ancillary_files.ecmwf_trop_t0
            secondary_troposphere_file  <- ancillary_files.ecmwf_trop_t1
        tec_file                    <- ancillary_files.total_electron_content_t0

Keys whose source value is None are left untouched, so any value already in the
reference/template runconfig is preserved.
"""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Union

from .base import NisarWorkflowBase, OverrideContext
from .geocode_grid import apply_geocode_grid_from_trackframe

if TYPE_CHECKING:
    from ..products.pairwise import (
        NisarGUNW, NisarRUNW, NisarGOFF, NisarROFF, NisarRIFG,
    )

logger = logging.getLogger(__name__)


class InsarWorkflow(NisarWorkflowBase):
    """Overrides for the insar workflow (GUNW/RUNW/RIFG/GOFF/ROFF)."""

    workflow_name = "InSAR"

    def apply(
        self,
        runconfig: dict,
        product: Union[
            "NisarGUNW", "NisarRUNW", "NisarGOFF", "NisarROFF", "NisarRIFG"
        ],
        ctx: OverrideContext,
    ) -> dict:
        logger.info("Applying %s workflow overrides", self.workflow_name)

        groups = self._groups(runconfig)

        # --- input_file_group: reference/secondary RSLC .h5 --------------- #
        ifg = groups.setdefault("input_file_group", {})
        if self._set_if_present(ifg, "reference_rslc_file", ctx.reference_rslc_file):
            logger.info("Set reference_rslc_file")
        else:
            logger.warning("No reference RSLC URL available for INSAR override")
        if self._set_if_present(ifg, "secondary_rslc_file", ctx.secondary_rslc_file):
            logger.info("Set secondary_rslc_file")
        else:
            logger.warning("No secondary RSLC URL available for INSAR override")

        # --- geocode grid + output_epsg from track-frame DB --------------- #
        # The reference template may be a different track/frame, so its geocode
        # corners/EPSG are wrong for this product. Done before the ancillary
        # early-return so geocode is set even when no ancillaries are available.
        # Only set radar_grid_cubes.output_epsg if the template already includes
        # it (preserves reference schema).
        processing = groups.get("processing", {})
        radar_grid_cubes = processing.get("radar_grid_cubes", {})
        has_output_epsg = "output_epsg" in radar_grid_cubes

        apply_geocode_grid_from_trackframe(
            groups, product.track, product.frame,
            set_radar_grid_cubes_epsg=has_output_epsg
        )

        # --- dynamic_ancillary_file_group: orbits + troposphere ----------- #
        anc = ctx.ancillary_files
        if anc is None:
            logger.warning(
                "No ancillary files available; leaving orbit/troposphere "
                "fields as-is in the INSAR runconfig")
            return runconfig

        dafg = groups.setdefault("dynamic_ancillary_file_group", {})

        orbit_files = dafg.setdefault("orbit_files", {})
        if self._set_if_present(
                orbit_files, "reference_orbit_file",
                getattr(anc, "orbit_ephemeris_t0", None)):
            logger.info("Set orbit_files.reference_orbit_file")
        if self._set_if_present(
                orbit_files, "secondary_orbit_file",
                getattr(anc, "orbit_ephemeris_t1", None)):
            logger.info("Set orbit_files.secondary_orbit_file")

        tropo = dafg.setdefault("troposphere_weather_model_files", {})
        if self._set_if_present(
                tropo, "reference_troposphere_file",
                getattr(anc, "ecmwf_trop_t0", None)):
            logger.info("Set troposphere_weather_model_files.reference_troposphere_file")
        if self._set_if_present(
                tropo, "secondary_troposphere_file",
                getattr(anc, "ecmwf_trop_t1", None)):
            logger.info("Set troposphere_weather_model_files.secondary_troposphere_file")

        # TEC: single file covering the reference (t0) range.
        if self._set_if_present(
                dafg, "tec_file",
                getattr(anc, "total_electron_content_t0", None)):
            logger.info("Set tec_file")

        return runconfig
