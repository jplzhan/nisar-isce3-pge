"""Product-specific runconfig override classes.

Each workflow (focus, gslc, gcov, insar, sme2) has a :class:`NisarWorkflowBase`
subclass implementing its product-specific parameter overrides. Dispatch is
data-driven via :data:`WORKFLOW_REGISTRY` / :func:`workflow_for_product`.
"""
from __future__ import annotations

from .base import (
    NisarWorkflowBase,
    OverrideContext,
    WORKFLOW_REGISTRY,
    register_workflow,
    workflow_for_product,
)
from .focus import FocusWorkflow
from .gcov import GcovWorkflow
from .gslc import GslcWorkflow
from .insar import InsarWorkflow
from .sme2 import Sme2Workflow

# Register each workflow class against the product-type code(s) it handles.
# All five INSAR products share the single InsarWorkflow implementation.
register_workflow(["RSLC"], FocusWorkflow)
register_workflow(["GSLC"], GslcWorkflow)
register_workflow(["GCOV"], GcovWorkflow)
register_workflow(["RIFG", "ROFF", "RUNW", "GUNW", "GOFF"], InsarWorkflow)
register_workflow(["SME2"], Sme2Workflow)

__all__ = [
    "NisarWorkflowBase",
    "OverrideContext",
    "WORKFLOW_REGISTRY",
    "register_workflow",
    "workflow_for_product",
    "FocusWorkflow",
    "GcovWorkflow",
    "GslcWorkflow",
    "InsarWorkflow",
    "Sme2Workflow",
]
