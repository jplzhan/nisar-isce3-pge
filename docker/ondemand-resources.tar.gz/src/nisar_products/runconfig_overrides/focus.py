"""Focus workflow (RSLC) runconfig overrides.

Handles product-specific parameter overrides for the nisar.workflows.focus
script that converts RRSD -> RSLC.
"""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from .base import NisarWorkflowBase, OverrideContext

if TYPE_CHECKING:
    from ..products.single import NisarRSLC

logger = logging.getLogger(__name__)


class FocusWorkflow(NisarWorkflowBase):
    """RSLC overrides for the focus workflow.

    Sets, for the single-product (RSLC) runconfig layout:

    - ``input_file_group.input_file_path`` -- this RSLC's own input RRSD ``.h5``
      files (from its lineage). Overwritten unconditionally: a reference/template
      runconfig carries the *reference* product's RRSD paths, wrong for the
      product being generated.
    - ``processing.output_grid.start_time`` / ``end_time`` -- the product's time
      range. (INSAR runconfigs have no ``output_grid``, so this is RSLC-specific.)
    - ``dynamic_ancillary_file_group`` orbit/pointing/calibration files -- the
      flat single-product keys (``orbit``, ``pointing``, ``external_calibration``,
      ``internal_calibration``, ``antenna_pattern``, ``corner_reflector_file``).
      INSAR uses a different nested layout (see :class:`InsarWorkflow`).
    """

    workflow_name = "focus (RSLC)"

    def apply(
        self,
        runconfig: dict,
        product: "NisarRSLC",
        ctx: OverrideContext,
    ) -> dict:
        # Imported here (not at module load) to avoid a circular import:
        # runconfig_reference imports the overrides package indirectly.
        from ..runconfig_reference import (
            _ANCILLARY_FIELD_TO_RUNCONFIG_KEY,
            _format_output_grid_time,
        )

        logger.info("Applying %s workflow overrides", self.workflow_name)

        groups = self._groups(runconfig)

        # --- input_file_group.input_file_path (lineage RRSD .h5 list) -------- #
        if ctx.input_file_paths:
            ifg = groups.setdefault("input_file_group", {})
            ifg["input_file_path"] = list(ctx.input_file_paths)
            logger.info(
                "Set input_file_group.input_file_path to %d RRSD input(s)",
                len(ctx.input_file_paths))
        else:
            logger.warning(
                "No RRSD input paths provided for RSLC input_file_group override; "
                "leaving input_file_path unchanged")

        # --- processing.output_grid start/end -------------------------------- #
        if ctx.time_range is not None:
            start_time, end_time = ctx.time_range
            processing = groups.setdefault("processing", {})
            output_grid = processing.setdefault("output_grid", {})
            output_grid["start_time"] = _format_output_grid_time(start_time)
            output_grid["end_time"] = _format_output_grid_time(end_time)

        # --- dynamic_ancillary_file_group (flat single-product keys) --------- #
        if ctx.ancillary_files is not None:
            dafg = groups.setdefault("dynamic_ancillary_file_group", {})
            for field_name, key in _ANCILLARY_FIELD_TO_RUNCONFIG_KEY.items():
                value = getattr(ctx.ancillary_files, field_name, None)
                if value is not None:
                    dafg[key] = value

        return runconfig
