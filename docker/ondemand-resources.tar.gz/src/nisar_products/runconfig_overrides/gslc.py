"""GSLC workflow runconfig overrides.

Handles product-specific parameter overrides for the nisar.workflows.gslc
script that converts RSLC -> GSLC.
"""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from .base import NisarWorkflowBase, OverrideContext
from .geocode_grid import apply_geocode_grid_from_trackframe

if TYPE_CHECKING:
    from ..products.single import NisarGSLC

logger = logging.getLogger(__name__)


class GslcWorkflow(NisarWorkflowBase):
    """GSLC overrides for the gslc workflow.

    Sets ``input_file_group.input_file_path`` to the single input RSLC ``.h5``
    (a scalar string, per the ISCE3 gslc schema -- "One NISAR L1B RSLC formatted
    HDF5 file"). For a future product whose RSLC has not been generated yet, the
    caller supplies the RSLC's ``partial_prefix`` as a placeholder.

    TODO: geocoding grid, resampling method, EPSG, posting are still left to the
    downloaded reference template.
    """

    workflow_name = "GSLC"

    def apply(
        self,
        runconfig: dict,
        product: "NisarGSLC",
        ctx: OverrideContext,
    ) -> dict:
        logger.info("Applying %s workflow overrides", self.workflow_name)

        groups = self._groups(runconfig)

        # --- input_file_group.input_file_path (single input RSLC .h5) -------- #
        # Schema requires a scalar string (one RSLC), unlike RSLC's list.
        if ctx.input_file_paths:
            ifg = groups.setdefault("input_file_group", {})
            ifg["input_file_path"] = ctx.input_file_paths[0]
            logger.info(
                "Set input_file_group.input_file_path to %s",
                ctx.input_file_paths[0])
        else:
            logger.warning(
                "No input RSLC provided for %s input_file_group override; "
                "leaving input_file_path unchanged", self.workflow_name)

        # --- dynamic_ancillary_file_group (flat GSLC keys) ------------------- #
        # GSLC's group: scalar orbit_file, tec_file, and corner_reflector_file
        # (no calibration/antenna keys). dem_file is left to the template (the
        # ancillary finder does not produce a DEM).
        anc = ctx.ancillary_files
        if anc is not None:
            dafg = groups.setdefault("dynamic_ancillary_file_group", {})
            if self._set_if_present(
                    dafg, "orbit_file", getattr(anc, "orbit_ephemeris", None)):
                logger.info("Set dynamic_ancillary_file_group.orbit_file")
            if self._set_if_present(
                    dafg, "tec_file",
                    getattr(anc, "total_electron_content", None)):
                logger.info("Set dynamic_ancillary_file_group.tec_file")
            if self._set_if_present(
                    dafg, "corner_reflector_file",
                    getattr(anc, "corner_reflector", None)):
                logger.info("Set dynamic_ancillary_file_group.corner_reflector_file")
        else:
            logger.warning(
                "No ancillary files for %s; leaving dynamic_ancillary_file_group "
                "as-is", self.workflow_name)

        # --- geocode grid + output_epsg from track-frame DB ------------------ #
        # The reference template may be a different track/frame, so its geocode
        # corners/EPSG are wrong for this product. Only set radar_grid_cubes.output_epsg
        # if the template already includes it (preserves reference schema).
        processing = groups.get("processing", {})
        radar_grid_cubes = processing.get("radar_grid_cubes", {})
        has_output_epsg = "output_epsg" in radar_grid_cubes

        apply_geocode_grid_from_trackframe(
            groups, product.track, product.frame,
            set_radar_grid_cubes_epsg=has_output_epsg
        )

        return runconfig
