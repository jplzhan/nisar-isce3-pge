# Runconfig Overrides

This directory contains workflow-specific runconfig override modules. Each module implements product-specific parameter overrides for its corresponding NISAR processing workflow.

## Structure

Each workflow has its own module:

- **`focus.py`**: RSLC products (nisar.workflows.focus: RRSD → RSLC)
- **`gslc.py`**: GSLC products (nisar.workflows.gslc: RSLC → GSLC)
- **`gcov.py`**: GCOV products (nisar.workflows.gcov: RSLC → GCOV)
- **`insar.py`**: InSAR products (nisar.workflows.insar: 2 RSLCs → GUNW/RUNW/GOFF/ROFF/RIFG)
- **`sme2.py`**: SME2 products (nisar.workflows.sme2: 3 GCOVs → SME2)

## Interface

Each module exports a single function with the signature:

```python
def apply_<workflow>_overrides(runconfig: dict, product: NisarSingleProduct) -> dict:
    """Apply workflow-specific overrides.
    
    Args:
        runconfig: The runconfig dict with common parameters already populated
        product: The NisarSingleProduct instance containing product metadata
    
    Returns:
        dict: Updated runconfig with workflow-specific overrides applied
    """
```

## Implementation Status

All modules are currently stubs marked with TODO comments. Each needs to be implemented based on:

1. **Workflow-specific requirements**: What parameters does this workflow need?
2. **Input file configuration**: How to specify input products (RRSD, RSLC, GCOV, etc.)
3. **Processing parameters**: Algorithm settings, grid specifications, etc.
4. **Output specifications**: Product format, naming conventions, etc.

## Usage

The `apply_product_specific_overrides()` function in `runconfig_builder.py` automatically routes to the correct override module based on the product type:

```python
from nisar_products import runconfig_builder

# Automatically routes to the correct workflow module
runconfig = runconfig_builder.apply_product_specific_overrides(runconfig, product)
```

## Adding New Workflows

To add support for a new workflow:

1. Create a new module file (e.g., `new_workflow.py`)
2. Implement the `apply_<workflow>_overrides()` function
3. Export the function in `__init__.py`
4. Add routing logic in `runconfig_builder.py`

## Examples of Override Scenarios

### Focus (RSLC)
- Input RRSD file paths
- Doppler estimation parameters
- Range/azimuth compression settings
- Output RSLC specifications

### GSLC
- Input RSLC file paths
- Geocoding grid parameters (EPSG, posting)
- Resampling method
- DEM configuration

### GCOV
- Input RSLC file paths
- Covariance computation method
- Multilook factors
- Radiometric terrain correction

### InSAR
- Reference and secondary RSLC paths
- Coregistration parameters
- Interferogram formation settings
- Unwrapping algorithm (SNAPHU, ICU)
- Coherence estimation

### SME2
- Three input GCOV file paths (time series)
- Soil moisture retrieval algorithm
- Vegetation correction parameters
- L3 grid specifications
