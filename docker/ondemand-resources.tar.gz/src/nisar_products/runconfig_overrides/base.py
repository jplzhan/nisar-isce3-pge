"""Base class + registry for product-specific runconfig overrides.

Each NISAR workflow (focus, gslc, gcov, insar, sme2) applies a different set of
acquisition-specific overrides on top of a template runconfig. The override
logic lives in a small class hierarchy rooted at :class:`NisarWorkflowBase`:

    NisarWorkflowBase          (shared helpers + template method)
     |-- FocusWorkflow         (RSLC)
     |-- GslcWorkflow          (GSLC)
     |-- GcovWorkflow          (GCOV)
     |-- InsarWorkflow         (GUNW/RUNW/RIFG/GOFF/ROFF -- the insar workflow)
     |-- Sme2Workflow          (SME2)

Common behavior (unwrapping the ``runconfig`` -> ``groups`` nesting, setting
keys under ``input_file_group`` / ``dynamic_ancillary_file_group``) is
implemented once on the superclass and reused by every subclass.

Dispatch is data-driven: :func:`workflow_for_product` looks the concrete class
up in :data:`WORKFLOW_REGISTRY` by product-type code, so callers never branch on
product type themselves.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime
from typing import TYPE_CHECKING, Dict, List, Optional, Tuple, Type

if TYPE_CHECKING:
    from ..products.base import NisarSingleProduct
    from ..ancillary_finder import AncillaryFiles

logger = logging.getLogger(__name__)


@dataclass
class OverrideContext:
    """Everything an override needs that is not on the product itself.

    Threaded from the generator so overrides stay S3-free where the data is
    already available (e.g. lineage URLs recorded in the backprocessor JSON).

    Attributes:
        input_file_paths: Lineage input ``.h5`` URLs (RRSD list for RSLC).
        ancillary_files: Resolved ancillary files (orbit/tropo/tec/etc.).
        reference_rslc_file: Reference (t0) RSLC ``.h5`` URL for INSAR products.
        secondary_rslc_file: Secondary (t1) RSLC ``.h5`` URL for INSAR products.
        time_range: (start, end) for ``processing.output_grid`` -- a single-product
            (RSLC) field. For pairwise products this is the reference (t0) range.
    """

    input_file_paths: Optional[List[str]] = None
    ancillary_files: Optional["AncillaryFiles"] = None
    reference_rslc_file: Optional[str] = None
    secondary_rslc_file: Optional[str] = None
    time_range: Optional[Tuple[datetime, datetime]] = None


class NisarWorkflowBase:
    """Base class for workflow-specific runconfig overrides.

    Subclasses override :meth:`apply` to mutate the runconfig for their
    product/workflow. Shared dict-plumbing helpers live here so each subclass
    stays focused on *what* to set, not *how* to reach the nested groups.
    """

    #: Human-readable workflow name for logging (set by subclasses).
    workflow_name: str = "base"

    # --- shared helpers ---------------------------------------------------- #
    @staticmethod
    def _groups(runconfig: dict) -> dict:
        """Return the mutable ``groups`` dict, tolerating flatter layouts.

        Reference templates nest as ``{"runconfig": {"groups": {...}}}``; some
        callers pass just the inner dict. This unwraps whichever is present.
        """
        rc = runconfig.get("runconfig", runconfig)
        return rc.get("groups", rc)

    @classmethod
    def _set_if_present(cls, section: dict, key: str, value) -> bool:
        """Set ``section[key] = value`` only when ``value`` is not None.

        Returns True if the key was written. Leaving None-sourced keys
        untouched preserves any value already carried by the template.
        """
        if value is None:
            return False
        section[key] = value
        return True

    # --- template method --------------------------------------------------- #
    def apply(
        self,
        runconfig: dict,
        product: "NisarSingleProduct",
        ctx: OverrideContext,
    ) -> dict:
        """Apply workflow-specific overrides and return the runconfig.

        Base implementation is a no-op (used by workflows with no overrides
        implemented yet). Subclasses override to fill their fields.
        """
        logger.info("Applying %s workflow overrides", self.workflow_name)
        return runconfig


# --------------------------------------------------------------------------- #
# Registry
# --------------------------------------------------------------------------- #
# Populated by runconfig_overrides/__init__.py after the subclasses import
# (avoids a circular import at module load). Maps product-type code -> class.
WORKFLOW_REGISTRY: Dict[str, Type[NisarWorkflowBase]] = {}


def register_workflow(product_codes: List[str], cls: Type[NisarWorkflowBase]) -> None:
    """Register ``cls`` as the workflow override for each product code."""
    for code in product_codes:
        WORKFLOW_REGISTRY[code] = cls


def workflow_for_product(product: "NisarSingleProduct") -> NisarWorkflowBase:
    """Return a workflow-override instance for the product's type.

    Falls back to a no-op :class:`NisarWorkflowBase` for unregistered types
    (logs a warning), matching the previous "use runconfig unchanged" behavior.
    """
    code = product.product_type.code
    cls = WORKFLOW_REGISTRY.get(code)
    if cls is None:
        logger.warning(
            "No workflow override registered for product type %s. "
            "Using runconfig without product-specific overrides.",
            code,
        )
        return NisarWorkflowBase()
    return cls()
