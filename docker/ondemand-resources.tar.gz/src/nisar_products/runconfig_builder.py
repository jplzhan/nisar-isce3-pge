"""Runconfig building and population logic.

This module handles Steps 2-4 from the requirements: populating common parameters,
applying product-specific overrides, and orchestrating the full workflow.
"""
from __future__ import annotations

import copy
import logging
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from .ancillary_finder import AncillaryFiles
    from .enums import NISARProductType, S3Bucket
    from .products.base import NisarSingleProduct

from .enums import INSAR_PRODUCT_TYPES

logger = logging.getLogger(__name__)


def populate_common_parameters(
    template: dict,
    product: "NisarSingleProduct",
    target_crid: str,
    ancillary_files: Optional["AncillaryFiles"] = None,
) -> dict:
    """Populate common runconfig parameters (Step 2 from requirements).

    Starting from the default template, adds fields based on the product being
    generated.

    Args:
        template: The base template dict (from S3 or reference product)
        product: The NisarSingleProduct instance
        target_crid: The target CRID for processing
        ancillary_files: Ancillary files found for this product, if any. Its
            computed ``product_accuracy`` (lowest of OE/RP precision) is written
            into ``primary_executable.product_accuracy`` when present.

    Returns:
        dict: Updated runconfig with common parameters populated
    """
    # Make a deep copy to avoid modifying the original template
    runconfig = copy.deepcopy(template)

    # Ensure runconfig structure exists
    if 'runconfig' not in runconfig:
        runconfig = {'runconfig': runconfig}

    rc = runconfig['runconfig']

    # Set the name
    product_code_dash = product.product_type.code.replace('_', '-')
    rc['name'] = f"NISAR_{product_code_dash}_RUNCONFIG"

    # All parameter groups live under runconfig.groups.* (matching the real
    # .rc.yaml / test_runconfig.yaml layout). The template may already carry a
    # 'groups' dict with processing/qa deltas, so populate into it in place.
    if 'groups' not in rc:
        rc['groups'] = {}
    groups = rc['groups']

    # Initialize product_path_group if not present
    if 'product_path_group' not in groups:
        groups['product_path_group'] = {}

    ppg = groups['product_path_group']
    ppg['product_path'] = 'output'
    ppg['scratch_path'] = 'scratch'
    ppg['sas_output_file'] = None
    ppg['sas_config_file'] = 'output/rslc_config.yaml'  # TODO: Make product-specific
    ppg['product_counter'] = None
    ppg['qa_output_dir'] = 'output'

    # Initialize primary_executable if not present
    if 'primary_executable' not in groups:
        groups['primary_executable'] = {}

    pe = groups['primary_executable']
    pe['product_type'] = product.product_type.code
    pe['product_version'] = '1.0.3'  # TODO: Make configurable

    # Set product_doi only for non-INSAR products
    doi = product.product_type.get_doi()
    if doi is not None:
        pe['product_doi'] = doi

    pe['composite_release_id'] = target_crid
    pe['processing_type'] = 'PR'
    pe['mission_id'] = 'NISAR'
    if ancillary_files is not None and ancillary_files.product_accuracy is not None:
        pe['product_accuracy'] = ancillary_files.product_accuracy.value
    else:
        pe['product_accuracy'] = None
    pe['urgent_request_id'] = []
    pe['processing_center'] = 'J'
    pe['data_source'] = 'A'
    pe['partial_granule_id'] = None

    # Initialize debug_level_group if not present
    if 'debug_level_group' not in groups:
        groups['debug_level_group'] = {}

    groups['debug_level_group']['debug_switch'] = False

    # Populate geometry ONLY for non-INSAR products (RSLC, GCOV, GSLC, SME2, RRSD)
    # INSAR products (GUNW, RUNW, ROFF, RIFG, GOFF) do NOT get geometry section
    if product.product_type not in INSAR_PRODUCT_TYPES:
        # Initialize geometry if not present
        if 'geometry' not in groups:
            groups['geometry'] = {}

        geom = groups['geometry']
        geom['relative_orbit_number'] = product.track
        geom['frame_number'] = product.frame

        # Handle cycle_number for both single and pairwise products
        if hasattr(product, 'cycles'):
            # Pairwise product: use reference cycle (first cycle)
            geom['cycle_number'] = product.cycles[0]
        else:
            # Single product: use cycle directly
            geom['cycle_number'] = product.cycle

        geom['orbit_direction'] = product.pass_direction

        # Get geometry GeoJSON string from track_frame_db_info
        if hasattr(product, 'track_frame_db_info') and product.track_frame_db_info is not None:
            # Convert geometry to GeoJSON string if it's a shapely object
            try:
                import json
                geom_obj = product.track_frame_db_info.geometry
                if hasattr(geom_obj, '__geo_interface__'):
                    geom['track_frame_polygon'] = json.dumps(geom_obj.__geo_interface__)
                else:
                    geom['track_frame_polygon'] = str(geom_obj)
            except Exception as e:
                logger.warning(f"Could not serialize geometry: {e}")
                geom['track_frame_polygon'] = None
        else:
            geom['track_frame_polygon'] = None

        geom['full_coverage_threshold_percent'] = 75.0

    # Initialize worker if not present
    if 'worker' not in groups:
        groups['worker'] = {}

    groups['worker']['gpu_enabled'] = False
    groups['worker']['gpu_id'] = 0

    logger.info("Populated common runconfig parameters")
    return runconfig


def apply_product_specific_overrides(
    runconfig: dict,
    product: "NisarSingleProduct",
    input_file_paths: Optional[list] = None,
    ancillary_files: Optional["AncillaryFiles"] = None,
    reference_rslc_file: Optional[str] = None,
    secondary_rslc_file: Optional[str] = None,
    time_range=None,
) -> dict:
    """Apply product-type-specific overrides (Step 3 from requirements).

    Looks up the workflow-override class for the product's type in
    ``WORKFLOW_REGISTRY`` and calls it. Each workflow is a
    :class:`~nisar_products.runconfig_overrides.base.NisarWorkflowBase`
    subclass; shared plumbing lives on the base and the acquisition-specific
    data is threaded via :class:`OverrideContext`.

    Args:
        runconfig: The runconfig dict with common parameters.
        product: The product instance (NisarSingleProduct or NisarPairwiseProduct).
        input_file_paths: Lineage input ``.h5`` URLs (RRSD list for RSLC).
        ancillary_files: Resolved ancillary files (orbit/tropo/tec/etc.), used by
            the INSAR workflow to fill orbit_files / troposphere fields and by the
            RSLC workflow to fill the flat calibration/orbit keys.
        reference_rslc_file: Reference (t0) RSLC ``.h5`` URL for INSAR products.
        secondary_rslc_file: Secondary (t1) RSLC ``.h5`` URL for INSAR products.
        time_range: (start, end) for ``processing.output_grid`` (RSLC only).

    Returns:
        dict: Updated runconfig with product-specific overrides.
    """
    from .runconfig_overrides import OverrideContext, workflow_for_product

    ctx = OverrideContext(
        input_file_paths=input_file_paths,
        ancillary_files=ancillary_files,
        reference_rslc_file=reference_rslc_file,
        secondary_rslc_file=secondary_rslc_file,
        time_range=time_range,
    )
    workflow = workflow_for_product(product)
    return workflow.apply(runconfig, product, ctx)


def build_runconfig_for_product(
    product: "NisarSingleProduct",
    target_crid: Optional[str],
    buckets: Optional[list["S3Bucket"]],
    template: dict,
    input_file_paths: Optional[list] = None,
    ancillary_files: Optional["AncillaryFiles"] = None,
    reference_rslc_file: Optional[str] = None,
    secondary_rslc_file: Optional[str] = None,
    time_range=None,
) -> dict:
    """Orchestrate the full runconfig generation workflow.

    Args:
        product: The NisarSingleProduct instance
        target_crid: The target CRID (already determined by caller)
        buckets: S3 buckets for searching (if needed)
        template: The base template (already obtained by caller)

    Returns:
        dict: Complete runconfig ready for YAML serialization

    Raises:
        ValueError: If required parameters are missing
    """
    if target_crid is None:
        raise ValueError("target_crid must be specified")

    # Format cycle info (handle both single and pairwise products)
    if hasattr(product, 'cycles'):
        cycle_info = f"cycles={product.cycles}"
    elif hasattr(product, 'cycle'):
        cycle_info = f"cycle={product.cycle}"
    else:
        cycle_info = "cycle=N/A"

    logger.info(
        f"Building runconfig for {product.product_type.code} "
        f"({cycle_info}, track={product.track}, "
        f"frame={product.frame}, CRID={target_crid})"
    )

    # Step 2: Populate common parameters
    runconfig = populate_common_parameters(
        template, product, target_crid, ancillary_files=ancillary_files)

    # Step 3: Apply product-specific overrides
    runconfig = apply_product_specific_overrides(
        runconfig, product,
        input_file_paths=input_file_paths,
        ancillary_files=ancillary_files,
        reference_rslc_file=reference_rslc_file,
        secondary_rslc_file=secondary_rslc_file,
        time_range=time_range,
    )

    # Step 4: Return the completed runconfig
    logger.info("Runconfig generation complete")
    return runconfig
