"""Direct reference product search for runconfig generation.

This module handles Step 1.1 from the requirements: finding a direct reference
product that matches (product_type, track, frame, target_crid) in ANY cycle in
ANY enumerated bucket.

Empirically, the ``.met.json``'s ``runconfig.processing.parameter_set_content``
named by the original design is a *sparse* delta (only a handful of parameter
overrides -- no ``geometry``, no ``processing.output_grid``). The reference
product's ``.rc.yaml`` sidecar, by contrast, is the *full* runconfig and is what
we actually want as a template: we start from it and overwrite only the fields
that differ for the new acquisition (ancillary files, ``geometry.cycle_number``,
and ``processing.output_grid.start_time`` / ``end_time``).
"""
from __future__ import annotations

import copy
import json
import logging
import re
from dataclasses import dataclass
from datetime import datetime
from typing import TYPE_CHECKING, List, Optional

import yaml

from .enums import INSAR_PRODUCT_TYPES

if TYPE_CHECKING:
    from .ancillary_finder import AncillaryFiles
    from .enums import NISARProductType, S3Bucket

logger = logging.getLogger(__name__)

# Sidecar extension carrying the full runconfig for a processed product.
RUNCONFIG_EXTENSION = ".rc.yaml"


class _RunconfigDumper(yaml.SafeDumper):
    """SafeDumper that renders datetimes like reference .rc.yaml sidecars."""


# ISO-8601 whole-second UTC with a ``Z`` suffix, e.g. ``2026-07-26T00:32:33Z``.
_ISO_Z_TIMESTAMP_RE = re.compile(
    r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$")


def _represent_runconfig_datetime(dumper, data):
    # Reference sidecars use ISO-8601 whole-second UTC with a ``Z`` suffix,
    # emitted as an (unquoted) YAML timestamp -- e.g. ``2026-07-26T00:32:33Z``.
    return dumper.represent_scalar(
        "tag:yaml.org,2002:timestamp", data.strftime("%Y-%m-%dT%H:%M:%SZ"))


def _represent_runconfig_str(dumper, data):
    # When a runconfig is loaded with timestamps kept as plain strings (e.g. the
    # localizer's _NoTimestampLoader), an ISO-Z timestamp string would otherwise
    # be *quoted* by PyYAML to prevent it reparsing as a !!timestamp. ISCE3 needs
    # the unquoted timestamp form, so emit those strings as timestamp scalars.
    if _ISO_Z_TIMESTAMP_RE.match(data):
        return dumper.represent_scalar("tag:yaml.org,2002:timestamp", data)
    return dumper.represent_str(data)


_RunconfigDumper.add_representer(datetime, _represent_runconfig_datetime)
_RunconfigDumper.add_representer(str, _represent_runconfig_str)


def dump_runconfig_yaml(runconfig: dict, stream=None, **kwargs):
    """Serialize a runconfig dict to YAML with reference-matching datetime format.

    Same options as the previous ``yaml.dump`` call site, but routes datetimes
    through :class:`_RunconfigDumper` so ``output_grid`` times render as
    ``YYYY-MM-DDTHH:MM:SSZ`` instead of Python's default repr.
    """
    kwargs.setdefault("default_flow_style", False)
    kwargs.setdefault("sort_keys", False)
    return yaml.dump(runconfig, stream, Dumper=_RunconfigDumper, **kwargs)


@dataclass
class ReferenceMatch:
    """A direct-reference product located in S3.

    Carries everything needed to locate the granule's sidecar files:
    the ``bucket`` it lives in and, for date-path (JPL) buckets, the
    ``date_path`` (``YYYY/MM/DD``) segment of its folder.
    """
    granule: str
    bucket: "S3Bucket"
    date_path: Optional[str] = None


def acceptable_crids(target_crid: str) -> "list[str]":
    """Return the CRIDs that count as a match for a target CRID.

    A ``P``-prefixed CRID is ALWAYS a valid alternative regardless of the
    target's first letter (e.g. target ``X05013`` also matches ``P05013``): the
    cycle-offset math depends only on the numeric suffix, which is identical, so
    a ``P`` product of the same track/frame/cycle is an equivalent reference.
    Order is preserved (exact target first), deduped.
    """
    crids = [target_crid]
    if len(target_crid) > 1:
        p_variant = "P" + target_crid[1:]
        if p_variant != target_crid:
            crids.append(p_variant)
    return crids


def radar_mode_signatures_from_metadata(radar_mode_metadata) -> "set":
    """Build the set of granule radar-mode signatures a reference may match.

    Each signature is ``(freqA, freqB, polA, polB)`` as 2-char strings, matching
    :func:`_granule_radar_mode_signature`. ``RadarModeMetadata`` carries parallel
    per-mode lists (freq as int, pol as :class:`Polarization`); this produces one
    signature per mode so a single-mode granule matches any listed mode. Returns
    an empty set when metadata is missing or malformed.
    """
    if radar_mode_metadata is None:
        return set()

    signatures = set()
    try:
        fa = radar_mode_metadata.frequencyA
        fb = radar_mode_metadata.frequencyB
        pa = radar_mode_metadata.polarizationA
        pb = radar_mode_metadata.polarizationB
        for i in range(len(fa)):
            # 77 -> "80" filename quirk, zero-pad to 2 digits (matches granule).
            freq_a = "80" if fa[i] == 77 else f"{fa[i]:02d}"
            freq_b = "80" if fb[i] == 77 else f"{fb[i]:02d}"
            signatures.add((freq_a, freq_b, pa[i].value, pb[i].value))
    except (AttributeError, IndexError, TypeError):
        return set()
    return signatures


def _parse_granule(granule_name: str, product_type: "NISARProductType"):
    """Parse a granule name with the parser for its family, or None on failure."""
    from .metadata import parse_insar_granule, parse_single_granule

    try:
        if product_type in INSAR_PRODUCT_TYPES:
            return parse_insar_granule(granule_name)
        return parse_single_granule(granule_name)
    except ValueError:
        return None


def _granule_matches(
    granule_name: str,
    product_type: "NISARProductType",
    track: int,
    frame: int,
    crids: "set[str]",
) -> bool:
    """Return True if a granule name matches type + track + frame + CRID.

    ``crids`` is the set of acceptable CRIDs (see :func:`acceptable_crids`).
    """
    parsed = _parse_granule(granule_name, product_type)
    if parsed is None:
        return False
    return (
        parsed.product_type == product_type
        and parsed.track == track
        and parsed.frame == frame
        and parsed.composite_release_id in crids
    )


def _granule_matches_track_crid(
    granule_name: str,
    product_type: "NISARProductType",
    track: int,
    crids: "set[str]",
) -> bool:
    """Return True if a granule matches type + track + CRID, IGNORING frame.

    Used only for the RSLC track+CRID fallback (see :func:`find_reference_product`).
    """
    parsed = _parse_granule(granule_name, product_type)
    if parsed is None:
        return False
    return (
        parsed.product_type == product_type
        and parsed.track == track
        and parsed.composite_release_id in crids
    )


def _granule_radar_mode_signature(parsed) -> "Optional[tuple]":
    """Return a granule's (freqA, freqB, polA, polB) signature, or None.

    The four values are the radar-mode discriminators encoded in a single-product
    granule name (tokens ``4005`` -> freqA/freqB, ``DHDH`` -> polA/polB), taken as
    their raw 2-char string values so they compare directly against a target
    signature built from :class:`RadarModeMetadata` (see
    :func:`radar_mode_signatures_from_metadata`). Returns None for product types
    whose parser does not expose ``metadata`` (e.g. INSAR).
    """
    meta = getattr(parsed, "metadata", None)
    if meta is None:
        return None
    try:
        return (
            meta.frequencyA.value,
            meta.frequencyB.value,
            meta.polarizationA.value,
            meta.polarizationB.value,
        )
    except AttributeError:
        return None


def _granule_matches_radar_mode(
    granule_name: str,
    product_type: "NISARProductType",
    radar_mode_signatures: "set",
) -> bool:
    """Return True if a granule's radar mode matches, IGNORING track/frame/CRID.

    Used only for the GCOV/GSLC radar-mode fallback (see
    :func:`find_reference_product`): any product of the same type whose frequency
    and polarization configuration matches is an acceptable runconfig template.
    """
    parsed = _parse_granule(granule_name, product_type)
    if parsed is None or parsed.product_type != product_type:
        return False
    sig = _granule_radar_mode_signature(parsed)
    return sig is not None and sig in radar_mode_signatures


def _search_flat_bucket(
    bucket: "S3Bucket",
    product_type: "NISARProductType",
    track: int,
    frame: int,
    crids: "set[str]",
    collect_fallback: bool = False,
    radar_mode_signatures: "Optional[set]" = None,
) -> "tuple[Optional[ReferenceMatch], Optional[str], Optional[str]]":
    """Search a non-date-path (DAAC) bucket in ONE streaming pass.

    Returns ``(exact_match, track_crid_fallback, radar_mode_fallback)``:
    - ``exact_match``: first granule matching track+frame+CRID whose ``.rc.yaml``
      sidecar exists (verified). Returned immediately, stopping the listing early.
    - ``track_crid_fallback``: when ``collect_fallback`` is set and no exact
      match was found, the FIRST granule matching track+CRID only (frame ignored).
    - ``radar_mode_fallback``: when ``radar_mode_signatures`` is given, the FIRST
      granule of the same type whose radar mode matches (track/frame/CRID ignored).
    Neither fallback's sidecar is verified here (the caller does so only if used).

    A single listing serves all three, so enabling fallbacks never re-lists.
    """
    from . import s3_search

    fallback: Optional[str] = None
    radar_fallback: Optional[str] = None
    try:
        for granule_name in s3_search.iter_granules_from_bucket(
                bucket, product_type, partial_prefixes=None, date_path=None):
            if _granule_matches(granule_name, product_type, track, frame, crids):
                if s3_search.verify_granule_file_exists(
                        bucket, product_type, granule_name, RUNCONFIG_EXTENSION, date_path=None):
                    logger.info("Found reference product %s in %s", granule_name, bucket.bucket_name)
                    return ReferenceMatch(granule=granule_name, bucket=bucket, date_path=None), None, None
                logger.debug(
                    "Granule %s matched in %s but %s sidecar missing",
                    granule_name, bucket.bucket_name, RUNCONFIG_EXTENSION)
                continue
            if (collect_fallback and fallback is None
                    and _granule_matches_track_crid(granule_name, product_type, track, crids)):
                fallback = granule_name
            if (radar_mode_signatures and radar_fallback is None
                    and _granule_matches_radar_mode(
                        granule_name, product_type, radar_mode_signatures)):
                radar_fallback = granule_name
    except Exception as exc:  # noqa: BLE001 - keep searching other buckets
        logger.warning("Error listing %s: %s", bucket.bucket_name, exc)

    return None, fallback, radar_fallback


def _search_date_path_bucket(
    bucket: "S3Bucket",
    product_type: "NISARProductType",
    track: int,
    frame: int,
    crids: "set[str]",
    collect_fallback: bool = False,
    radar_mode_signatures: "Optional[set]" = None,
) -> "tuple[Optional[ReferenceMatch], Optional[tuple[str, str]], Optional[tuple[str, str]]]":
    """Search a date-path (JPL) bucket newest-first in ONE walk.

    Returns ``(exact_match, track_crid_fallback, radar_mode_fallback)`` where each
    fallback is ``(granule_name, date_path)`` for, respectively, the first
    track+CRID-only match (when ``collect_fallback``) and the first radar-mode
    match (when ``radar_mode_signatures`` given), both when no exact match is
    found. The single tree walk serves all three, so fallbacks add no extra
    listing.
    """
    from . import s3_search
    from .ancillary_finder import _list_folders_at_prefix

    client = s3_search.get_s3_client_for_bucket(bucket)
    bucket_name = bucket.bucket_name

    # Base prefix without the {date_path} segment, e.g. "products/L1_L_RSLC/".
    # Filling date_path="" leaves a trailing "//"; collapse it to a single "/".
    base_prefix = bucket.path_format.format(
        level=product_type.level_tag,
        product_type=product_type.code,
        date_path="",
    ).replace("//", "/")

    fallback: Optional[tuple] = None
    radar_fallback: Optional[tuple] = None
    try:
        years = sorted(_list_folders_at_prefix(client, bucket_name, base_prefix), reverse=True)
    except Exception as exc:  # noqa: BLE001
        logger.warning("Error listing years in %s/%s: %s", bucket_name, base_prefix, exc)
        return None, None, None

    for year in years:
        year_prefix = f"{base_prefix}{year}/"
        for month in sorted(_list_folders_at_prefix(client, bucket_name, year_prefix), reverse=True):
            month_prefix = f"{year_prefix}{month}/"
            for day in sorted(_list_folders_at_prefix(client, bucket_name, month_prefix), reverse=True):
                date_path = f"{year}/{month}/{day}"
                day_prefix = f"{month_prefix}{day}/"
                for granule_name in _list_folders_at_prefix(client, bucket_name, day_prefix):
                    if _granule_matches(granule_name, product_type, track, frame, crids):
                        if s3_search.verify_granule_file_exists(
                                bucket, product_type, granule_name,
                                RUNCONFIG_EXTENSION, date_path=date_path):
                            logger.info(
                                "Found reference product %s in %s (%s)",
                                granule_name, bucket_name, date_path)
                            return ReferenceMatch(
                                granule=granule_name, bucket=bucket, date_path=date_path), None, None
                        logger.debug(
                            "Granule %s matched in %s but %s sidecar missing",
                            granule_name, bucket_name, RUNCONFIG_EXTENSION)
                        continue
                    if (collect_fallback and fallback is None
                            and _granule_matches_track_crid(
                                granule_name, product_type, track, crids)):
                        fallback = (granule_name, date_path)
                    if (radar_mode_signatures and radar_fallback is None
                            and _granule_matches_radar_mode(
                                granule_name, product_type, radar_mode_signatures)):
                        radar_fallback = (granule_name, date_path)

    return None, fallback, radar_fallback


def find_reference_product(
    product_type: "NISARProductType",
    track: int,
    frame: int,
    target_crid: str,
    buckets: List["S3Bucket"],
    allow_track_crid_fallback: bool = False,
    radar_mode_signatures: "Optional[set]" = None,
) -> Optional[ReferenceMatch]:
    """Search for ANY product matching (product_type, track, frame, target_crid).

    Searches across ALL cycles in the enumerated buckets to find a reference
    product whose full ``.rc.yaml`` runconfig can serve as a template. Handles
    both date-path (JPL) and flat (DAAC) bucket layouts.

    Fallback tiers, tried in order only when no exact (track, frame, CRID)
    reference exists in ANY bucket:

    1. ``allow_track_crid_fallback`` (RSLC only): FIRST product matching
       track + CRID only (frame ignored).
    2. ``radar_mode_signatures`` (GCOV/GSLC): FIRST product of the same type
       whose radar mode (freqA/freqB/polA/polB) matches -- track, frame and CRID
       all ignored. See :func:`radar_mode_signatures_from_metadata`.

    All candidates are captured during the same listing pass, so fallbacks never
    trigger a second scan; only the chosen candidate's ``.rc.yaml`` sidecar is
    verified afterwards (one extra ``head_object``). Earliest bucket wins.

    Args:
        product_type: NISAR product type to search for.
        track: Track number.
        frame: Frame number.
        target_crid: Target CRID to match.
        buckets: List of S3 buckets to search.
        allow_track_crid_fallback: Enable the RSLC track+CRID fallback (tier 1).
        radar_mode_signatures: Acceptable radar-mode signatures for the GCOV/GSLC
            fallback (tier 2); None or empty disables it.

    Returns:
        ReferenceMatch if found (with the ``.rc.yaml`` sidecar verified to
        exist), None otherwise.
    """
    from . import s3_search

    crids = set(acceptable_crids(target_crid))
    logger.info(
        "Searching for reference product: %s, track=%s, frame=%s, CRID in %s "
        "(track_crid_fallback=%s, radar_mode_fallback=%s)",
        product_type.code, track, frame, sorted(crids),
        allow_track_crid_fallback, bool(radar_mode_signatures))

    # Lower-priority candidates seen (earliest bucket wins), plus how to locate
    # each sidecar. For date-path buckets we also keep the date_path.
    fallback_match: Optional[ReferenceMatch] = None
    radar_mode_match: Optional[ReferenceMatch] = None

    for bucket in buckets:
        logger.debug("Searching bucket: %s", bucket.bucket_name)
        try:
            if bucket.uses_date_path:
                match, fb, rfb = _search_date_path_bucket(
                    bucket, product_type, track, frame, crids,
                    collect_fallback=allow_track_crid_fallback,
                    radar_mode_signatures=radar_mode_signatures)
                if fb is not None and fallback_match is None:
                    fallback_match = ReferenceMatch(
                        granule=fb[0], bucket=bucket, date_path=fb[1])
                if rfb is not None and radar_mode_match is None:
                    radar_mode_match = ReferenceMatch(
                        granule=rfb[0], bucket=bucket, date_path=rfb[1])
            else:
                match, fb, rfb = _search_flat_bucket(
                    bucket, product_type, track, frame, crids,
                    collect_fallback=allow_track_crid_fallback,
                    radar_mode_signatures=radar_mode_signatures)
                if fb is not None and fallback_match is None:
                    fallback_match = ReferenceMatch(
                        granule=fb, bucket=bucket, date_path=None)
                if rfb is not None and radar_mode_match is None:
                    radar_mode_match = ReferenceMatch(
                        granule=rfb, bucket=bucket, date_path=None)
        except Exception as exc:  # noqa: BLE001 - one bad bucket shouldn't abort the search
            logger.warning("Error searching bucket %s: %s", bucket.bucket_name, exc)
            continue

        if match is not None:
            return match

    # Tier 1: remembered track+CRID fallback (RSLC).
    if fallback_match is not None:
        if s3_search.verify_granule_file_exists(
                fallback_match.bucket, product_type, fallback_match.granule,
                RUNCONFIG_EXTENSION, date_path=fallback_match.date_path):
            logger.info(
                "Using track+CRID fallback reference %s in %s",
                fallback_match.granule, fallback_match.bucket.bucket_name)
            return fallback_match
        logger.debug(
            "Fallback candidate %s has no %s sidecar",
            fallback_match.granule, RUNCONFIG_EXTENSION)

    # Tier 2: remembered radar-mode fallback (GCOV/GSLC).
    if radar_mode_match is not None:
        if s3_search.verify_granule_file_exists(
                radar_mode_match.bucket, product_type, radar_mode_match.granule,
                RUNCONFIG_EXTENSION, date_path=radar_mode_match.date_path):
            logger.info(
                "Using radar-mode fallback reference %s in %s",
                radar_mode_match.granule, radar_mode_match.bucket.bucket_name)
            return radar_mode_match
        logger.debug(
            "Radar-mode fallback candidate %s has no %s sidecar",
            radar_mode_match.granule, RUNCONFIG_EXTENSION)

    logger.info("No reference product found")
    return None


def download_reference_runconfig(
    match: ReferenceMatch,
    product_type: "NISARProductType",
    dest_dir: str,
) -> dict:
    """Download and parse the reference product's full ``.rc.yaml`` runconfig.

    Args:
        match: The located reference product.
        product_type: NISAR product type (for building the sidecar URL).
        dest_dir: Local directory to download the sidecar into.

    Returns:
        dict: The parsed runconfig (top-level ``{"runconfig": {...}}``).

    Raises:
        ClientError: If the S3 download fails.
        yaml.YAMLError: If the sidecar is not valid YAML.
    """
    from . import s3_search

    url = s3_search.build_granule_file_url(
        match.bucket, product_type, match.granule,
        RUNCONFIG_EXTENSION, date_path=match.date_path)
    logger.info("Downloading reference runconfig from %s", url)
    local_path = s3_search.download_url(url, dest_dir)

    with open(local_path, "r") as f:
        runconfig = yaml.safe_load(f)

    logger.info("Parsed reference runconfig from %s", match.granule)
    return runconfig


# Maps AncillaryFiles dataclass fields to dynamic_ancillary_file_group keys.
# dem_file / *_description and water-mask entries are intentionally left as the
# reference provides them.
_ANCILLARY_FIELD_TO_RUNCONFIG_KEY = {
    "orbit_ephemeris": "orbit",
    "radar_pointing": "pointing",
    "external_calibration": "external_calibration",
    "internal_calibration": "internal_calibration",
    "antenna_pattern": "antenna_pattern",
    "corner_reflector": "corner_reflector_file",
}


def apply_direct_reference_overrides(
    runconfig: dict,
    product,
    ancillary_files: Optional["AncillaryFiles"] = None,
) -> dict:
    """Overwrite the product-agnostic acquisition fields of a reference runconfig.

    Starting from a reference product's full runconfig, overwrite only the
    fields that differ for the new acquisition and are common to every product
    type:

    - ``geometry.cycle_number`` / ``relative_orbit_number`` / ``frame_number`` /
      ``track_frame_polygon`` -- always refreshed to the product's own
      track/frame/cycle. This matters because a reference can come from a
      different cycle (exact match) or even a different frame (RSLC track+CRID
      fallback), so its geometry does not describe the product being generated.
      Only applied when the reference has a ``geometry`` group (single-cycle
      products do; INSAR products do not).
    - ``primary_executable.partial_granule_id`` -- reprefixed to the product's
      own identifier prefix.
    - ``primary_executable.product_accuracy`` -- the product's computed accuracy.

    Product-specific fields are NOT touched here -- they are set by the
    product-specific override framework (the single source of truth shared with
    the Step 1.2 path):

    - ``input_file_group`` (RSLC RRSD list; INSAR reference/secondary RSLC).
    - ``processing.output_grid`` and the flat ``dynamic_ancillary_file_group``
      calibration/orbit keys -- RSLC only (:class:`FocusWorkflow`); writing them
      unconditionally here produced schema-invalid INSAR runconfigs.

    All other groups and keys are preserved verbatim.

    Args:
        runconfig: Parsed reference runconfig (``{"runconfig": {"groups": ...}}``).
        product: The product being generated (single or pairwise).
        ancillary_files: Ancillary files found for this product, if any. Only its
            computed ``product_accuracy`` is used here.

    Returns:
        dict: A deep-copied runconfig with the overrides applied.
    """
    result = copy.deepcopy(runconfig)

    rc = result.get("runconfig", result)
    groups = rc.get("groups", rc)

    # --- geometry: cycle / track / frame / polygon ----------------------- #
    # Only single-cycle products carry a geometry group; INSAR does not, so we
    # refresh in place rather than creating one.
    if "geometry" in groups:
        geometry = groups["geometry"]
        if hasattr(product, "cycles"):
            geometry["cycle_number"] = product.cycles[0]
        elif hasattr(product, "cycle"):
            geometry["cycle_number"] = product.cycle
        if getattr(product, "track", None) is not None:
            geometry["relative_orbit_number"] = product.track
        if getattr(product, "frame", None) is not None:
            geometry["frame_number"] = product.frame
        pass_dir = getattr(product, "pass_direction", None)
        if pass_dir is not None:
            # Runconfig geometry uses the full word; product carries "A"/"D".
            geometry["orbit_direction"] = {
                "A": "Ascending", "D": "Descending"}.get(pass_dir, pass_dir)
        polygon = _track_frame_polygon(product)
        if polygon is not None:
            geometry["track_frame_polygon"] = polygon

    # Accuracy computed for THIS product from its found ancillary files (lowest
    # of OE/RP precision), as the single-char token ("P"/"M"/"N"/"F"). None when
    # no ancillary accuracy was determined -> leave the reference values as-is.
    accuracy = None
    if ancillary_files is not None and ancillary_files.product_accuracy is not None:
        accuracy = ancillary_files.product_accuracy.value

    # --- primary_executable.partial_granule_id --------------------------- #
    # The accuracy field is refreshed here too: the reference's id embeds its own
    # accuracy (e.g. "N"), which must track the product's.
    pe = groups.get("primary_executable")
    if isinstance(pe, dict):
        new_pgid = _reprefixed_partial_granule_id(
            pe.get("partial_granule_id"), product, product_accuracy=accuracy)
        if new_pgid is not None:
            pe["partial_granule_id"] = new_pgid

    # --- primary_executable.product_accuracy ----------------------------- #
    # The reference template carries its own accuracy (e.g. "N"); overwrite it
    # with the product's computed accuracy.
    if accuracy is not None:
        if not isinstance(pe, dict):
            pe = groups.setdefault("primary_executable", {})
        pe["product_accuracy"] = accuracy

    return result


def _format_output_grid_time(t):
    """Normalize an output_grid time to match the reference .rc.yaml convention.

    Reference sidecars store the time as a YAML timestamp truncated to whole
    seconds and rendered ``2026-07-26T00:32:33Z`` (see ``dump_runconfig_yaml``
    for the ``T...Z`` representer). Here we only drop sub-second precision and
    timezone so serialization is deterministic; a datetime stays a datetime so
    the YAML timestamp tag (not a quoted string) is emitted. Passthrough for
    non-datetime values.
    """
    if isinstance(t, datetime):
        return t.replace(microsecond=0, tzinfo=None)
    return t


def _track_frame_polygon(product) -> Optional[str]:
    """Return the product's track-frame footprint as a GeoJSON string, or None.

    Mirrors ``runconfig_builder.populate_common_parameters``: serialize the
    track-frame DB row's geometry via ``__geo_interface__``.
    """
    import json

    tf = getattr(product, "track_frame_db_info", None)
    if tf is None:
        return None
    try:
        geom = tf.geometry
        if hasattr(geom, "__geo_interface__"):
            return json.dumps(geom.__geo_interface__)
        return str(geom)
    except Exception as exc:  # noqa: BLE001
        logger.warning("Could not serialize track-frame polygon: %s", exc)
        return None


def _reprefixed_partial_granule_id(
    reference_pgid, product, product_accuracy: Optional[str] = None
) -> Optional[str]:
    """Replace a reference partial_granule_id's identifier prefix with the product's.

    Layout-agnostic: the product supplies its own identifier prefix via
    ``get_partial_granule_name()`` (which ends with ``_``). The number of prefix
    tokens is taken from that prefix -- 8 for single products
    (``NISAR_L1_PR_RSLC_{cycle}_{track}_{pass}_{frame}_``) and 9 for INSAR
    (``..._{refcycle}_{track}_{pass}_{frame}_{seccycle}_``). Because the reference
    is the same product type, its first ``n`` tokens are the same identifier
    slots; we drop them and splice ``prefix + reference_tail``, keeping the
    reference's template tail (mode/pol/times/CRID/accuracy/coverage/counter).

    Returns None when there is no reference value, the product can't produce a
    prefix, or the reference has no tail beyond the prefix.

    The full-granule accuracy token is always at overall index ``len(tokens) - 4``
    (accuracy, coverage, processing-location, counter). When ``product_accuracy``
    is given it overwrites that token so the id no longer carries the reference's
    accuracy (e.g. ``N``).
    """
    if not isinstance(reference_pgid, str) or not reference_pgid:
        return None
    if not hasattr(product, "get_partial_granule_name"):
        return None

    prefix = product.get_partial_granule_name()  # trailing "_" included
    # Prefix token count: "A_B_C_" -> ["A","B","C",""] -> 3 identifier tokens.
    n_prefix = len(prefix.split("_")) - 1

    tokens = reference_pgid.split("_")
    if len(tokens) <= n_prefix:  # need at least one token after the prefix
        return None

    tail_tokens = tokens[n_prefix:]
    # Overwrite the accuracy field (overall index len(tokens) - 4) when a computed
    # accuracy is available. Its position within the tail is that same index minus
    # the prefix length.
    accuracy_tail_idx = len(tokens) - 4 - n_prefix
    if product_accuracy is not None and 0 <= accuracy_tail_idx < len(tail_tokens):
        tail_tokens[accuracy_tail_idx] = product_accuracy
    tail = "_".join(tail_tokens)
    return f"{prefix}{tail}"


def extract_template_from_metadata(met_json_path: str) -> dict:
    """Extract runconfig template from product metadata.

    Loads the .met.json file and extracts the
    runconfig.processing.parameter_set_content field.

    NOTE: This field is empirically a *sparse* delta and is not used by the
    direct-reference path (see module docstring); prefer
    :func:`download_reference_runconfig`. Retained for completeness.

    Args:
        met_json_path: Local path to the .met.json file

    Returns:
        dict: The extracted runconfig template

    Raises:
        KeyError: If the expected metadata structure is not found
        FileNotFoundError: If the metadata file doesn't exist
        json.JSONDecodeError: If the JSON is invalid
    """
    logger.info(f"Extracting template from metadata: {met_json_path}")

    with open(met_json_path, 'r') as f:
        metadata = json.load(f)

    try:
        template = metadata['runconfig']['processing']['parameter_set_content']
        logger.info("Successfully extracted template from metadata")
        return template

    except KeyError as e:
        logger.error(f"Required metadata key not found: {e}")
        raise KeyError(
            f"Could not find 'runconfig.processing.parameter_set_content' in metadata file"
        ) from e
