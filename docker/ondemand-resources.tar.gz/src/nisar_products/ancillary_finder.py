"""NISAR ancillary file finder for runconfig generation.

This module provides functions to locate ancillary files from the
s3://nisar-ops-lts-fwd bucket based on product time ranges. Ancillary files
include orbit ephemeris, radar pointing, calibration files, and more.

Time-Independent Files (find once per batch):
    - Corner Reflector (.csv)
    - External Calibration (.yaml)
    - Internal Calibration (.h5)
    - Antenna Pattern (.h5)

Time-Dependent Files (find per unique time range):
    - Orbit Ephemeris (.xml): POE > MOE > NOE > FOE
    - Radar Pointing (.xml): PRP > NRP > FRP (no MRP)
    - Total Electron Content (.json)

Product Accuracy Determination:
    Final accuracy = min(OE_accuracy, RP_accuracy)
    Priority order: P (Precise) < M (Medium) < N (Near Real-Time) < F (Forecast)
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import List, Optional, Tuple

from botocore.exceptions import ClientError

from . import s3_search
from .enums import ProductAccuracy

logger = logging.getLogger(__name__)

# Ancillary files bucket (separate from product buckets)
ANCILLARY_BUCKET_NAME = "nisar-ops-lts-fwd"

# ECMWF troposphere weather-model bucket + grid. Files live under
# preprocessed/YYYYMMDD/<grid>/ as ECMWF_TROP_<YYYYMMDDHH00>_<...>_1.nc, four
# per day at the synoptic hours 00/06/12/18Z. The grid subfolder is fixed.
ECMWF_BUCKET_NAME = "nisar-ecmwf"
ECMWF_GRID = "A2A3"

# Search priority for orbit ephemeris files (highest to lowest accuracy)
OE_PRIORITY = [ProductAccuracy.P, ProductAccuracy.M, ProductAccuracy.N, ProductAccuracy.F]

# Search priority for radar pointing files (highest to lowest accuracy)
# Note: MRP files don't exist per documentation
RP_PRIORITY = [ProductAccuracy.P, ProductAccuracy.N, ProductAccuracy.F]


@dataclass
class AncillaryFiles:
    """Container for ancillary files needed by NISAR products."""

    # Time-independent files
    corner_reflector: Optional[str] = None          # .csv
    external_calibration: Optional[str] = None      # .yaml
    internal_calibration: Optional[str] = None      # .h5
    antenna_pattern: Optional[str] = None           # .h5

    # Time-dependent files (single products)
    orbit_ephemeris: Optional[str] = None           # .xml
    radar_pointing: Optional[str] = None            # .xml
    total_electron_content: Optional[str] = None    # .json

    # Time-dependent files for pairwise products (INSAR only)
    # Reference time range (t_0)
    orbit_ephemeris_t0: Optional[str] = None
    total_electron_content_t0: Optional[str] = None
    ecmwf_trop_t0: Optional[str] = None

    # Secondary time range (t_1)
    orbit_ephemeris_t1: Optional[str] = None
    ecmwf_trop_t1: Optional[str] = None

    # Derived metadata
    product_accuracy: Optional[ProductAccuracy] = None
    oe_accuracy: Optional[ProductAccuracy] = None
    rp_accuracy: Optional[ProductAccuracy] = None

    # Timestamps for time-dependent files
    oe_start_time: Optional[datetime] = None
    oe_end_time: Optional[datetime] = None
    rp_start_time: Optional[datetime] = None
    rp_end_time: Optional[datetime] = None
    tec_start_time: Optional[datetime] = None
    tec_end_time: Optional[datetime] = None


def _extract_time_ranges_from_product_node(product_node: dict) -> List[Tuple[datetime, datetime]]:
    """Extract time ranges from product node JSON (with lineage).

    For single products: Returns [(start_time, end_time)]
    For pairwise products: Returns [(ref_start, ref_end), (sec_start, sec_end)]

    Args:
        product_node: Product node dict from backprocessor JSON (includes inputs)

    Returns:
        List of (start_time, end_time) tuples

    Raises:
        ValueError: If time ranges cannot be extracted
    """
    from .metadata import parse_single_granule, parse_insar_granule

    product_type = product_node.get("product_type")

    # Check if this is an INSAR product (has inputs list with 2 RSLCs)
    inputs = product_node.get("inputs", [])

    if len(inputs) == 2 and all(inp.get("product_type") == "RSLC" for inp in inputs):
        # INSAR product - extract time ranges from both input RSLCs
        time_ranges = []

        for inp in inputs:
            matches = inp.get("matches", [])
            if matches:
                # Parse the first match granule name
                granule = matches[0].get("granule")
                if granule:
                    parsed = parse_single_granule(granule)
                    time_ranges.append((parsed.metadata.start_time, parsed.metadata.end_time))
                else:
                    raise ValueError(f"No granule name in input RSLC match")
            else:
                raise ValueError(f"No matches for input RSLC in INSAR product")

        if len(time_ranges) != 2:
            raise ValueError(f"Expected 2 time ranges for INSAR product, got {len(time_ranges)}")

        return time_ranges

    else:
        # Single product - get time range from granule or estimate
        matches = product_node.get("matches", [])
        if matches:
            granule = matches[0].get("granule")
            if granule:
                parsed = parse_single_granule(granule)
                return [(parsed.metadata.start_time, parsed.metadata.end_time)]

        # No matches - estimate from cycle time
        from . import references
        identifiers = product_node.get("identifiers", {})
        cycle = identifiers.get("cycle")
        track = identifiers.get("track")
        frame = identifiers.get("frame")

        if cycle and track and frame:
            start, end = references.estimated_time_range(track, frame, cycle)
            return [(start, end)]

        raise ValueError(f"Cannot extract time range from product node")


def _parse_ancillary_timestamps(filename: str) -> Tuple[datetime, datetime]:
    """Extract start/end times from ancillary filename.

    Ancillary filenames follow the pattern:
    NISAR_ANC_X_PR_YYY_YYYYMMDDTHHMMSS_YYYYMMDDTHHMMSS_YYYYMMDDTHHMMSS[_counter]

    The second timestamp is the start_time and the third is the end_time.

    Args:
        filename: The ancillary file basename (with or without extension).

    Returns:
        Tuple of (start_time, end_time) as datetime objects.

    Raises:
        ValueError: If the filename doesn't contain valid timestamps.
    """
    # Remove extension if present
    basename = filename.rsplit('.', 1)[0]

    # Pattern to match timestamps in format YYYYMMDDTHHMMSS
    timestamp_pattern = r'(\d{8}T\d{6})'
    matches = re.findall(timestamp_pattern, basename)

    if len(matches) < 3:
        raise ValueError(
            f"Expected at least 3 timestamps in ancillary filename, found {len(matches)}: {filename}")

    # Second timestamp = start_time, third timestamp = end_time
    start_str = matches[1]
    end_str = matches[2]

    start_time = datetime.strptime(start_str, "%Y%m%dT%H%M%S")
    end_time = datetime.strptime(end_str, "%Y%m%dT%H%M%S")

    return start_time, end_time


def _check_time_coverage(
    file_start: datetime,
    file_end: datetime,
    product_start: datetime,
    product_end: datetime,
    margin_minutes: int
) -> bool:
    """Check if a file's time range covers the product's time range with margin.

    Args:
        file_start: Start time of the ancillary file.
        file_end: End time of the ancillary file.
        product_start: Start time of the product.
        product_end: End time of the product.
        margin_minutes: Required margin in minutes on both sides.

    Returns:
        True if the file covers (product_start - margin) to (product_end + margin).
    """
    margin = timedelta(minutes=margin_minutes)
    required_start = product_start - margin
    required_end = product_end + margin

    return file_start <= required_start and file_end >= required_end


def _extract_counter_from_folder(folder_name: str) -> int:
    """Parse counter from folder names like NISAR_ANC_CORNER_REFLECTORS_007.

    Args:
        folder_name: The folder basename.

    Returns:
        The counter as an integer, or 0 if no counter found.
    """
    # Look for trailing digits after underscore, optionally with letter prefix (e.g., _s015)
    match = re.search(r'_[a-z]?(\d+)$', folder_name, re.IGNORECASE)
    if match:
        return int(match.group(1))
    return 0


def _list_folders_at_prefix(client, bucket_name: str, prefix: str) -> List[str]:
    """List folder names (common prefixes) at a given S3 prefix.

    Args:
        client: Boto3 S3 client.
        bucket_name: S3 bucket name.
        prefix: S3 prefix to search under.

    Returns:
        List of folder basenames (not full paths).
    """
    folders = []
    paginator = client.get_paginator("list_objects_v2")

    try:
        pages = paginator.paginate(
            Bucket=bucket_name,
            Prefix=prefix,
            Delimiter="/"
        )
        for page in pages:
            for common in page.get("CommonPrefixes", []):
                folder_path = common["Prefix"].rstrip("/")
                folder_basename = folder_path.rsplit("/", 1)[-1]
                folders.append(folder_basename)
    except ClientError as exc:
        code = exc.response.get("Error", {}).get("Code", "")
        if code in s3_search._ACCESS_ERROR_CODES:
            raise
        logger.warning("Failed to list folders at %s/%s: %s", bucket_name, prefix, exc)

    return folders


def _find_file_in_folder(
    client,
    bucket_name: str,
    folder_prefix: str,
    extension: str,
    exclude_suffixes: Optional[Tuple[str, ...]] = None,
) -> Optional[str]:
    """Find a file with the given extension in a specific S3 folder.

    Verifies that the file actually exists (not just listed in the directory).

    Args:
        client: Boto3 S3 client.
        bucket_name: S3 bucket name.
        folder_prefix: Full S3 prefix to the folder (with trailing slash).
        extension: File extension to search for (e.g., '.csv', '.yaml').
        exclude_suffixes: Optional key suffixes to skip even though they match
            ``extension``. Needed where sidecars share the extension (e.g. TEC
            folders hold ``.context.json`` / ``.dataset.json`` / ``.met.json``
            alongside the real ``.json`` data file).

    Returns:
        Full s3:// URL to the file, or None if not found or deleted.
    """
    try:
        response = client.list_objects_v2(
            Bucket=bucket_name,
            Prefix=folder_prefix,
            MaxKeys=100
        )

        for obj in response.get("Contents", []):
            key = obj["Key"]
            if exclude_suffixes and key.endswith(exclude_suffixes):
                continue
            if key.endswith(extension):
                # Verify file actually exists with head_object
                try:
                    client.head_object(Bucket=bucket_name, Key=key)
                    return f"s3://{bucket_name}/{key}"
                except ClientError as head_exc:
                    head_code = head_exc.response.get("Error", {}).get("Code", "")
                    if head_code == "404":
                        logger.debug(
                            "File %s/%s listed but not accessible (404), skipping",
                            bucket_name, key)
                        continue
                    # For other errors (permissions, etc.), propagate if access error
                    if head_code in s3_search._ACCESS_ERROR_CODES:
                        raise
                    logger.debug(
                        "Failed to verify file %s/%s: %s",
                        bucket_name, key, head_exc)
                    continue

    except ClientError as exc:
        code = exc.response.get("Error", {}).get("Code", "")
        if code in s3_search._ACCESS_ERROR_CODES:
            raise
        logger.debug("Failed to list folder %s/%s: %s", bucket_name, folder_prefix, exc)

    return None


def determine_product_accuracy(
    oe_accuracy: Optional[ProductAccuracy],
    rp_accuracy: Optional[ProductAccuracy]
) -> Optional[ProductAccuracy]:
    """Determine final product accuracy as the lowest of OE and RP accuracies.

    Accuracy is ordered from most precise to least: P < M < N < F
    The final product accuracy is the minimum (least precise) of the two inputs.

    Args:
        oe_accuracy: Orbit ephemeris accuracy level.
        rp_accuracy: Radar pointing accuracy level.

    Returns:
        The lowest accuracy level, or None if both inputs are None.

    Examples:
        >>> determine_product_accuracy(ProductAccuracy.P, ProductAccuracy.F)
        ProductAccuracy.F
        >>> determine_product_accuracy(ProductAccuracy.M, ProductAccuracy.N)
        ProductAccuracy.N
        >>> determine_product_accuracy(ProductAccuracy.P, ProductAccuracy.P)
        ProductAccuracy.P
    """
    if oe_accuracy is None and rp_accuracy is None:
        return None
    if oe_accuracy is None:
        return rp_accuracy
    if rp_accuracy is None:
        return oe_accuracy

    # Compare based on enum definition order (P=highest, F=lowest)
    accuracy_order = {
        ProductAccuracy.P: 0,
        ProductAccuracy.M: 1,
        ProductAccuracy.N: 2,
        ProductAccuracy.F: 3
    }

    # Return the one with higher order value (lower precision)
    if accuracy_order[oe_accuracy] > accuracy_order[rp_accuracy]:
        return oe_accuracy
    return rp_accuracy


def find_corner_reflector(client, bucket_name: str = ANCILLARY_BUCKET_NAME) -> Optional[str]:
    """Find the latest corner reflector CSV from ancillary/CORNER_REFL/.

    Searches for the highest counter in folder names like:
    NISAR_ANC_CORNER_REFLECTORS_007

    Tries folders in descending order of counter until a file is found.

    Args:
        client: Boto3 S3 client.
        bucket_name: S3 bucket name (default: nisar-ops-lts-fwd).

    Returns:
        Full s3:// URL to the .csv file, or None if not found.
    """
    prefix = "ancillary/CORNER_REFL/"
    folders = _list_folders_at_prefix(client, bucket_name, prefix)

    if not folders:
        logger.warning("No corner reflector folders found at %s/%s", bucket_name, prefix)
        return None

    # Sort folders by counter (highest first) and try each until we find a file
    folders_sorted = sorted(folders, key=_extract_counter_from_folder, reverse=True)

    for folder in folders_sorted:
        folder_prefix = f"{prefix}{folder}/"
        csv_url = _find_file_in_folder(client, bucket_name, folder_prefix, ".csv")

        if csv_url is not None:
            return csv_url

        logger.debug("No .csv file found in %s/%s, trying next folder", bucket_name, folder_prefix)

    logger.warning("No corner reflector .csv file found in any folder at %s/%s", bucket_name, prefix)
    return None


def find_external_calibration(client, bucket_name: str = ANCILLARY_BUCKET_NAME) -> Optional[str]:
    """Find the latest external calibration YAML from ancillary/LSAR_EXT_CAL/.

    Searches recursively through date directories (YYYY/MM/DD) for the latest
    date with the highest counter.

    Args:
        client: Boto3 S3 client.
        bucket_name: S3 bucket name (default: nisar-ops-lts-fwd).

    Returns:
        Full s3:// URL to the .yaml file, or None if not found.
    """
    return _find_latest_dated_ancillary(
        client, bucket_name, "ancillary/LSAR_EXT_CAL/", ".yaml", "external calibration")


def find_internal_calibration(client, bucket_name: str = ANCILLARY_BUCKET_NAME) -> Optional[str]:
    """Find the latest internal calibration H5 from ancillary/LSAR_INT_CAL/.

    Searches recursively through date directories (YYYY/MM/DD) for the latest
    date with the highest counter.

    Args:
        client: Boto3 S3 client.
        bucket_name: S3 bucket name (default: nisar-ops-lts-fwd).

    Returns:
        Full s3:// URL to the .h5 file, or None if not found.
    """
    return _find_latest_dated_ancillary(
        client, bucket_name, "ancillary/LSAR_INT_CAL/", ".h5", "internal calibration")


def find_antenna_pattern(client, bucket_name: str = ANCILLARY_BUCKET_NAME) -> Optional[str]:
    """Find the latest antenna pattern H5 from products/ANTPAT/.

    Searches recursively through date directories (YYYY/MM/DD) for the latest date.

    Args:
        client: Boto3 S3 client.
        bucket_name: S3 bucket name (default: nisar-ops-lts-fwd).

    Returns:
        Full s3:// URL to the .h5 file, or None if not found.
    """
    return _find_latest_dated_ancillary(
        client, bucket_name, "products/ANTPAT/", ".h5", "antenna pattern")


def _find_latest_dated_ancillary(
    client,
    bucket_name: str,
    base_prefix: str,
    extension: str,
    file_type: str
) -> Optional[str]:
    """Find the latest dated ancillary file with highest counter.

    Searches recursively through date directories (YYYY/MM/DD) to find the
    latest date with files, then tries folders in descending order by counter
    until a file is actually found (not just a folder).

    Args:
        client: Boto3 S3 client.
        bucket_name: S3 bucket name.
        base_prefix: Base S3 prefix (e.g., 'ancillary/LSAR_EXT_CAL/').
        extension: File extension to search for (e.g., '.yaml', '.h5').
        file_type: Human-readable file type for logging.

    Returns:
        Full s3:// URL to the file, or None if not found.
    """
    # List year directories
    year_folders = _list_folders_at_prefix(client, bucket_name, base_prefix)

    if not year_folders:
        logger.warning("No year folders found for %s at %s/%s", file_type, bucket_name, base_prefix)
        return None

    # Sort years in descending order
    year_folders.sort(reverse=True)

    # Search from most recent year backwards
    for year in year_folders:
        year_prefix = f"{base_prefix}{year}/"
        month_folders = _list_folders_at_prefix(client, bucket_name, year_prefix)

        if not month_folders:
            continue

        # Sort months in descending order
        month_folders.sort(reverse=True)

        for month in month_folders:
            month_prefix = f"{year_prefix}{month}/"
            day_folders = _list_folders_at_prefix(client, bucket_name, month_prefix)

            if not day_folders:
                continue

            # Sort days in descending order
            day_folders.sort(reverse=True)

            for day in day_folders:
                day_prefix = f"{month_prefix}{day}/"
                file_folders = _list_folders_at_prefix(client, bucket_name, day_prefix)

                if not file_folders:
                    continue

                # Sort folders by counter (highest first) and try each until we find a file
                file_folders_sorted = sorted(file_folders, key=_extract_counter_from_folder, reverse=True)

                for folder in file_folders_sorted:
                    folder_prefix = f"{day_prefix}{folder}/"

                    # Find file with correct extension
                    file_url = _find_file_in_folder(client, bucket_name, folder_prefix, extension)

                    if file_url is not None:
                        return file_url

                    logger.debug(
                        "No %s file found in %s/%s, trying next folder",
                        file_type, bucket_name, folder_prefix)

    logger.warning("No %s file found at %s/%s", file_type, bucket_name, base_prefix)
    return None


def find_orbit_ephemeris(
    client,
    start_time: datetime,
    end_time: datetime,
    margin_minutes: int = 3,
    bucket_name: str = ANCILLARY_BUCKET_NAME
) -> Tuple[Optional[str], Optional[ProductAccuracy], Optional[datetime], Optional[datetime]]:
    """Find orbit ephemeris file covering the product time range with margin.

    Searches in priority order: POE → MOE → NOE → FOE
    Returns the first file found that covers (start_time - margin) to (end_time + margin).

    Args:
        client: Boto3 S3 client.
        start_time: Product start time.
        end_time: Product end time.
        margin_minutes: Required margin in minutes on both sides (default: 3).
        bucket_name: S3 bucket name (default: nisar-ops-lts-fwd).

    Returns:
        Tuple of (file_url, accuracy, file_start_time, file_end_time) or (None, None, None, None).
    """
    for accuracy in OE_PRIORITY:
        file_type = f"{accuracy.value}OE"
        prefix = f"products/{file_type}/"

        result = _find_time_dependent_file(
            client, bucket_name, prefix, start_time, end_time, margin_minutes, ".xml", file_type)

        if result is not None:
            file_url, file_start, file_end = result
            return file_url, accuracy, file_start, file_end

    logger.info(
        "No orbit ephemeris file found covering %s to %s with %d-minute margin",
        start_time, end_time, margin_minutes)
    return None, None, None, None


def find_radar_pointing(
    client,
    start_time: datetime,
    end_time: datetime,
    margin_minutes: int = 3,
    bucket_name: str = ANCILLARY_BUCKET_NAME
) -> Tuple[Optional[str], Optional[ProductAccuracy], Optional[datetime], Optional[datetime]]:
    """Find radar pointing file covering the product time range with margin.

    Searches in priority order: PRP → NRP → FRP (MRP files don't exist)
    Returns the first file found that covers (start_time - margin) to (end_time + margin).

    Args:
        client: Boto3 S3 client.
        start_time: Product start time.
        end_time: Product end time.
        margin_minutes: Required margin in minutes on both sides (default: 3).
        bucket_name: S3 bucket name (default: nisar-ops-lts-fwd).

    Returns:
        Tuple of (file_url, accuracy, file_start_time, file_end_time) or (None, None, None, None).
    """
    for accuracy in RP_PRIORITY:
        file_type = f"{accuracy.value}RP"
        prefix = f"products/{file_type}/"

        result = _find_time_dependent_file(
            client, bucket_name, prefix, start_time, end_time, margin_minutes, ".xml", file_type)

        if result is not None:
            file_url, file_start, file_end = result
            return file_url, accuracy, file_start, file_end

    logger.info(
        "No radar pointing file found covering %s to %s with %d-minute margin",
        start_time, end_time, margin_minutes)
    return None, None, None, None


def find_total_electron_content(
    client,
    start_time: datetime,
    end_time: datetime,
    margin_minutes: int = 3,
    bucket_name: str = ANCILLARY_BUCKET_NAME
) -> Tuple[Optional[str], Optional[datetime], Optional[datetime]]:
    """Find TEC file covering the product time range with margin.

    Args:
        client: Boto3 S3 client.
        start_time: Product start time.
        end_time: Product end time.
        margin_minutes: Required margin in minutes on both sides (default: 3).
        bucket_name: S3 bucket name (default: nisar-ops-lts-fwd).

    Returns:
        Tuple of (file_url, file_start_time, file_end_time) or (None, None, None).
    """
    prefix = "products/TEC/"
    # A TEC folder holds the real data file (``<granule>.json``) alongside JSON
    # sidecars that also end in ``.json``; exclude those so we return the data file.
    result = _find_time_dependent_file(
        client, bucket_name, prefix, start_time, end_time, margin_minutes, ".json",
        "TEC",
        exclude_suffixes=(".context.json", ".dataset.json", ".met.json"))

    if result is not None:
        return result

    logger.info(
        "No TEC file found covering %s to %s with %d-minute margin",
        start_time, end_time, margin_minutes)
    return None, None, None


# Matches ECMWF_TROP_<YYYYMMDDHH00>_<YYYYMMDDHH00>_<n>.nc; captures the first
# (reference) synoptic timestamp.
_ECMWF_TROP_RE = re.compile(r"ECMWF_TROP_(\d{12})_\d{12}_\d+\.nc$")


def find_ecmwf_trop(
    client,
    acquisition_start: datetime,
    bucket_name: str = ECMWF_BUCKET_NAME,
    grid: str = ECMWF_GRID,
) -> Optional[str]:
    """Find the ECMWF troposphere weather-model file for an acquisition.

    ECMWF files are produced four times a day (synoptic hours 00/06/12/18Z) and
    stored under ``preprocessed/<YYYYMMDD>/<grid>/`` keyed by the acquisition
    date. The correct file is the synoptic snapshot at or immediately before the
    acquisition start time (the most recent model state preceding the pass).

    Args:
        client: Boto3 S3 client.
        acquisition_start: RSLC acquisition start time (reference or secondary).
        bucket_name: ECMWF bucket name (default: nisar-ecmwf).
        grid: Grid subfolder (default: A2A3).

    Returns:
        Full ``s3://`` URL to the ``.nc`` file, or None if none found on/before
        the acquisition time.
    """
    date_str = f"{acquisition_start.year:04d}{acquisition_start.month:02d}{acquisition_start.day:02d}"
    prefix = f"preprocessed/{date_str}/{grid}/"

    # Collect every ECMWF_TROP file in the day's folder, parsing its synoptic
    # timestamp from the name.
    candidates: List[Tuple[datetime, str]] = []  # (synoptic_time, s3_url)
    paginator = client.get_paginator("list_objects_v2")
    try:
        for page in paginator.paginate(Bucket=bucket_name, Prefix=prefix):
            for obj in page.get("Contents", []):
                key = obj["Key"]
                match = _ECMWF_TROP_RE.search(key)
                if not match:
                    continue
                try:
                    synoptic = datetime.strptime(match.group(1), "%Y%m%d%H%M")
                except ValueError:
                    logger.debug("Unparseable ECMWF timestamp in %s", key)
                    continue
                candidates.append((synoptic, f"s3://{bucket_name}/{key}"))
    except ClientError as exc:
        code = exc.response.get("Error", {}).get("Code", "")
        if code in s3_search._ACCESS_ERROR_CODES:
            raise
        logger.warning(
            "Failed to list ECMWF troposphere files at %s/%s: %s",
            bucket_name, prefix, exc)
        return None

    if not candidates:
        logger.warning(
            "No ECMWF troposphere files found at %s/%s", bucket_name, prefix)
        return None

    # Choose the latest synoptic snapshot at or before the acquisition start.
    at_or_before = [(t, url) for t, url in candidates if t <= acquisition_start]
    if not at_or_before:
        logger.warning(
            "No ECMWF troposphere file at or before %s in %s/%s "
            "(earliest available: %s)",
            acquisition_start, bucket_name, prefix, min(candidates)[0])
        return None

    synoptic, url = max(at_or_before, key=lambda pair: pair[0])
    logger.debug(
        "Selected ECMWF troposphere file %s (synoptic %s) for acquisition %s",
        url, synoptic, acquisition_start)
    return url


def _find_time_dependent_file(
    client,
    bucket_name: str,
    base_prefix: str,
    start_time: datetime,
    end_time: datetime,
    margin_minutes: int,
    extension: str,
    file_type: str,
    exclude_suffixes: Optional[Tuple[str, ...]] = None,
) -> Optional[Tuple[str, datetime, datetime]]:
    """Find a time-dependent ancillary file that covers the required time range.

    Searches through candidate folders and verifies files actually exist before
    checking time coverage.

    Args:
        client: Boto3 S3 client.
        bucket_name: S3 bucket name.
        base_prefix: Base S3 prefix (e.g., 'products/POE/').
        start_time: Product start time.
        end_time: Product end time.
        margin_minutes: Required margin in minutes.
        extension: File extension (e.g., '.xml', '.json').
        file_type: Human-readable file type for logging.
        exclude_suffixes: Key suffixes to skip even though they match
            ``extension`` (forwarded to :func:`_find_file_in_folder`).

    Returns:
        Tuple of (file_url, file_start_time, file_end_time) or None if not found.
    """
    # Generate date paths to search (add margin to account for file storage dates)
    margin = timedelta(minutes=margin_minutes)
    search_start = start_time - margin - timedelta(days=1)  # Extra day buffer for storage
    search_end = end_time + margin + timedelta(days=1)

    date_paths = _generate_date_paths(search_start, search_end)

    for date_path in date_paths:
        prefix = f"{base_prefix}{date_path}/"
        folders = _list_folders_at_prefix(client, bucket_name, prefix)

        for folder in folders:
            # Parse timestamps from folder name first (to avoid unnecessary S3 calls)
            try:
                file_start, file_end = _parse_ancillary_timestamps(folder)

                # Check if file would cover required time range before checking if it exists
                if not _check_time_coverage(file_start, file_end, start_time, end_time, margin_minutes):
                    continue

            except ValueError as exc:
                logger.debug("Failed to parse timestamps from %s: %s", folder, exc)
                continue

            # Only check for file existence if time coverage is satisfied
            folder_prefix = f"{prefix}{folder}/"
            file_url = _find_file_in_folder(
                client, bucket_name, folder_prefix, extension,
                exclude_suffixes=exclude_suffixes)

            if file_url is not None:
                logger.debug(
                    "Found %s file: %s (covers %s to %s)",
                    file_type, file_url, file_start, file_end)
                return file_url, file_start, file_end

            logger.debug(
                "Folder %s/%s meets time requirements but file not found, continuing search",
                bucket_name, folder_prefix)

    return None


def _generate_date_paths(start_date: datetime, end_date: datetime) -> List[str]:
    """Generate list of YYYY/MM/DD date paths between start and end dates.

    Args:
        start_date: Start date (inclusive).
        end_date: End date (inclusive).

    Returns:
        List of date path strings in format YYYY/MM/DD.
    """
    paths = []
    current = start_date.date()
    end = end_date.date()

    while current <= end:
        paths.append(f"{current.year:04d}/{current.month:02d}/{current.day:02d}")
        current += timedelta(days=1)

    return paths


def find_ancillary_files_for_product(
    product,
    margin_minutes: int = 3,
    bucket_name: str = ANCILLARY_BUCKET_NAME,
    find_time_independent: bool = True
) -> AncillaryFiles:
    """Find all ancillary files needed for a NISAR product.

    This is the main entry point for finding ancillary files. It finds both
    time-independent files (corner reflector, calibrations, antenna pattern)
    and time-dependent files (orbit ephemeris, radar pointing, TEC) based on
    the product's time range.

    Args:
        product: A NisarSingleProduct instance with time range information.
        margin_minutes: Required margin in minutes for time-dependent files (default: 3).
        bucket_name: S3 bucket name (default: nisar-ops-lts-fwd).
        find_time_independent: Whether to find time-independent files (default: True).
            Set to False if these have already been found and cached.

    Returns:
        AncillaryFiles dataclass with populated file URLs and metadata.

    Example:
        >>> from nisar_products.products.single import NisarRSLC
        >>>
        >>> rslc = NisarRSLC(cycle=25, track=170, frame=58, composite_release_id="P05023")
        >>> ancillary = find_ancillary_files_for_product(rslc)
        >>> print(ancillary.orbit_ephemeris)
        s3://nisar-ops-lts-fwd/products/POE/...
        >>> print(ancillary.product_accuracy)
        ProductAccuracy.P
    """
    # Get S3 client (uses default AWS credentials)
    client = s3_search.get_s3_client()

    # Extract time range from product
    start_time, end_time = product.get_time_range()

    # Initialize result container
    result = AncillaryFiles()

    # Find time-independent files (can be cached across products)
    if find_time_independent:
        result.corner_reflector = find_corner_reflector(client, bucket_name)
        result.external_calibration = find_external_calibration(client, bucket_name)
        result.internal_calibration = find_internal_calibration(client, bucket_name)
        result.antenna_pattern = find_antenna_pattern(client, bucket_name)

    # Find time-dependent files (specific to this product's time range)
    oe_url, oe_acc, oe_start, oe_end = find_orbit_ephemeris(
        client, start_time, end_time, margin_minutes, bucket_name)
    result.orbit_ephemeris = oe_url
    result.oe_accuracy = oe_acc
    result.oe_start_time = oe_start
    result.oe_end_time = oe_end

    rp_url, rp_acc, rp_start, rp_end = find_radar_pointing(
        client, start_time, end_time, margin_minutes, bucket_name)
    result.radar_pointing = rp_url
    result.rp_accuracy = rp_acc
    result.rp_start_time = rp_start
    result.rp_end_time = rp_end

    tec_url, tec_start, tec_end = find_total_electron_content(
        client, start_time, end_time, margin_minutes, bucket_name)
    result.total_electron_content = tec_url
    result.tec_start_time = tec_start
    result.tec_end_time = tec_end

    # Determine final product accuracy from OE and RP accuracies
    result.product_accuracy = determine_product_accuracy(oe_acc, rp_acc)

    return result


def find_ancillary_files_for_pairwise_product(
    product,
    product_node: dict,
    margin_minutes: int = 3,
    bucket_name: str = ANCILLARY_BUCKET_NAME,
    find_time_independent: bool = True
) -> AncillaryFiles:
    """Find ancillary files for INSAR pairwise products.

    INSAR products need:
    - OE (t_0): reference time range
    - OE (t_1): secondary time range
    - TEC (t_0): reference time range
    - ECMWF_TROP (t_0): reference time range
    - ECMWF_TROP (t_1): secondary time range

    Args:
        product: NisarPairwiseProduct instance (GUNW, RUNW, etc.)
        product_node: Product node dict from backprocessor JSON (includes inputs with time ranges)
        margin_minutes: Required margin for time-dependent files (default: 3)
        bucket_name: S3 bucket name (default: nisar-ops-lts-fwd)
        find_time_independent: Whether to find time-independent files (default: True)

    Returns:
        AncillaryFiles with dual time range fields populated
    """
    client = s3_search.get_s3_client()
    result = AncillaryFiles()

    # Get both time ranges from product_node JSON (contains input RSLCs with actual time ranges)
    time_ranges = _extract_time_ranges_from_product_node(product_node)
    if len(time_ranges) != 2:
        raise ValueError(f"Expected 2 time ranges for pairwise product, got {len(time_ranges)}")

    (ref_start, ref_end), (sec_start, sec_end) = time_ranges

    # Find time-independent files (same as single products)
    if find_time_independent:
        result.corner_reflector = find_corner_reflector(client, bucket_name)
        result.external_calibration = find_external_calibration(client, bucket_name)
        result.internal_calibration = find_internal_calibration(client, bucket_name)
        result.antenna_pattern = find_antenna_pattern(client, bucket_name)

    # Find OE for reference time range (t_0)
    oe_t0_url, oe_t0_acc, _, _ = find_orbit_ephemeris(
        client, ref_start, ref_end, margin_minutes, bucket_name)
    result.orbit_ephemeris_t0 = oe_t0_url

    # Find OE for secondary time range (t_1)
    oe_t1_url, oe_t1_acc, _, _ = find_orbit_ephemeris(
        client, sec_start, sec_end, margin_minutes, bucket_name)
    result.orbit_ephemeris_t1 = oe_t1_url

    # Product accuracy is the least precise of both OE accuracies. Reuse
    # determine_product_accuracy (explicit P<M<N<F order) rather than min() on
    # .value, which sorts strings alphabetically (F<M<N<P) and inverts precision.
    if oe_t0_acc and oe_t1_acc:
        result.product_accuracy = determine_product_accuracy(oe_t0_acc, oe_t1_acc)
        result.oe_accuracy = result.product_accuracy

    # Find TEC for reference time range (t_0)
    tec_t0_url, _, _ = find_total_electron_content(
        client, ref_start, ref_end, margin_minutes, bucket_name)
    result.total_electron_content_t0 = tec_t0_url

    # Find ECMWF_TROP for reference (t_0) and secondary (t_1). Each uses the
    # synoptic snapshot at or before its acquisition start time.
    result.ecmwf_trop_t0 = find_ecmwf_trop(client, ref_start)
    result.ecmwf_trop_t1 = find_ecmwf_trop(client, sec_start)

    return result
