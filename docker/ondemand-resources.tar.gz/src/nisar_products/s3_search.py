"""S3 bucket search and download helpers.

Adapts the credential handling and path-building machinery proven in
``scripts/localize_runconfig.py`` into a reusable module. JPL ops buckets use
default AWS credentials; DAAC buckets use a named profile (default ``daac``) with
an ``earthaccess`` fallback for temporary credentials.
"""
from __future__ import annotations

import json
import logging
import os
import subprocess
import sys
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from urllib.parse import urlparse

from .enums import BucketType, ProcessingType, S3Bucket

logger = logging.getLogger(__name__)

DAAC_PROFILE_NAME = os.environ.get("NISAR_DAAC_PROFILE", "daac")

# S3 error codes that indicate a credential/permission problem rather than a
# genuinely absent object. These must surface (not be swallowed as "no match").
_ACCESS_ERROR_CODES = frozenset({
    "AccessDenied", "ExpiredToken", "ExpiredTokenException", "InvalidAccessKeyId",
    "InvalidToken", "SignatureDoesNotMatch", "TokenRefreshRequired",
    "UnrecognizedClientException", "AuthorizationHeaderMalformed",
})

# Subset of the above that a fresh credential fetch can recover from -> triggers
# an automatic refresh-and-retry for DAAC buckets.
_EXPIRED_TOKEN_CODES = frozenset({
    "ExpiredToken", "ExpiredTokenException", "InvalidToken", "TokenRefreshRequired",
})

_S3_CLIENTS: Dict[Optional[str], object] = {}
_EARTHACCESS_CREDENTIALS: Optional[Dict[str, str]] = None

# Prefix-narrowed listing normally saves work, but when the SAME base path would
# be queried with many different narrowing prefixes (e.g. a wide time range
# spanning many tracks/cycles, especially on date-less DAAC buckets where every
# query hits one folder), the per-prefix list_objects_v2 calls add up. When a
# planner determines a base path will see more than this many distinct prefixes,
# it lists that base once (Delimiter="/") and every prefix lookup is served from
# a local cache. Overridable via env var.
BULK_LIST_PREFIX_THRESHOLD = int(
    os.environ.get("NISAR_BULK_LIST_PREFIX_THRESHOLD", "5"))

# Cache of whole-base listings decided by plan_bucket_listings(), keyed by
# (bucket_name, full_base_prefix) -> list of full folder prefixes under the base.
# Presence of a key means "bulk mode": list_granules_from_bucket serves matching
# prefixes from here instead of issuing a per-prefix request.
_BASE_LIST_CACHE: Dict[tuple, List[str]] = {}


def reset_bucket_listing_cache() -> None:
    """Clear the planned bulk-listing cache."""
    _BASE_LIST_CACHE.clear()


def _paginate_folder_prefixes(client, bucket_name: str, prefix: str) -> List[str]:
    """Return full (un-basenamed) immediate folder prefixes under ``prefix``."""
    out: List[str] = []
    paginator = client.get_paginator("list_objects_v2")
    for page in paginator.paginate(
            Bucket=bucket_name, Prefix=prefix, Delimiter="/"):
        for common in page.get("CommonPrefixes", []):
            out.append(common["Prefix"].rstrip("/"))
    return out


def plan_bucket_listings(targets) -> None:
    """Pre-decide bulk-vs-fan-out for a whole set of upcoming listings.

    ``targets`` is an iterable of ``(bucket, product_type, date_path)`` describing
    every listing about to be performed (derivable from the built products, before
    any S3 call). For each distinct (bucket, base-path) that would be hit by more
    than ``BULK_LIST_PREFIX_THRESHOLD`` listings, the base is listed once now and
    cached so subsequent ``list_granules_from_bucket`` calls filter locally.

    Idempotent and additive: already-cached bases are left as-is, so this may be
    called once per time-range group. Call ``reset_bucket_listing_cache`` between
    independent runs if bucket contents may have changed.
    """
    counts: Dict[tuple, int] = {}
    a_bucket: Dict[tuple, S3Bucket] = {}
    for bucket, product_type, date_path in targets:
        for base in _product_dir_prefixes(bucket, product_type, date_path):
            key = (bucket.bucket_name, base)
            counts[key] = counts.get(key, 0) + 1
            a_bucket[key] = bucket

    for key, n in counts.items():
        if n <= BULK_LIST_PREFIX_THRESHOLD or key in _BASE_LIST_CACHE:
            continue
        bucket_name, base = key
        logger.debug(
            "Planning bulk list of %s/%s: %d listings > threshold %d",
            bucket_name, base, n, BULK_LIST_PREFIX_THRESHOLD)
        client = get_s3_client_for_bucket(a_bucket[key])
        try:
            _BASE_LIST_CACHE[key] = _paginate_folder_prefixes(
                client, bucket_name, base)
        except Exception as exc:  # fall back to per-prefix listing on any failure
            logger.warning(
                "Bulk list planning failed for %s/%s (%s); using per-prefix",
                bucket_name, base, exc)

_EARTHACCESS_SCRIPT = """
import sys, json
try:
    import earthaccess
    auth = earthaccess.login(strategy="netrc")
    if not auth.authenticated:
        print(json.dumps({"error": "authentication_failed"})); sys.exit(1)
    cred = auth.get_s3_credentials(
        endpoint="https://nisar.asf.earthdatacloud.nasa.gov/s3credentials")
    if not cred:
        print(json.dumps({"error": "no_credentials"})); sys.exit(1)
    print(json.dumps({
        "aws_access_key_id": cred["accessKeyId"],
        "aws_secret_access_key": cred["secretAccessKey"],
        "aws_session_token": cred["sessionToken"],
    }))
except ImportError:
    print(json.dumps({"error": "earthaccess_not_available"})); sys.exit(1)
except Exception as e:
    print(json.dumps({"error": str(e)})); sys.exit(1)
"""


def _get_earthaccess_credentials() -> Optional[Dict[str, str]]:
    """Fetch temporary AWS credentials via earthaccess (through a subprocess)."""
    if not os.path.exists(os.path.expanduser("~/.netrc")):
        logger.debug("~/.netrc not found; skipping earthaccess credential fetch")
        return None
    candidates = [sys.executable]
    base_python = "/opt/conda/bin/python"
    if os.environ.get("CONDA_PREFIX") and os.path.exists(base_python):
        candidates.append(base_python)
    for python in candidates:
        try:
            result = subprocess.run(
                [python, "-c", _EARTHACCESS_SCRIPT],
                capture_output=True, text=True, timeout=30,
            )
        except (subprocess.TimeoutExpired, OSError) as exc:
            logger.debug("earthaccess subprocess failed on %s: %s", python, exc)
            continue
        if result.returncode == 0:
            try:
                return json.loads(result.stdout)
            except json.JSONDecodeError:
                logger.debug("Could not parse earthaccess output: %s", result.stdout)
        else:
            # Login/credential fetch failed: the subprocess prints a JSON
            # {"error": ...} payload. Surface it -- this is the root cause when
            # DAAC downloads later 403 after falling back to default creds.
            logger.warning(
                "earthaccess credential fetch failed on %s (rc=%s): %s",
                python, result.returncode,
                (result.stdout or result.stderr or "").strip())
    return None


_DAAC_CACHE_KEY = "__daac__"


def _credentials_valid(client) -> bool:
    """Return True if a client's credentials actually work (are not expired).

    Mirrors ``localize_runconfig.validate_aws_profile``: a successful call or an
    ``AccessDenied`` both mean auth succeeded (DAAC creds legitimately lack the
    ``s3:ListAllMyBuckets`` permission), whereas ``ExpiredToken`` and friends mean
    the credentials must be refreshed.
    """
    from botocore.exceptions import (
        ClientError, NoCredentialsError, PartialCredentialsError)

    try:
        client.list_buckets()
        return True
    except (NoCredentialsError, PartialCredentialsError):
        return False
    except ClientError as exc:
        code = exc.response.get("Error", {}).get("Code", "")
        # Auth worked, caller just can't list all buckets -> credentials valid.
        return code in ("AccessDenied", "AllAccessDisabled")


def _build_earthaccess_client(force_refresh: bool = False):
    """Build an S3 client from earthaccess temporary credentials (fetched fresh).

    An empty fetch result is never cached, so a transient failure is retried on
    the next call rather than poisoning the whole session.
    """
    global _EARTHACCESS_CREDENTIALS
    import boto3

    if force_refresh:
        _EARTHACCESS_CREDENTIALS = None
    if not _EARTHACCESS_CREDENTIALS:
        _EARTHACCESS_CREDENTIALS = _get_earthaccess_credentials() or {}
    if not _EARTHACCESS_CREDENTIALS:
        return None
    return boto3.client(
        "s3",
        aws_access_key_id=_EARTHACCESS_CREDENTIALS["aws_access_key_id"],
        aws_secret_access_key=_EARTHACCESS_CREDENTIALS["aws_secret_access_key"],
        aws_session_token=_EARTHACCESS_CREDENTIALS["aws_session_token"],
    )


def _get_daac_client(force_refresh: bool = False):
    """Return a working DAAC S3 client, validating credentials before use.

    Prefers the named DAAC profile, but only if its token is still valid;
    otherwise falls back to (freshly fetched) earthaccess temporary credentials.
    This is the automatic credential-refresh behaviour proven in
    ``scripts/localize_runconfig.py`` -- the previous implementation trusted the
    profile whenever its *name* existed, so an expired profile token produced
    ``ExpiredToken`` with no fallback.
    """
    import boto3
    from botocore.exceptions import NoCredentialsError, PartialCredentialsError

    if not force_refresh and _DAAC_CACHE_KEY in _S3_CLIENTS:
        return _S3_CLIENTS[_DAAC_CACHE_KEY]

    # 1. Named profile, but only if its credentials actually work (not expired).
    try:
        available_profiles = boto3.Session().available_profiles
    except Exception:
        available_profiles = []
    if DAAC_PROFILE_NAME in available_profiles:
        try:
            client = boto3.Session(profile_name=DAAC_PROFILE_NAME).client("s3")
            if _credentials_valid(client):
                _S3_CLIENTS[_DAAC_CACHE_KEY] = client
                return client
            logger.info(
                "DAAC profile %r credentials invalid/expired; falling back to "
                "earthaccess", DAAC_PROFILE_NAME)
        except (NoCredentialsError, PartialCredentialsError):
            logger.info(
                "DAAC profile %r unusable; falling back to earthaccess",
                DAAC_PROFILE_NAME)

    # 2. Earthaccess temporary credentials (fetched fresh).
    client = _build_earthaccess_client(force_refresh=force_refresh)
    if client is not None:
        logger.info("Using earthaccess temporary credentials for DAAC access")
        _S3_CLIENTS[_DAAC_CACHE_KEY] = client
        return client

    # 3. Last resort: default credential chain. This is almost certainly wrong
    # for a DAAC bucket (the worker IAM role is not authorized) and will 403 --
    # warn loudly so this silent fallback is not mistaken for working auth.
    logger.warning(
        "Could not obtain DAAC credentials via the %r profile or earthaccess "
        "(is ~/.netrc present with machine urs.earthdata.nasa.gov, and is "
        "earthaccess installed?); falling back to the default AWS credential "
        "chain, which will likely 403 on DAAC buckets", DAAC_PROFILE_NAME)
    client = boto3.client("s3")
    _S3_CLIENTS[_DAAC_CACHE_KEY] = client
    return client


def refresh_daac_credentials():
    """Discard cached DAAC client + earthaccess creds and rebuild from fresh ones.

    Called automatically when a DAAC request fails with an expired-token error so
    the operation can be retried without restarting the process.
    """
    global _EARTHACCESS_CREDENTIALS
    _EARTHACCESS_CREDENTIALS = None
    _S3_CLIENTS.pop(_DAAC_CACHE_KEY, None)
    _S3_CLIENTS.pop("__earthaccess__", None)
    return _get_daac_client(force_refresh=True)


def get_s3_client(profile_name: Optional[str] = None):
    """Return a cached boto3 S3 client for the given profile (None = default)."""
    import boto3
    from botocore.exceptions import NoCredentialsError, PartialCredentialsError

    if profile_name == DAAC_PROFILE_NAME:
        return _get_daac_client()

    if profile_name not in _S3_CLIENTS:
        try:
            if profile_name:
                _S3_CLIENTS[profile_name] = boto3.Session(
                    profile_name=profile_name).client("s3")
            else:
                _S3_CLIENTS[profile_name] = boto3.client("s3")
        except (NoCredentialsError, PartialCredentialsError):
            logger.error("No AWS credentials for profile %r", profile_name)
            raise
    return _S3_CLIENTS[profile_name]


def get_s3_client_for_bucket(bucket: S3Bucket):
    profile = DAAC_PROFILE_NAME if bucket.bucket_type is BucketType.DAAC else None
    return get_s3_client(profile)


def _product_dir_prefixes(bucket: S3Bucket, product_type,
                          date_path: Optional[str]) -> List[str]:
    """Return the S3 product-directory prefix(es) for a bucket + product type.

    For date-path (JPL) buckets a ``date_path`` (``YYYY/MM/DD``) is required
    to produce an efficient prefix; without one the level-scoped prefix is used.
    """
    fmt = bucket.path_format
    kwargs = {"level": product_type.level_tag, "product_type": product_type.code}
    if bucket.uses_date_path:
        kwargs["date_path"] = date_path if date_path is not None else ""
    return [fmt.format(**kwargs)]


def list_granules_from_bucket(
    bucket: S3Bucket,
    product_type,
    partial_prefixes: Optional[List[str]] = None,
    date_path: Optional[str] = None,
) -> List[str]:
    """List granule folder names in a bucket for a product type.

    Args:
        bucket: The bucket to search.
        product_type: A ``NISARProductType`` member.
        partial_prefixes: Optional granule-name prefixes appended to the S3 prefix
            to narrow the ``list_objects_v2`` scan (e.g. up to three for PR/UR/OD).
        date_path: ``YYYY/MM/DD`` segment for date-path (JPL) buckets.

    Returns:
        Granule folder basenames found under the built prefixes.
    """
    from botocore.exceptions import ClientError, NoCredentialsError, PartialCredentialsError

    base_prefixes = _product_dir_prefixes(bucket, product_type, date_path)
    partials = list(partial_prefixes) if partial_prefixes else [""]

    def _list(client) -> List[str]:
        granules: List[str] = []
        for base in base_prefixes:
            cache_key = (bucket.bucket_name, base)
            wanted = [base + p for p in partials]
            try:
                cached = _BASE_LIST_CACHE.get(cache_key)
                if cached is not None:
                    # A planner already listed this whole base; filter locally.
                    for full in cached:
                        if any(full.startswith(w) for w in wanted):
                            granules.append(full.rsplit("/", 1)[-1])
                else:
                    for w in wanted:
                        for full in _paginate_folder_prefixes(
                                client, bucket.bucket_name, w):
                            granules.append(full.rsplit("/", 1)[-1])
            except ClientError as exc:
                code = exc.response.get("Error", {}).get("Code", "")
                if code in _ACCESS_ERROR_CODES:
                    # Credential/access failure -- let the caller decide whether
                    # to refresh-and-retry or surface it.
                    raise
                logger.warning(
                    "List failed for %s/%s: %s", bucket.bucket_name, base, exc)
                continue
        return granules

    client = get_s3_client_for_bucket(bucket)
    try:
        return _list(client)
    except (NoCredentialsError, PartialCredentialsError):
        logger.error("No AWS credentials for bucket %s", bucket.bucket_name)
        raise
    except ClientError as exc:
        code = exc.response.get("Error", {}).get("Code", "")
        # Expired DAAC token: refresh credentials once and retry before failing.
        if code in _EXPIRED_TOKEN_CODES and bucket.bucket_type is BucketType.DAAC:
            logger.info(
                "DAAC credentials expired for %s; refreshing and retrying",
                bucket.bucket_name)
            try:
                return _list(refresh_daac_credentials())
            except (ClientError, NoCredentialsError, PartialCredentialsError) as exc2:
                logger.error(
                    "Retry after credential refresh failed for %s: %s",
                    bucket.bucket_name, exc2)
                raise
        logger.error("Access error listing %s: %s", bucket.bucket_name, exc)
        raise


def iter_granules_from_bucket(
    bucket: S3Bucket,
    product_type,
    partial_prefixes: Optional[List[str]] = None,
    date_path: Optional[str] = None,
):
    """Yield granule folder basenames one at a time (streaming).

    Same listing as :func:`list_granules_from_bucket` (``Delimiter="/"`` so only
    granule *folders* are returned, never every object), but a generator: the
    caller can stop after the first match instead of buffering every page of a
    bucket that may hold tens of thousands of granules across all cycles.

    Credential/access errors are raised (not swallowed) so the caller can
    distinguish "searched, no match" from "couldn't search". Expired-DAAC-token
    refresh-and-retry is NOT handled here (mid-stream retry can't resume cleanly);
    callers needing that should preflight with the buffered variant.
    """
    from botocore.exceptions import ClientError

    base_prefixes = _product_dir_prefixes(bucket, product_type, date_path)
    search_prefixes: List[str] = []
    for base in base_prefixes:
        if partial_prefixes:
            search_prefixes.extend(base + p for p in partial_prefixes)
        else:
            search_prefixes.append(base)

    client = get_s3_client_for_bucket(bucket)
    paginator = client.get_paginator("list_objects_v2")
    for prefix in search_prefixes:
        try:
            pages = paginator.paginate(
                Bucket=bucket.bucket_name, Prefix=prefix, Delimiter="/")
            for page in pages:
                for common in page.get("CommonPrefixes", []):
                    yield common["Prefix"].rstrip("/").rsplit("/", 1)[-1]
        except ClientError as exc:
            code = exc.response.get("Error", {}).get("Code", "")
            if code in _ACCESS_ERROR_CODES:
                raise
            logger.warning(
                "List failed for %s/%s: %s", bucket.bucket_name, prefix, exc)
            continue


def build_granule_file_url(bucket: S3Bucket, product_type, granule_basename: str,
                           extension: str, date_path: Optional[str] = None) -> str:
    """Build the full ``s3://`` URL for a granule's file inside its folder."""
    base = _product_dir_prefixes(bucket, product_type, date_path)[0]
    key = f"{base}{granule_basename}/{granule_basename}{extension}"
    return f"s3://{bucket.bucket_name}/{key}"


def verify_granule_file_exists(
    bucket: S3Bucket,
    product_type,
    granule_basename: str,
    extension: str,
    date_path: Optional[str] = None
) -> bool:
    """Verify that a granule file actually exists in S3.

    This checks for the case where a granule folder exists but the file inside
    has been deleted or moved to another bucket.

    Args:
        bucket: The S3 bucket.
        product_type: A ``NISARProductType`` member.
        granule_basename: The granule folder basename.
        extension: File extension (e.g., '.h5').
        date_path: ``YYYY/MM/DD`` segment for date-path (JPL) buckets.

    Returns:
        True if the file exists and is accessible, False otherwise.
    """
    from botocore.exceptions import ClientError

    base = _product_dir_prefixes(bucket, product_type, date_path)[0]
    key = f"{base}{granule_basename}/{granule_basename}{extension}"

    client = get_s3_client_for_bucket(bucket)

    try:
        client.head_object(Bucket=bucket.bucket_name, Key=key)
        return True
    except ClientError as exc:
        code = exc.response.get("Error", {}).get("Code", "")
        if code == "404":
            logger.debug(
                "Granule folder %s exists but file %s not found (404)",
                granule_basename, key)
            return False
        # For access errors, propagate them
        if code in _ACCESS_ERROR_CODES:
            raise
        logger.debug(
            "Failed to verify file %s/%s: %s",
            bucket.bucket_name, key, exc)
        return False


def download_url(url: str, dest_dir: str, force_redownload: bool = False) -> str:
    """Download an ``s3://`` (or http[s]) URL to ``dest_dir``; return local path."""
    parsed = urlparse(url)
    filename = os.path.basename(parsed.path)
    local_path = os.path.abspath(os.path.join(dest_dir, filename))
    os.makedirs(dest_dir, exist_ok=True)
    if os.path.exists(local_path) and not force_redownload:
        logger.info("File exists, skipping download: %s", local_path)
        return local_path

    if parsed.scheme in ("http", "https"):
        import urllib.request
        urllib.request.urlretrieve(url, local_path)
        return local_path

    from botocore.exceptions import ClientError

    bucket_name = parsed.netloc
    key = parsed.path.lstrip("/")
    bucket = next((b for b in S3Bucket if b.bucket_name == bucket_name), None)
    # Which credential path applies to this bucket. Unregistered buckets fall
    # through to the default AWS chain (worker IAM role) and NEVER consult the
    # netrc/earthaccess creds -- surface that so a 403 on such a bucket is not
    # mistaken for a netrc problem.
    if bucket is None:
        cred_source = ("default AWS credential chain (bucket %r not in S3Bucket "
                       "enum; netrc/earthaccess NOT used)" % bucket_name)
        client = get_s3_client()
    elif bucket.bucket_type is BucketType.DAAC:
        cred_source = "DAAC profile / earthaccess creds (from ~/.netrc)"
        client = get_s3_client_for_bucket(bucket)
    else:
        cred_source = "default AWS credential chain (JPL bucket)"
        client = get_s3_client_for_bucket(bucket)
    logger.debug("Downloading %s using %s", url, cred_source)
    try:
        client.download_file(bucket_name, key, local_path)
    except ClientError as exc:
        code = exc.response.get("Error", {}).get("Code", "")
        # Expired DAAC token: refresh credentials once and retry.
        if (code in _EXPIRED_TOKEN_CODES and bucket is not None
                and bucket.bucket_type is BucketType.DAAC):
            logger.info(
                "DAAC credentials expired for %s; refreshing and retrying download",
                bucket_name)
            refresh_daac_credentials().download_file(bucket_name, key, local_path)
        else:
            # Attach the URL, bucket, error code, and credential path to the
            # bare boto3 error so the failing input is identifiable in the log.
            logger.error(
                "S3 download failed [%s] for %s (bucket=%s) using %s",
                code or "unknown", url, bucket_name, cred_source)
            # Also fold the detail into the exception message itself. The
            # notebook wrapper surfaces only the traceback (a bare
            # "ClientError: An error occurred (403) ... HeadObject"), and the
            # logging lines above go to kernel stderr, which is easy to miss.
            # Overwriting the exception's message means the failing URL +
            # credential path ride along in the PapermillExecutionError
            # traceback. exc.response (and thus the error Code that callers
            # inspect) is left untouched -- only the displayed message changes.
            exc.args = (
                f"{exc.args[0] if exc.args else str(exc)} "
                f"[failed URL: {url} | bucket={bucket_name} | creds: {cred_source}]",
            )
            raise
    return local_path


def date_path_from_time(time: datetime) -> str:
    """Return the ``YYYY/MM/DD`` path segment for a datetime."""
    return f"{time.year:04d}/{time.month:02d}/{time.day:02d}"


def date_paths_for_window(
    bucket: S3Bucket,
    start_time: Optional[datetime],
    is_estimated: bool = False,
) -> List[Optional[str]]:
    """Return the ``date_path`` value(s) to search for a product by its start time.

    Products are ALWAYS stored by their start_time only in S3, never by end_time
    or intermediate dates. This function returns the date path(s) needed to locate
    a product given its start time.

    Args:
        bucket: The S3 bucket to search
        start_time: When the product starts. None returns [None] for all buckets.
        is_estimated: Whether start_time is estimated from orbit references (True)
            or actual from a parsed granule name (False). When True and start_time
            is within 1 minute of a day boundary, returns both adjacent days to
            account for precision differences between estimated and actual times.

    Returns:
        - ``[None]`` for date-less (DAAC) buckets or when start_time is None
        - ``["YYYY/MM/DD"]`` (single date) for date-path (JPL) buckets when
          start_time is actual or not near a day boundary
        - ``["YYYY/MM/DD", "YYYY/MM/DD"]`` (two adjacent dates) when start_time
          is estimated and within 1 minute of a day boundary

    Whether dates appear in the S3 path at all is a property of the bucket, so
    that decision lives here rather than in every caller. Callers iterate the
    result and pass each value to :func:`list_granules_from_bucket` without
    knowing the bucket's layout.
    """
    if not bucket.uses_date_path or start_time is None:
        return [None]

    # Products are stored by their start_time date
    start_date = start_time.date()
    paths: List[Optional[str]] = [f"{start_date.year:04d}/{start_date.month:02d}/{start_date.day:02d}"]

    # If estimated, check if within 1 minute of a day boundary
    if is_estimated:
        # Get seconds since midnight
        seconds_since_midnight = (
            start_time.hour * 3600 + start_time.minute * 60 + start_time.second
        )
        seconds_in_day = 24 * 3600

        # Within 1 minute (60 seconds) of start of day?
        if seconds_since_midnight < 60:
            prev_date = start_date - timedelta(days=1)
            prev_path = f"{prev_date.year:04d}/{prev_date.month:02d}/{prev_date.day:02d}"
            if prev_path not in paths:
                paths.insert(0, prev_path)

        # Within 1 minute (60 seconds) of end of day?
        if seconds_since_midnight > seconds_in_day - 60:
            next_date = start_date + timedelta(days=1)
            next_path = f"{next_date.year:04d}/{next_date.month:02d}/{next_date.day:02d}"
            if next_path not in paths:
                paths.append(next_path)

    return paths


def date_paths_for_intersection_search(
    bucket: S3Bucket,
    window_start: Optional[datetime],
    window_end: Optional[datetime],
) -> List[Optional[str]]:
    """Return date paths to search for products that intersect a time window.

    This is for finding products (like RRSD) that could START on any date within
    or shortly before the window and then extend to intersect it. Since products
    are stored by their start_time only, we need to search each potential start
    date separately.

    Args:
        bucket: The S3 bucket to search
        window_start: Start of the time window to find intersecting products
        window_end: End of the time window

    Returns:
        - ``[None]`` for date-less (DAAC) buckets or when window_start is None
        - List of date paths for each day from window_start through window_end
          where a product could potentially start and intersect the window

    Example:
        To find RRSDs that intersect window [2024-06-15 12:00, 2024-06-17 14:00]:
        - An RRSD starting 2024-06-14 could extend into the window
        - RRSDs starting 2024-06-15, 06-16, 06-17 would intersect
        - So we search date paths: 2024/06/14, 2024/06/15, 2024/06/16, 2024/06/17
    """
    if not bucket.uses_date_path or window_start is None:
        return [None]

    # Search from window_start through window_end (inclusive)
    start_date = window_start.date()
    end_date = (window_end or window_start).date()

    paths: List[Optional[str]] = []
    current_date = start_date
    while current_date <= end_date:
        paths.append(f"{current_date.year:04d}/{current_date.month:02d}/{current_date.day:02d}")
        current_date += timedelta(days=1)

    return paths
