"""Lineage tree: LineageNode return type, builders, and the LineageMixin.

`trace_lineage` returns a `LineageNode` tree that makes predecessor relationships
explicit (which RRSD feeds which RSLC), rather than a flat list the caller must
re-interpret. Both the exact met.json path and the estimated (guessing) path build
the same tree shape, so callers get a uniform API.
"""
from __future__ import annotations

import json
import os
from typing import Dict, List, Optional

from .enums import NISARProductType

# Accountability keys of interest (predecessor product types).
_ACC_RSLC_KEY = "L1_L_RSLC"
_ACC_RRSD_KEY = "L0B_L_RRSD"


def _intersects(a0, a1, b0, b1) -> bool:
    """True if closed intervals [a0,a1] and [b0,b1] overlap."""
    return a0 <= b1 and b0 <= a1


class LineageNode:
    """A node in a product's lineage tree.

    ``product`` is the Nisar* object; ``inputs`` are its direct predecessors.
    The root wraps the product ``trace_lineage`` was called on.
    """

    def __init__(self, product, inputs: Optional[List["LineageNode"]] = None):
        self.product = product
        self.inputs: List["LineageNode"] = inputs if inputs is not None else []
        self.radar_mode_metadata: Optional["RadarModeMetadata"] = None  # type: ignore

    @property
    def granule_name(self) -> Optional[str]:
        match = getattr(self.product, "latest_product_match", None)
        if match:
            return match
        return getattr(self.product, "granule_name", None)

    @property
    def granule_matches(self) -> List[str]:
        """All granule basenames this product resolved to (best-first).

        An incomplete search can match several granules sharing the identifiers;
        this exposes every match. Falls back to the single ``granule_name`` when
        the product was built from a known name (e.g. exact met.json lineage).
        """
        matches = getattr(self.product, "product_matches", None)
        if matches:
            return list(matches)
        name = self.granule_name
        return [name] if name else []

    @property
    def product_type(self) -> NISARProductType:
        return self.product.product_type

    def walk(self):
        """Depth-first generator over this node and all descendants."""
        yield self
        for child in self.inputs:
            yield from child.walk()

    def flatten(self) -> list:
        """Return predecessor products (excludes the root), depth-first."""
        return [node.product for node in self.walk()][1:]

    def find(self, product_type: NISARProductType) -> List["LineageNode"]:
        """Return all descendant nodes (and self) matching a product type."""
        return [node for node in self.walk() if node.product_type is product_type]

    def unprocessed_products(self) -> Dict[NISARProductType, list]:
        """Group products that were searched but not found, keyed by product type.

        A product is "unprocessed" only if ``find_granule`` ran for it and produced
        no exact match. Products with an exact match exist; products never searched
        are unknown (not reported here).
        """
        result: Dict[NISARProductType, list] = {}
        for node in self.walk():
            state = getattr(node.product, "processed_state", "unknown")
            if state == "unprocessed":
                result.setdefault(node.product_type, []).append(node.product)
        return result

    def __repr__(self) -> str:
        name = self.granule_name or self.product_type.code
        if not self.inputs:
            return name
        children = ", ".join(repr(child) for child in self.inputs)
        return f"{name} <- ({children})" if len(self.inputs) > 1 else f"{name} <- {children}"


def lineage_from_met_json(product, met_json: dict) -> LineageNode:
    """Build an exact lineage tree from a product's ``.met.json`` accountability.

    Predecessor granule names are read from ``accountability.L1_L_RSLC.outputs`` and
    ``accountability.L0B_L_RRSD.outputs``. RSLCs and RRSDs are paired by time-range
    intersection; the tree is flat (one met.json already lists the full chain).
    """
    from .factory import from_granule_name  # lazy import to avoid a cycle

    accountability = met_json.get("accountability", {})
    own_name = getattr(product, "latest_product_match", None) or \
        getattr(product, "granule_name", None)

    rslc_names = list(accountability.get(_ACC_RSLC_KEY, {}).get("outputs", []))
    rrsd_names = list(accountability.get(_ACC_RRSD_KEY, {}).get("outputs", []))

    # Exclude the product's own entry when it is itself an RSLC.
    if product.product_type is NISARProductType.RSLC and own_name:
        rslc_names = [n for n in rslc_names if n != own_name]

    rrsd_nodes = [LineageNode(from_granule_name(n)) for n in rrsd_names]

    if rslc_names:
        rslc_inputs: List[LineageNode] = []
        for rslc_name in rslc_names:
            rslc = from_granule_name(rslc_name)
            r_start, r_end = rslc.get_time_range()
            children = [
                node for node in rrsd_nodes
                if _intersects(r_start, r_end,
                               node.product.start_time, node.product.end_time)
            ]
            rslc_inputs.append(LineageNode(rslc, inputs=children))
        return LineageNode(product, inputs=rslc_inputs)

    # Product is itself an RSLC: its direct inputs are the RRSDs.
    return LineageNode(product, inputs=rrsd_nodes)


def estimated_lineage(product, resolve: bool, buckets) -> LineageNode:
    """Build a lineage tree by recursive guessing from partial identifiers.

    When ``resolve`` is True the root product runs ``find_granule`` (so its own
    processed-state and matches are populated), and each guessed predecessor is
    likewise resolved.
    """
    if resolve and buckets and hasattr(product, "find_granule"):
        product.find_granule(buckets)
    inputs = product._estimate_inputs(resolve=resolve, buckets=buckets)
    return LineageNode(product, inputs=inputs)


def resolve_branches(template, resolve: bool, buckets) -> List["LineageNode"]:
    """Expand a predecessor into one lineage branch per resolved granule match.

    An incomplete search can match several granules that share the identifiers but
    differ in radar mode, time range, etc. Each is a distinct possible predecessor,
    so -- when resolving -- this returns one *fully-parsed* branch per match, each
    using that granule's real metadata to find its own predecessors. This makes the
    estimated tree a superset that covers every candidate lineage.

    Falls back to a single estimated branch (built from the template's identifiers)
    when ``resolve`` is off or nothing is found.
    """
    from .factory import from_granule_name  # lazy import to avoid a cycle

    if resolve and buckets:
        matches = template.find_granule(buckets)
        if matches:
            # find_granule populated template.download_urls parallel to matches;
            # from_granule_name rebuilds a product from the name alone and does
            # not know the URL, so carry the resolved URL over to each branch.
            url_by_name = dict(zip(matches, template.download_urls))
            branches: List["LineageNode"] = []
            for match_name in matches:
                product = from_granule_name(match_name)
                url = url_by_name.get(match_name)
                if url is not None:
                    product.download_url = url
                    product.download_urls = [url]
                branches.append(LineageNode(
                    product, inputs=product._estimate_inputs(resolve, buckets)))
            return branches
    return [LineageNode(template, inputs=template._estimate_inputs(resolve, buckets))]


class LineageMixin:
    """Adds ``trace_lineage`` (returns a LineageNode) to product classes.

    Subclasses implement ``_estimate_inputs`` returning ``list[LineageNode]``.
    """

    def trace_lineage(self, resolve: bool = False, buckets=None,
                      met_json=None, dest_dir: Optional[str] = None) -> LineageNode:
        """Return the lineage tree for this product.

        If a met.json is available (passed explicitly, or downloaded when
        ``resolve`` is set and the product supports it), build the exact tree from
        accountability; otherwise fall back to estimation.
        """
        met = _resolve_met_json(self, resolve, buckets, met_json, dest_dir)
        if met is not None:
            return lineage_from_met_json(self, met)
        return estimated_lineage(self, resolve, buckets)

    def _estimate_inputs(self, resolve: bool, buckets) -> List[LineageNode]:
        raise NotImplementedError


def _resolve_met_json(product, resolve: bool, buckets, met_json, dest_dir):
    """Obtain a met.json dict from an explicit arg or by downloading it."""
    if isinstance(met_json, dict):
        return met_json
    if isinstance(met_json, (str, os.PathLike)):
        with open(met_json) as f:
            return json.load(f)
    if resolve and hasattr(product, "download_metadata") and dest_dir is not None:
        try:
            path = product.download_metadata(dest_dir, buckets=buckets)
        except (FileNotFoundError, ValueError):
            return None
        with open(path) as f:
            return json.load(f)
    return None


def attach_radar_mode_metadata(root: LineageNode) -> None:
    """Compute and attach RadarModeMetadata to all nodes in lineage tree.

    Finds all RRSD products in the tree, constructs RadarModeMetadata from
    their radar_modes, and attaches the same metadata object to every node.
    If no RRSDs are found, no metadata is attached (graceful degradation).

    Args:
        root: The root LineageNode of the lineage tree.
    """
    from .radar_mode_metadata import RadarModeMetadata

    # Find all RRSD nodes in the tree
    rrsd_nodes = root.find(NISARProductType.RRSD)

    if not rrsd_nodes:
        # No RRSDs found - skip metadata attachment
        return

    # Extract RRSD products
    rrsd_products = [node.product for node in rrsd_nodes]

    # Get radar_band from the root product
    radar_band = root.product.radar_band

    # Construct RadarModeMetadata
    try:
        metadata = RadarModeMetadata(rrsd_products, radar_band)
    except (ValueError, FileNotFoundError) as e:
        # If metadata construction fails, log and skip attachment
        # This prevents the entire backprocessing from failing
        import logging
        logger = logging.getLogger(__name__)
        logger.warning(f"Failed to construct RadarModeMetadata: {e}")
        return

    # Attach to all nodes in the tree
    for node in root.walk():
        node.radar_mode_metadata = metadata
