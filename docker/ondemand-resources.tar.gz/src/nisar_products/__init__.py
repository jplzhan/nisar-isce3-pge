"""nisar_products: an object model for NISAR products.

Parse granule names into identifiers, derive metadata from static references
(track-frame geopackage + cycle-times), resolve/download granules from S3, and
trace product lineage back through the processing chain.
"""
from .enums import (
    FrequencyA,
    FrequencyB,
    NISARProductType,
    Polarization,
    ProcessingType,
    ProductAccuracy,
    RadarBand,
    S3Bucket,
)
from .factory import from_granule_name, from_identifiers
from .lineage import LineageNode, lineage_from_met_json
from .radar_mode_metadata import RadarModeMetadata
from .metadata import (
    NisarSingleProductMetadata,
    ParsedInsarGranule,
    ParsedRRSDGranule,
    ParsedSingleGranule,
    parse_insar_granule,
    parse_rrsd_granule,
    parse_single_granule,
)
from .products import (
    NisarGCOV,
    NisarGOFF,
    NisarGSLC,
    NisarGUNW,
    NisarObservation,
    NisarPairwiseProduct,
    NisarRIFG,
    NisarROFF,
    NisarRRSD,
    NisarRSLC,
    NisarRUNW,
    NisarSingleProduct,
    NisarSME2,
)
from .references import configure

__all__ = [
    "from_granule_name",
    "from_identifiers",
    "configure",
    # enums
    "RadarBand",
    "ProcessingType",
    "ProductAccuracy",
    "Polarization",
    "FrequencyA",
    "FrequencyB",
    "NISARProductType",
    "S3Bucket",
    # metadata
    "NisarSingleProductMetadata",
    "ParsedSingleGranule",
    "ParsedInsarGranule",
    "ParsedRRSDGranule",
    "parse_single_granule",
    "parse_insar_granule",
    "parse_rrsd_granule",
    # lineage
    "LineageNode",
    "lineage_from_met_json",
    "RadarModeMetadata",
    # products
    "NisarSingleProduct",
    "NisarObservation",
    "NisarRRSD",
    "NisarRSLC",
    "NisarGSLC",
    "NisarGCOV",
    "NisarPairwiseProduct",
    "NisarGUNW",
    "NisarRUNW",
    "NisarGOFF",
    "NisarROFF",
    "NisarRIFG",
    "NisarSME2",
]

__version__ = "0.1.0"
