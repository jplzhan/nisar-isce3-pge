"""Multi-cycle products: INSAR family (2 cycles) and SME2 (3 cycles)."""
from __future__ import annotations

import logging
from typing import List, Optional

from .. import naming, references, s3_search
from ..enums import NISARProductType, ProcessingType, RadarBand, S3Bucket
from ..lineage import LineageMixin, LineageNode, resolve_branches
from ..metadata import parse_insar_granule
from .single import NisarGCOV, NisarRSLC

logger = logging.getLogger(__name__)


class NisarPairwiseProduct(LineageMixin):
    """Base for products sharing (track, frame, CRID, product_type) across cycles.

    ``cycles`` is a fixed-size set of unique cycle numbers.
    """

    product_type: NISARProductType = None
    num_cycles: int = 0

    def __init__(
        self,
        cycles: List[int],
        track: int,
        frame: int,
        composite_release_id: Optional[str] = None,
        radar_band: RadarBand = RadarBand.L,
        processing_type: ProcessingType = ProcessingType.PR,
    ):
        if self.product_type is None:
            raise TypeError(
                f"{type(self).__name__} must define a product_type class attribute")
        unique = list(dict.fromkeys(cycles))
        if len(unique) != len(cycles):
            raise ValueError(f"Cycles must be unique: {cycles}")
        if self.num_cycles and len(unique) != self.num_cycles:
            raise ValueError(
                f"{type(self).__name__} requires {self.num_cycles} cycles, "
                f"got {len(unique)}: {cycles}")
        self.cycles = unique
        self.track = track
        self.frame = frame
        self.composite_release_id = composite_release_id
        self.radar_band = radar_band
        self.processing_type = processing_type
        self.granule_name: Optional[str] = None
        self.download_url: Optional[str] = None
        # All granules matching an incomplete search (best-first); see
        # NisarSingleProduct.find_granule for the rationale.
        self.product_matches: List[str] = []  # granule basenames, best-first
        self.download_urls: List[str] = []  # parallel .h5 URLs, best-first
        self._find_granule_attempted = False

    @property
    def level(self) -> int:
        return self.product_type.level

    @property
    def processed_state(self) -> str:
        """One of 'exact', 'unprocessed', 'unknown' (see lineage.py)."""
        if self.granule_name:
            return "exact"
        if self._find_granule_attempted:
            return "unprocessed"
        return "unknown"

    def set_latest_product_match(self, granule_basename: Optional[str]) -> None:
        """Alias for setting granule_name (mirrors NisarSingleProduct interface)."""
        self.granule_name = granule_basename

    def __repr__(self) -> str:
        return (f"{type(self).__name__}(cycles={self.cycles}, track={self.track}, "
                f"frame={self.frame}, crid={self.composite_release_id!r})")


class _InsarProduct(NisarPairwiseProduct):
    """INSAR products derive from two RSLCs (one per cycle)."""

    num_cycles = 2

    @property
    def reference_cycle(self) -> int:
        return self.cycles[0]

    @property
    def secondary_cycle(self) -> int:
        return self.cycles[1]

    def get_partial_granule_name(self, cycle_offset: Optional[int] = None) -> str:
        """Build this INSAR product's identifier-only partial granule prefix.

        Mirrors ``NisarSingleProduct.get_partial_granule_name`` but for the
        two-cycle INSAR layout (reference + secondary cycle).
        """
        return naming.build_insar_partial_granule_name(
            radar_band=self.radar_band,
            product_type=self.product_type,
            processing_type=self.processing_type,
            reference_cycle=self.reference_cycle,
            track=self.track,
            frame=self.frame,
            secondary_cycle=self.secondary_cycle,
            pass_direction=references.pass_direction(self.track, self.frame),
            composite_release_id=self.composite_release_id,
            cycle_offset=cycle_offset,
        )

    def find_granule(self, buckets: List[S3Bucket]) -> List[str]:
        """Search buckets for INSAR granule(s) matching this product's identifiers.

        Builds a partial prefix from cycles/track/frame/pass_direction, lists
        matching folders, and keeps every granule sharing the identifiers and
        CRID -- an incomplete search can match several that differ only in radar
        mode, etc. Matches are ordered best-first (highest product counter) in
        ``self.product_matches`` (basenames) and ``self.download_urls`` (URLs);
        the best also sets ``granule_name`` / ``download_url``.

        Returns ``self.product_matches`` (all matching basenames, best-first;
        empty if none found).
        """
        self._find_granule_attempted = True
        self.product_matches = []
        self.download_urls = []
        crid = self.composite_release_id or ""
        pass_dir = references.pass_direction(self.track, self.frame)
        # When the CRID is unknown the on-disk cycle tokens may carry the
        # dumb-exception offset or not, so search a prefix per candidate offset.
        partial_prefixes = []
        for offset in naming.candidate_cycle_offsets(self.composite_release_id):
            named_ref = self.cycles[0] + offset
            named_sec = self.cycles[1] + offset
            partial_prefixes.append(
                f"{naming.FIXED_HEAD}_{self.radar_band.value}{self.product_type.level}_"
                f"{self.processing_type.value}_{self.product_type.code}_"
                f"{named_ref:03d}_{self.track:03d}_{pass_dir}_{self.frame:03d}_{named_sec:03d}_"
            )
        # INSAR granules are stored under the reference acquisition date on
        # date-path buckets. Since we're using estimated_time_range (not actual
        # times from a granule name), we pass is_estimated=True to search adjacent
        # days if the estimated time is near a day boundary. s3_search decides
        # whether the layout uses dates.
        ref_start, ref_end = references.estimated_time_range(
            self.track, self.frame, self.reference_cycle)
        candidates = []  # (name, bucket)
        for bucket in buckets:
            for dp in s3_search.date_paths_for_window(bucket, ref_start, is_estimated=True):
                found = s3_search.list_granules_from_bucket(
                    bucket, self.product_type,
                    partial_prefixes=partial_prefixes, date_path=dp)
                for name in found:
                    candidates.append((name, bucket))

        # Filter by CRID when known; otherwise validate that the granule parses
        # back to this product's cycles (its own CRID's offset is applied on
        # parse), rejecting coincidental hits from the extra +5 search prefix.
        # Group by name to collect all buckets where each product was found.
        from collections import defaultdict
        products_by_name = defaultdict(list)  # name -> [(bucket, parsed), ...]

        for name, bucket in candidates:
            try:
                parsed = parse_insar_granule(name)
            except ValueError:
                continue
            if crid:
                if parsed.composite_release_id != crid:
                    continue
            elif [parsed.reference_cycle, parsed.secondary_cycle] != self.cycles:
                continue
            # Store all buckets where this product name was found
            products_by_name[name].append((bucket, parsed))

        if not products_by_name:
            return []

        # For each unique product, find the first bucket where the file exists
        verified = []  # (product_counter, name, bucket, parsed)
        for name, bucket_list in products_by_name.items():
            # All entries for the same name should have the same metadata
            _, first_parsed = bucket_list[0]
            date_path = s3_search.date_path_from_time(first_parsed.reference_start_time)

            # Try each bucket where this product folder was found
            file_found = False
            for bucket, parsed in bucket_list:
                # Check if file exists in this bucket
                if s3_search.verify_granule_file_exists(
                        bucket, self.product_type, name, ".h5", date_path=date_path):
                    # File exists in this bucket - use it
                    url = s3_search.build_granule_file_url(
                        bucket, self.product_type, name, ".h5", date_path=date_path)
                    self.product_matches.append(name)
                    self.download_urls.append(url)
                    verified.append((parsed.product_counter, name, bucket, parsed))
                    file_found = True
                    break
                else:
                    logger.debug(
                        "Granule folder %s found in %s but .h5 file missing, trying other buckets",
                        name, bucket.bucket_name)

            if not file_found:
                logger.debug(
                    "Granule folder %s found in %d bucket(s) but file missing in all",
                    name, len(bucket_list))

        if not verified:
            logger.info("Pairwise granule folders found but no files exist in any bucket")
            return []

        # Sort by product counter (highest first)
        verified.sort(key=lambda t: t[0], reverse=True)

        self.granule_name = self.product_matches[0]
        self.download_url = self.download_urls[0]
        return self.product_matches

    def _estimate_inputs(self, resolve: bool = False,
                         buckets: Optional[List[S3Bucket]] = None) -> List[LineageNode]:
        """RSLC branches per cycle, each with its own RRSD child.

        A partial search per cycle can match several RSLCs (differing radar mode,
        time range, etc.); each is expanded as its own branch.
        """
        nodes: List[LineageNode] = []
        for cycle in self.cycles:
            rslc = NisarRSLC(
                cycle=cycle,
                track=self.track,
                frame=self.frame,
                composite_release_id=self.composite_release_id,
                radar_band=self.radar_band,
                processing_type=self.processing_type,
            )
            nodes.extend(resolve_branches(rslc, resolve, buckets))
        return nodes


class NisarGUNW(_InsarProduct):
    product_type = NISARProductType.GUNW


class NisarRUNW(_InsarProduct):
    product_type = NISARProductType.RUNW


class NisarGOFF(_InsarProduct):
    product_type = NISARProductType.GOFF


class NisarROFF(_InsarProduct):
    product_type = NISARProductType.ROFF


class NisarRIFG(_InsarProduct):
    product_type = NISARProductType.RIFG


class NisarSME2(NisarPairwiseProduct):
    """L3 SME2: derives from three GCOVs (one per cycle).

    Only the reference cycle is recoverable from the SME2 granule name; the other
    two cycles and their times are left as future work per the spec. Callers may
    supply all three cycles explicitly.
    """

    product_type = NISARProductType.SME2
    num_cycles = 3

    def __init__(self, cycles, track, frame, composite_release_id=None,
                 radar_band: RadarBand = RadarBand.L,
                 processing_type: ProcessingType = ProcessingType.PR):
        # Allow partial construction (only the reference cycle known).
        unique = list(dict.fromkeys(cycles))
        self.cycles = unique
        self.track = track
        self.frame = frame
        self.composite_release_id = composite_release_id
        self.radar_band = radar_band
        self.processing_type = processing_type
        self.granule_name: Optional[str] = None
        self.download_url: Optional[str] = None
        self.product_matches: List[str] = []
        self.download_urls: List[str] = []
        self._find_granule_attempted = False

    def _estimate_inputs(self, resolve: bool = False,
                         buckets: Optional[List[S3Bucket]] = None) -> List[LineageNode]:
        """GCOV branches per known cycle, each expanding to RSLC <- RRSD.

        A partial search per cycle can match several GCOVs; each is expanded as
        its own branch.
        """
        nodes: List[LineageNode] = []
        for cycle in self.cycles:
            gcov = NisarGCOV(
                cycle=cycle,
                track=self.track,
                frame=self.frame,
                composite_release_id=self.composite_release_id,
                radar_band=self.radar_band,
                processing_type=self.processing_type,
            )
            nodes.extend(resolve_branches(gcov, resolve, buckets))
        return nodes
