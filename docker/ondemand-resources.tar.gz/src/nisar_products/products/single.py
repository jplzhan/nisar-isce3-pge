"""Single-cycle products: RSLC (root basic), GSLC, GCOV."""
from __future__ import annotations

import logging
from typing import List, Optional

from ..enums import NISARProductType, S3Bucket
from ..lineage import LineageNode, resolve_branches
from .base import NisarSingleProduct
from .observation import NisarRRSD

logger = logging.getLogger(__name__)


class NisarRSLC(NisarSingleProduct):
    """L1 RSLC: the "root basic product" from which higher products derive."""

    product_type = NISARProductType.RSLC

    def _estimate_inputs(self, resolve: bool = False,
                         buckets: Optional[List[S3Bucket]] = None) -> List[LineageNode]:
        """RSLC derives from an RRSD covering its time range.

        Prefers the real time range (via ``find_granule``) when ``resolve`` is
        set; otherwise uses the estimated range. The RRSD shares this RSLC's
        cycle/track/pass/CRID (an RRSD carries no frame), so those identifiers
        are propagated and the RRSD is itself resolved when ``resolve`` is set.
        """
        if resolve and self._latest_product_match is None and buckets:
            self.find_granule(buckets)
        start, end = self.get_time_range()
        rrsd = NisarRRSD(
            start,
            end,
            radar_band=self.radar_band,
            cycle=self.cycle,
            track=self.track,
            pass_direction=self.pass_direction,
            composite_release_id=self.composite_release_id,
            processing_type=self.processing_type,
        )
        if resolve and buckets:
            rrsd.find_granule(buckets)
        return [LineageNode(rrsd)]

    def generate_runconfig(
        self,
        target_crid: Optional[str] = None,
        buckets: Optional[List[S3Bucket]] = None
    ) -> dict:
        """Generate processing runconfig for this RSLC product.

        See base class docstring for full details on the generation modes.

        Args:
            target_crid: Optional CRID to use. Defaults to product's CRID or latest.
            buckets: S3 buckets to search. Defaults to all available buckets.

        Returns:
            dict: Dictionary representing the runconfig YAML structure.
        """
        from .. import crid_utils, references, runconfig_builder, runconfig_reference, runconfig_templates
        from ..radar_mode_metadata import RadarModeMetadata

        # Determine target CRID
        if target_crid is None:
            target_crid = self.composite_release_id
            if target_crid is None:
                # TODO: Find latest CRID across all buckets
                raise ValueError("target_crid not specified and product has no CRID")

        # Use all available buckets if not specified
        if buckets is None:
            from ..enums import S3Bucket as S3BucketEnum
            buckets = list(S3BucketEnum)

        logger.info(
            f"Generating runconfig for {self.product_type.code} "
            f"(cycle={self.cycle}, track={self.track}, frame={self.frame}, "
            f"target_crid={target_crid})"
        )

        # Step 1.1: Try to find direct reference
        reference_granule = runconfig_reference.find_reference_product(
            self.product_type,
            self.track,
            self.frame,
            target_crid,
            buckets
        )

        if reference_granule:
            logger.info("Using direct reference product for template")
            # Download .met.json and extract template
            # For now, fall through to template inference since downloading requires more logic
            pass

        # Step 1.2: Infer template from S3 parameter sets
        logger.info("Inferring template from S3 parameter sets")

        # Get radar mode metadata from lineage
        lineage = self.trace_lineage(resolve=True, buckets=buckets)
        rrsd_products = [node.product for node in lineage if isinstance(node.product, NisarRRSD)]

        if not rrsd_products:
            logger.warning("No RRSD products in lineage, cannot determine radar mode metadata")
            radar_mode_metadata = None
        else:
            radar_mode_metadata = RadarModeMetadata(rrsd_products, self.radar_band)

        # Get default template
        template_s3_path = runconfig_templates.get_default_template_s3_path(
            self.product_type,
            radar_mode_metadata=radar_mode_metadata,
            insar_psf_criteria=None  # Not needed for RSLC
        )

        template = runconfig_templates.download_and_parse_template(template_s3_path)

        # Build the runconfig
        runconfig = runconfig_builder.build_runconfig_for_product(
            self,
            target_crid,
            buckets,
            template
        )

        return runconfig


class _DerivedFromRSLC(NisarSingleProduct):
    """Shared lineage for single-cycle products built from one RSLC."""

    def _estimate_inputs(self, resolve: bool = False,
                         buckets: Optional[List[S3Bucket]] = None) -> List[LineageNode]:
        """Derive from RSLC(s) sharing this cycle/track/frame/CRID.

        A partial search can match several RSLCs (differing radar mode, time
        range, etc.); each is expanded as its own branch using its real metadata.
        """
        rslc = NisarRSLC(
            cycle=self.cycle,
            track=self.track,
            frame=self.frame,
            composite_release_id=self.composite_release_id,
            radar_band=self.radar_band,
            processing_type=self.processing_type,
        )
        return resolve_branches(rslc, resolve, buckets)

    def generate_runconfig(
        self,
        target_crid: Optional[str] = None,
        buckets: Optional[List[S3Bucket]] = None
    ) -> dict:
        """Generate processing runconfig for GSLC/GCOV products.

        See base class docstring for full details on the generation modes.

        Args:
            target_crid: Optional CRID to use. Defaults to product's CRID or latest.
            buckets: S3 buckets to search. Defaults to all available buckets.

        Returns:
            dict: Dictionary representing the runconfig YAML structure.
        """
        from .. import references, runconfig_builder, runconfig_reference, runconfig_templates
        from ..radar_mode_metadata import RadarModeMetadata

        # Determine target CRID
        if target_crid is None:
            target_crid = self.composite_release_id
            if target_crid is None:
                # TODO: Find latest CRID across all buckets
                raise ValueError("target_crid not specified and product has no CRID")

        # Use all available buckets if not specified
        if buckets is None:
            from ..enums import S3Bucket as S3BucketEnum
            buckets = list(S3BucketEnum)

        logger.info(
            f"Generating runconfig for {self.product_type.code} "
            f"(cycle={self.cycle}, track={self.track}, frame={self.frame}, "
            f"target_crid={target_crid})"
        )

        # Step 1.1: Try to find direct reference
        reference_granule = runconfig_reference.find_reference_product(
            self.product_type,
            self.track,
            self.frame,
            target_crid,
            buckets
        )

        if reference_granule:
            logger.info("Using direct reference product for template")
            # For now, fall through to template inference
            pass

        # Step 1.2: Infer template from S3 parameter sets
        logger.info("Inferring template from S3 parameter sets")

        # Get radar mode metadata from RSLC lineage
        lineage = self.trace_lineage(resolve=True, buckets=buckets)
        rrsd_products = []

        # Find all RRSD products in the lineage tree
        def collect_rrsds(node):
            if isinstance(node.product, NisarRRSD):
                rrsd_products.append(node.product)
            for child in node.children:
                collect_rrsds(child)

        for node in lineage:
            collect_rrsds(node)

        if not rrsd_products:
            logger.warning("No RRSD products in lineage, cannot determine radar mode metadata")
            radar_mode_metadata = None
        else:
            radar_mode_metadata = RadarModeMetadata(rrsd_products, self.radar_band)

        # Get default template
        template_s3_path = runconfig_templates.get_default_template_s3_path(
            self.product_type,
            radar_mode_metadata=radar_mode_metadata,
            insar_psf_criteria=None  # Not needed for GSLC/GCOV
        )

        template = runconfig_templates.download_and_parse_template(template_s3_path)

        # Build the runconfig
        runconfig = runconfig_builder.build_runconfig_for_product(
            self,
            target_crid,
            buckets,
            template
        )

        return runconfig


class NisarGSLC(_DerivedFromRSLC):
    product_type = NISARProductType.GSLC


class NisarGCOV(_DerivedFromRSLC):
    product_type = NISARProductType.GCOV
