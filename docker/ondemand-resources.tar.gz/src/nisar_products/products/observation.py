"""Observation-based products (RRSD and its base class).

RRSD products span multiple track-frames, so they are defined by a time range
rather than a single (track, frame). They are treated as root products for now.
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta
from typing import List, Optional

from .. import naming, s3_search
from ..enums import NISARProductType, ProcessingType, ProductAccuracy, RadarBand, S3Bucket
from ..lineage import LineageMixin, LineageNode
from ..metadata import parse_rrsd_granule

logger = logging.getLogger(__name__)


class NisarObservation:
    """Base class for time-range-defined products spanning many track-frames."""

    product_type: NISARProductType = None

    def __init__(self, start_time: datetime, end_time: datetime,
                 radar_band: RadarBand = RadarBand.L):
        if self.product_type is None:
            raise TypeError(
                f"{type(self).__name__} must define a product_type class attribute")
        self.start_time = start_time
        self.end_time = end_time
        self.radar_band = radar_band

    @property
    def level(self) -> int:
        return self.product_type.level

    def __repr__(self) -> str:
        return (f"{type(self).__name__}(start={self.start_time.isoformat()}, "
                f"end={self.end_time.isoformat()})")


class NisarRRSD(LineageMixin, NisarObservation):
    """L0B RRSD: the root product for lineage tracing.

    ``intersecting_start_time`` / ``intersecting_end_time`` describe the time
    window (typically an RSLC's real or estimated range) used to find RRSD
    granules that intersect it. Optional identifiers are populated when the RRSD
    is built from a real granule name.
    """

    product_type = NISARProductType.RRSD

    def __init__(
        self,
        start_time: datetime,
        end_time: datetime,
        radar_band: RadarBand = RadarBand.L,
        cycle: Optional[int] = None,
        track: Optional[int] = None,
        pass_direction: Optional[str] = None,
        radar_mode: Optional[int] = None,
        is_mixed_mode: Optional[bool] = None,
        composite_release_id: Optional[str] = None,
        processing_type: Optional[ProcessingType] = None,
        product_accuracy: Optional[ProductAccuracy] = None,
        processing_location: Optional[str] = None,
        product_counter: Optional[int] = None,
        granule_name: Optional[str] = None,
        overlap_frames: Optional[List[int]] = None,
    ):
        super().__init__(start_time, end_time, radar_band)
        self.intersecting_start_time = start_time
        self.intersecting_end_time = end_time
        self.cycle = cycle
        self.track = track
        # Frames this RRSD strip overlaps. An RRSD is a time-window strip that can
        # span several track-frames, so this is a list. Populated with the frame(s)
        # being queried for; pure metadata -- never used for granule matching.
        self.overlap_frames = list(overlap_frames) if overlap_frames else []
        self.pass_direction = pass_direction
        self.radar_mode = radar_mode
        self.is_mixed_mode = is_mixed_mode
        self.composite_release_id = composite_release_id
        self.processing_type = processing_type
        self.product_accuracy = product_accuracy
        self.processing_location = processing_location
        self.product_counter = product_counter
        self.granule_name = granule_name
        self.download_url: Optional[str] = None
        # All intersecting granules from an incomplete search (best-first);
        # product_matches holds basenames, download_urls the parallel .h5 URLs.
        self.product_matches: List[str] = []
        self.download_urls: List[str] = []
        self._find_granule_attempted = False

    @classmethod
    def from_parsed(cls, parsed) -> "NisarRRSD":
        """Build a NisarRRSD from a ``ParsedRRSDGranule`` (see metadata.py)."""
        return cls(
            start_time=parsed.start_time,
            end_time=parsed.end_time,
            radar_band=parsed.radar_band,
            cycle=parsed.cycle,
            track=parsed.track,
            pass_direction=parsed.pass_direction,
            radar_mode=parsed.radar_mode,
            is_mixed_mode=parsed.is_mixed_mode,
            composite_release_id=parsed.composite_release_id,
            processing_type=parsed.processing_type,
            product_accuracy=parsed.product_accuracy,
            processing_location=parsed.processing_location,
            product_counter=parsed.product_counter,
            granule_name=parsed.granule_name if hasattr(parsed, "granule_name") else None,
        )

    @property
    def processed_state(self) -> str:
        """One of 'exact', 'unprocessed', 'unknown' (see lineage.py)."""
        if self.granule_name:
            return "exact"
        if self._find_granule_attempted:
            return "unprocessed"
        return "unknown"

    def set_latest_product_match(self, granule_basename: Optional[str]) -> None:
        """Alias for setting granule_name (mirrors NisarSingleProduct interface)."""
        self.granule_name = granule_basename

    def search_prefixes(self) -> List[str]:
        """Return the granule-name prefixes this RRSD would list S3 under.

        One prefix per candidate cycle offset (the on-disk cycle token may or may
        not carry the dumb-exception offset when the CRID is unknown). This is the
        single source of truth for both ``find_granule`` and any caller that wants
        to plan bucket listings *before* resolving (e.g. to pre-decide a bulk list
        vs. per-prefix fan-out).
        """
        proc = self.processing_type.value if self.processing_type else ProcessingType.PR.value
        prefixes = []
        for offset in naming.candidate_cycle_offsets(self.composite_release_id):
            named_cycle = (self.cycle or 0) + offset
            prefix_tokens = [
                naming.FIXED_HEAD,
                f"{self.radar_band.value}{self.product_type.level}",
                proc,
                self.product_type.code,
                f"{named_cycle:03d}",
                f"{(self.track or 0):03d}",
            ]
            if self.pass_direction:
                prefix_tokens.append(self.pass_direction)
            prefixes.append("_".join(prefix_tokens) + "_")
        return prefixes

    def iter_listing_targets(self, buckets: List[S3Bucket]):
        """Yield ``(bucket, date_path, partial_prefixes)`` for every listing needed.

        Enumerates exactly the S3 listings ``find_granule`` will perform. Because
        it is derivable without touching S3, a planner can call it across many
        products to know every intended (bucket, base, prefix) up front.
        """
        # An intersecting RRSD can begin shortly before the window (e.g. across
        # midnight) and is stored under its own start date, so search from the day
        # before the window start. Products are stored by start_time only, so we
        # search each day an RRSD could start and intersect; s3_search decides
        # whether dates matter per bucket.
        search_start = (self.intersecting_start_time - timedelta(days=1)
                        if self.intersecting_start_time is not None else None)
        prefixes = self.search_prefixes()
        for bucket in buckets:
            for dp in s3_search.date_paths_for_intersection_search(
                    bucket, search_start, self.intersecting_end_time):
                yield bucket, dp, prefixes

    def find_granule(self, buckets: List[S3Bucket]) -> List[str]:
        """Search buckets for RRSD granules whose time range intersects this window.

        Builds a search prefix from available identifiers (cycle, track, and
        pass_direction when known). Candidates are filtered by CRID and time
        intersection. Because an RRSD window (especially from incomplete inputs)
        can overlap several L0B granules, every passing match is a proper result:
        basenames are stored (best-first) in ``self.product_matches`` and the
        parallel ``.h5`` URLs in ``self.download_urls``.

        ``download_url`` and ``granule_name`` point at the best match (highest
        product counter) whenever at least one granule is found, so a non-empty
        ``product_matches`` always implies a usable ``download_url``.

        Returns ``self.product_matches`` (basenames of all intersecting
        granules, ordered best-first; empty if none found).
        """
        self._find_granule_attempted = True
        self.product_matches = []
        self.download_urls = []
        crid = self.composite_release_id or ""

        candidates = []  # (name, bucket)
        for bucket, dp, partial_prefixes in self.iter_listing_targets(buckets):
            found = s3_search.list_granules_from_bucket(
                bucket, self.product_type,
                partial_prefixes=partial_prefixes, date_path=dp)
            for name in found:
                candidates.append((name, bucket))

        # Group by name to collect all buckets where each product was found
        from collections import defaultdict
        products_by_name = defaultdict(list)  # name -> [(bucket, parsed), ...]

        for name, bucket in candidates:
            try:
                parsed = parse_rrsd_granule(name)
            except ValueError:
                continue
            if crid and parsed.composite_release_id != crid:
                continue
            # With no CRID the extra +5 search prefix can surface granules from
            # another cycle; reject any that don't parse back to our cycle (the
            # time-intersection filter below also guards this, but be explicit).
            if not crid and self.cycle is not None and parsed.cycle != self.cycle:
                continue
            if (self.intersecting_start_time is not None
                    and self.intersecting_end_time is not None
                    and (parsed.end_time < self.intersecting_start_time
                         or parsed.start_time > self.intersecting_end_time)):
                continue
            # Store all buckets where this product name was found
            products_by_name[name].append((bucket, parsed))

        if not products_by_name:
            return []

        # For each unique product, find the first bucket where the file exists
        matched = []  # (product_counter, name, url)
        for name, bucket_list in products_by_name.items():
            # All entries for the same name should have the same metadata
            _, first_parsed = bucket_list[0]
            date_path = s3_search.date_path_from_time(first_parsed.start_time)

            # Try each bucket where this product folder was found
            file_found = False
            for bucket, parsed in bucket_list:
                # Check if file exists in this bucket
                if s3_search.verify_granule_file_exists(
                        bucket, self.product_type, name, ".h5", date_path=date_path):
                    # File exists in this bucket - use it
                    url = s3_search.build_granule_file_url(
                        bucket, self.product_type, name, ".h5", date_path=date_path)
                    matched.append((parsed.product_counter, name, url))
                    file_found = True
                    break
                else:
                    logger.debug(
                        "Granule folder %s found in %s but .h5 file missing, trying other buckets",
                        name, bucket.bucket_name)

            if not file_found:
                logger.debug(
                    "Granule folder %s found in %d bucket(s) but file missing in all",
                    name, len(bucket_list))

        if not matched:
            return []

        # Best match first (highest product counter).
        matched.sort(key=lambda t: t[0], reverse=True)
        self.product_matches = [name for _, name, _ in matched]
        self.download_urls = [url for _, _, url in matched]
        self.granule_name = self.product_matches[0]
        self.download_url = self.download_urls[0]

        # Update RRSD attributes from the best match
        # This ensures radar_mode and other metadata are populated for RadarModeMetadata
        if self.granule_name:
            try:
                parsed = parse_rrsd_granule(self.granule_name)
                self.cycle = parsed.cycle
                self.track = parsed.track
                self.pass_direction = parsed.pass_direction
                self.radar_mode = parsed.radar_mode
                self.is_mixed_mode = parsed.is_mixed_mode
                self.composite_release_id = parsed.composite_release_id
                self.processing_type = parsed.processing_type
                self.product_accuracy = parsed.product_accuracy
                self.processing_location = parsed.processing_location
                self.product_counter = parsed.product_counter
            except ValueError as exc:
                logger.warning("Failed to parse best RRSD match %s: %s", self.granule_name, exc)

        return self.product_matches

    def _estimate_inputs(self, resolve: bool, buckets) -> List[LineageNode]:
        """RRSD is a root product: no predecessors."""
        return []
