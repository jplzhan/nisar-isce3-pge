"""Base class for single-frame NISAR products."""
from __future__ import annotations

import logging
from datetime import datetime
from typing import TYPE_CHECKING, List, Optional

from .. import naming, references, s3_search
from ..enums import NISARProductType, ProcessingType, RadarBand, S3Bucket
from ..lineage import LineageMixin
from ..metadata import NisarSingleProductMetadata, parse_single_granule

if TYPE_CHECKING:
    from ..ancillary_finder import AncillaryFiles

logger = logging.getLogger(__name__)


class NisarSingleProduct(LineageMixin):
    """A single-frame NISAR product identified by (cycle, track, frame, CRID).

    Subclasses set the class attribute ``product_type`` (a ``NISARProductType``).
    Level is taken from that product type.
    """

    product_type: NISARProductType = None  # set by subclasses

    def __init__(
        self,
        cycle: int,
        track: int,
        frame: int,
        composite_release_id: Optional[str] = None,
        radar_band: RadarBand = RadarBand.L,
        processing_type: ProcessingType = ProcessingType.PR,
        metadata: Optional[NisarSingleProductMetadata] = None,
    ):
        if self.product_type is None:
            raise TypeError(
                f"{type(self).__name__} must define a product_type class attribute")
        self.cycle = cycle
        self.track = track
        self.frame = frame
        self.composite_release_id = composite_release_id
        self.radar_band = radar_band
        self.processing_type = processing_type
        self.metadata = metadata

        # Derived reference values.
        self.track_frame_db_info = references.get_trackframe_row(track, frame)
        self.cycle_zero_time = references.cycle_zero_time(cycle)
        self.pass_direction = references.pass_direction(track, frame)
        self.estimated_start_time, self.estimated_end_time = (
            references.estimated_time_range(track, frame, cycle))

        # Populated after find_granule.
        self._latest_product_match: Optional[str] = None
        self._matched_bucket: Optional[S3Bucket] = None
        self._find_granule_attempted: bool = False
        self.download_url: Optional[str] = None
        # An incomplete search (identifiers only) can legitimately match several
        # granules that share the identifiers but differ in radar mode, time
        # range, etc. All such matches are kept here (best-first); the "best"
        # (highest product counter) also populates latest_product_match /
        # download_url for the common single-result case.
        self.product_matches: List[str] = []  # granule basenames, best-first
        self.download_urls: List[str] = []  # parallel .h5 URLs, best-first

        # Populated by ancillary_finder.find_ancillary_files_for_product()
        self.ancillary_files: Optional["AncillaryFiles"] = None

    @property
    def level(self) -> int:
        return self.product_type.level

    @property
    def latest_product_match(self) -> Optional[str]:
        return self._latest_product_match

    def set_latest_product_match(self, granule_basename: str) -> None:
        """Record a known granule basename as the latest match (no S3 call)."""
        self._latest_product_match = granule_basename

    @property
    def processed_state(self) -> str:
        """One of 'exact', 'unprocessed', 'unknown' (see lineage.py)."""
        if self._latest_product_match:
            return "exact"
        if self._find_granule_attempted:
            return "unprocessed"
        return "unknown"

    # ------------------------------------------------------------------ #
    # Accessors
    # ------------------------------------------------------------------ #
    def get_time_range(self) -> "tuple[datetime, datetime]":
        """Return the actual metadata time range if known, else the estimate."""
        if self.metadata is not None:
            return self.metadata.start_time, self.metadata.end_time
        return self.estimated_start_time, self.estimated_end_time

    def get_partial_granule_name(self, cycle_offset: Optional[int] = None) -> str:
        return naming.build_partial_granule_name(
            radar_band=self.radar_band,
            product_type=self.product_type,
            processing_type=self.processing_type,
            cycle=self.cycle,
            track=self.track,
            frame=self.frame,
            pass_direction=self.pass_direction,
            composite_release_id=self.composite_release_id,
            cycle_offset=cycle_offset,
        )

    # ------------------------------------------------------------------ #
    # Mutators
    # ------------------------------------------------------------------ #
    def find_granule(self, buckets: List[S3Bucket]) -> List[str]:
        """Search buckets for the real granule(s); record all matches.

        Keeps every granule sharing this product's identifiers and CRID -- an
        incomplete search can match several that differ only in radar mode, time
        range, etc. Matches are ordered best-first (highest product counter) in
        ``self.product_matches`` (basenames) and ``self.download_urls`` (URLs).
        The best match also populates ``latest_product_match``, ``download_url``
        and ``metadata`` for the common single-result case.

        Returns ``self.product_matches`` (all matching granule basenames,
        best-first; empty if none found).
        """
        self._find_granule_attempted = True
        self.product_matches = []
        self.download_urls = []
        # When the CRID is unknown the on-disk cycle token may carry the
        # dumb-exception offset or not, so search a prefix per candidate offset.
        prefixes = [self.get_partial_granule_name(cycle_offset=off)
                    for off in naming.candidate_cycle_offsets(self.composite_release_id)]

        # s3_search decides whether the bucket layout includes dates, so no
        # bucket-specific path logic is needed here. Products are stored by their
        # start_time, and since we're using estimated_start_time from orbit
        # references, we pass is_estimated=True to search adjacent days if near
        # a day boundary.
        candidates = []  # (name, bucket)
        for bucket in buckets:
            for dp in s3_search.date_paths_for_window(
                    bucket, self.estimated_start_time, is_estimated=True):
                found = s3_search.list_granules_from_bucket(
                    bucket, self.product_type,
                    partial_prefixes=prefixes, date_path=dp)
                for name in found:
                    candidates.append((name, bucket))

        # Keep matches for this product; order best-first (highest counter).
        # Filter by CRID when known; otherwise validate that the granule's
        # own parse (which applies its CRID's offset) recovers this true cycle,
        # rejecting coincidental hits from the extra +5 search prefix.
        # Group by name to collect all buckets where each product was found.
        from collections import defaultdict
        products_by_name = defaultdict(list)  # name -> [(bucket, parsed), ...]

        for name, bucket in candidates:
            try:
                parsed = parse_single_granule(name)
            except ValueError:
                continue
            if self.composite_release_id:
                if parsed.composite_release_id != self.composite_release_id:
                    continue
            elif parsed.cycle != self.cycle:
                continue
            # Store all buckets where this product name was found
            products_by_name[name].append((bucket, parsed))

        if not products_by_name:
            logger.info("No granule match for prefixes %s", prefixes)
            return []

        # For each unique product, find the first bucket where the file exists
        verified = []  # (product_counter, name, bucket, parsed)
        for name, bucket_list in products_by_name.items():
            # All entries for the same name should have the same metadata
            _, first_parsed = bucket_list[0]
            date_path = s3_search.date_path_from_time(first_parsed.metadata.start_time)

            # Try each bucket where this product folder was found
            file_found = False
            for bucket, parsed in bucket_list:
                # Check if file exists in this bucket
                if s3_search.verify_granule_file_exists(
                        bucket, self.product_type, name, ".h5", date_path=date_path):
                    # File exists in this bucket - use it
                    url = s3_search.build_granule_file_url(
                        bucket, self.product_type, name, ".h5", date_path=date_path)
                    self.product_matches.append(name)
                    self.download_urls.append(url)
                    verified.append((parsed.metadata.product_counter, name, bucket, parsed))
                    file_found = True
                    break
                else:
                    logger.debug(
                        "Granule folder %s found in %s but .h5 file missing, trying other buckets",
                        name, bucket.bucket_name)

            if not file_found:
                logger.debug(
                    "Granule folder %s found in %d bucket(s) but file missing in all",
                    name, len(bucket_list))

        if not verified:
            logger.info(
                "Granule folders found for prefixes %s but no files exist in any bucket",
                prefixes)
            return []

        # Sort by product counter (highest first)
        verified.sort(key=lambda t: t[0], reverse=True)

        best_counter, best_name, best_bucket, best_parsed = verified[0]
        self._latest_product_match = best_name
        self._matched_bucket = best_bucket
        self.metadata = best_parsed.metadata
        self.download_url = self.download_urls[0]
        return self.product_matches

    def _ensure_match(self, buckets: Optional[List[S3Bucket]]) -> None:
        if self._latest_product_match is None:
            if not buckets:
                raise ValueError(
                    "No latest_product_match set and no buckets provided to search.")
            self.find_granule(buckets)
        if self._latest_product_match is None:
            raise FileNotFoundError("Could not locate a matching granule.")

    def download_granule(self, dest_dir: str, buckets: Optional[List[S3Bucket]] = None,
                         force_redownload: bool = False) -> str:
        """Download the ``.h5`` product file for the matched granule."""
        self._ensure_match(buckets)
        return s3_search.download_url(self.download_url, dest_dir, force_redownload)

    def download_metadata(self, dest_dir: str, buckets: Optional[List[S3Bucket]] = None,
                          force_redownload: bool = False) -> str:
        """Download the ``.met.json`` file for the matched granule.

        For buckets with a metadata companion bucket, tries the primary bucket
        first, then falls back to the companion bucket if the file is not found.
        """
        from botocore.exceptions import ClientError

        self._ensure_match(buckets)
        if self.download_url is None:
            raise FileNotFoundError("No download URL available for metadata.")
        # ``download_url`` ends in ``<basename>.h5`` -> swap to ``.met.json``.
        meta_url = self.download_url[: -len(".h5")] + ".met.json"

        # Try downloading from the primary URL
        try:
            return s3_search.download_url(meta_url, dest_dir, force_redownload)
        except ClientError as exc:
            code = exc.response.get("Error", {}).get("Code", "")
            # If 404 and this bucket has a companion, try the companion bucket
            if code == "404" and self._matched_bucket:
                companion = self._matched_bucket.get_metadata_companion_bucket()
                if companion:
                    # Construct URL in companion bucket with same path structure
                    companion_url = meta_url.replace(
                        self._matched_bucket.bucket_name, companion.bucket_name)
                    logger.debug(
                        "Metadata not found at %s, trying companion bucket: %s",
                        meta_url, companion_url)
                    try:
                        return s3_search.download_url(companion_url, dest_dir, force_redownload)
                    except ClientError as companion_exc:
                        companion_code = companion_exc.response.get("Error", {}).get("Code", "")
                        if companion_code == "404":
                            logger.warning(
                                "Metadata not found in primary bucket %s or companion bucket %s",
                                self._matched_bucket.bucket_name, companion.bucket_name)
                        raise
            # Re-raise original exception if not 404 or no companion
            raise

    def get_metadata_url(self) -> Optional[str]:
        """Construct the correct URL for the .met.json file.

        Automatically uses the companion bucket if one exists for the matched
        bucket, otherwise uses the primary bucket.

        Returns None if no granule has been matched.
        """
        if self.download_url is None:
            return None

        # Check if there's a metadata companion bucket
        if self._matched_bucket:
            companion = self._matched_bucket.get_metadata_companion_bucket()
            if companion:
                # Use companion bucket
                meta_url = self.download_url[: -len(".h5")] + ".met.json"
                return meta_url.replace(self._matched_bucket.bucket_name, companion.bucket_name)

        # No companion, use primary bucket
        return self.download_url[: -len(".h5")] + ".met.json"

    def get_browse_url(self) -> Optional[str]:
        """Construct the correct URL for the .png browse image.

        Automatically uses the companion bucket if one exists for the matched
        bucket, otherwise uses the primary bucket.

        Returns None if no granule has been matched.
        """
        if self.download_url is None:
            return None

        # Check if there's a browse companion bucket
        if self._matched_bucket:
            companion = self._matched_bucket.get_browse_companion_bucket()
            if companion:
                # Use companion bucket
                browse_url = self.download_url[: -len(".h5")] + ".png"
                return browse_url.replace(self._matched_bucket.bucket_name, companion.bucket_name)

        # No companion, use primary bucket
        return self.download_url[: -len(".h5")] + ".png"

    # ------------------------------------------------------------------ #
    # Lineage
    # ------------------------------------------------------------------ #
    # trace_lineage is provided by LineageMixin; subclasses implement
    # _estimate_inputs to describe their direct predecessors.

    # ------------------------------------------------------------------ #
    # Runconfig Generation
    # ------------------------------------------------------------------ #
    def generate_runconfig(
        self,
        target_crid: Optional[str] = None,
        buckets: Optional[List[S3Bucket]] = None
    ) -> dict:
        """Generate processing runconfig for this product.

        Supports three modes:
        1. Exact Reproduction: If this product has an exact match, use its metadata.
        2. Partial Reproduction: If a different CRID match exists, reuse time fields.
        3. New Production: Generate from S3 parameter set templates.

        Args:
            target_crid: Optional CRID to use for processing. Defaults to:
                        - This product's CRID if available
                        - Latest CRID found across all buckets otherwise
            buckets: S3 buckets to search for reference products and templates.
                    If None, uses all available buckets.

        Returns:
            dict: Dictionary representing the runconfig YAML structure, ready to
                 be serialized to YAML.

        Raises:
            NotImplementedError: This is an abstract method that must be implemented
                               by subclasses.
        """
        raise NotImplementedError(
            f"{type(self).__name__} must implement generate_runconfig()"
        )

    def __repr__(self) -> str:
        return (f"{type(self).__name__}(cycle={self.cycle}, track={self.track}, "
                f"frame={self.frame}, crid={self.composite_release_id!r})")
