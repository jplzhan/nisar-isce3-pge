"""Factory: build a concrete product object from a full granule name or identifiers."""
from __future__ import annotations

from datetime import datetime
from typing import List, Optional, Union

from .enums import NISARProductType, ProcessingType, RadarBand
from .metadata import parse_insar_granule, parse_rrsd_granule, parse_single_granule
from .naming import split_granule_name
from .products import (
    NisarGCOV,
    NisarGOFF,
    NisarGSLC,
    NisarGUNW,
    NisarRIFG,
    NisarROFF,
    NisarRRSD,
    NisarRSLC,
    NisarRUNW,
    NisarSME2,
)
from .products.base import NisarSingleProduct
from .products.observation import NisarObservation
from .products.pairwise import NisarPairwiseProduct

_SINGLE_CLASSES = {
    NISARProductType.RSLC: NisarRSLC,
    NISARProductType.GSLC: NisarGSLC,
    NISARProductType.GCOV: NisarGCOV,
}

_INSAR_CLASSES = {
    NISARProductType.GUNW: NisarGUNW,
    NISARProductType.RUNW: NisarRUNW,
    NISARProductType.GOFF: NisarGOFF,
    NISARProductType.ROFF: NisarROFF,
    NISARProductType.RIFG: NisarRIFG,
}


def from_granule_name(
    name: str,
) -> Union[NisarSingleProduct, NisarPairwiseProduct, NisarObservation]:
    """Parse a full granule name and return the corresponding product object.

    The returned single-product object has its ``latest_product_match`` set to
    the input granule and its metadata populated from the name; an RRSD carries
    its ``granule_name``.
    """
    tokens = split_granule_name(name)
    product_type = NISARProductType.from_code(
        tokens[3] if len(tokens[3]) == 4 else f"{tokens[3]}_{tokens[4]}")

    if product_type is NISARProductType.RRSD:
        parsed = parse_rrsd_granule(name)
        product = NisarRRSD.from_parsed(parsed)
        product.granule_name = "_".join(tokens)
        return product

    if product_type in _INSAR_CLASSES:
        parsed = parse_insar_granule(name)
        cls = _INSAR_CLASSES[product_type]
        product = cls(
            cycles=[parsed.reference_cycle, parsed.secondary_cycle],
            track=parsed.track,
            frame=parsed.frame,
            composite_release_id=parsed.composite_release_id,
            radar_band=parsed.radar_band,
            processing_type=parsed.processing_type,
        )
        product.granule_name = "_".join(tokens)
        return product

    if product_type is NISARProductType.SME2:
        parsed = parse_single_granule(name)
        product = NisarSME2(
            cycles=[parsed.cycle],
            track=parsed.track,
            frame=parsed.frame,
            composite_release_id=parsed.composite_release_id,
            radar_band=parsed.radar_band,
            processing_type=parsed.processing_type,
        )
        product.granule_name = "_".join(tokens)
        return product

    if product_type in _SINGLE_CLASSES:
        parsed = parse_single_granule(name)
        cls = _SINGLE_CLASSES[product_type]
        product = cls(
            cycle=parsed.cycle,
            track=parsed.track,
            frame=parsed.frame,
            composite_release_id=parsed.composite_release_id,
            radar_band=parsed.radar_band,
            processing_type=parsed.processing_type,
            metadata=parsed.metadata,
        )
        product.set_latest_product_match("_".join(split_granule_name(name)))
        return product

    raise ValueError(f"No product class registered for type {product_type.code}")


def from_identifiers(
    product_type: NISARProductType,
    *,
    track: int,
    composite_release_id: Optional[str] = None,
    cycle: Optional[int] = None,
    cycles: Optional[List[int]] = None,
    frame: Optional[int] = None,
    start_time: Optional[datetime] = None,
    end_time: Optional[datetime] = None,
    radar_band: RadarBand = RadarBand.L,
    processing_type: ProcessingType = ProcessingType.PR,
) -> Union[NisarSingleProduct, NisarPairwiseProduct, NisarObservation]:
    """Build a product from its minimum unique identifiers (no granule name).

    The identifier-based counterpart to :func:`from_granule_name`: use it to
    construct a product to *search* for when only its identifiers are known.
    ``find_granule`` can then resolve it against S3.

    Required identifiers by family:
      * single (RSLC/GSLC/GCOV): ``cycle``, ``track``, ``frame``, CRID
      * INSAR (GUNW/RUNW/GOFF/ROFF/RIFG): ``cycles`` (2), ``track``, ``frame``, CRID
      * SME2: ``cycles`` (up to 3), ``track``, ``frame``, CRID
      * RRSD: ``start_time``, ``end_time``, ``track``, CRID (``cycle`` optional)
    """
    if product_type is NISARProductType.RRSD:
        if start_time is None or end_time is None:
            raise ValueError("RRSD requires start_time and end_time.")
        return NisarRRSD(
            start_time=start_time,
            end_time=end_time,
            radar_band=radar_band,
            cycle=cycle,
            track=track,
            composite_release_id=composite_release_id,
            processing_type=processing_type,
            overlap_frames=[frame] if frame is not None else None,
        )

    if product_type in _SINGLE_CLASSES:
        if cycle is None or frame is None:
            raise ValueError(f"{product_type.code} requires cycle and frame.")
        return _SINGLE_CLASSES[product_type](
            cycle=cycle,
            track=track,
            frame=frame,
            composite_release_id=composite_release_id,
            radar_band=radar_band,
            processing_type=processing_type,
        )

    if product_type in _INSAR_CLASSES:
        if not cycles or frame is None:
            raise ValueError(f"{product_type.code} requires cycles and frame.")
        return _INSAR_CLASSES[product_type](
            cycles=cycles,
            track=track,
            frame=frame,
            composite_release_id=composite_release_id,
            radar_band=radar_band,
            processing_type=processing_type,
        )

    if product_type is NISARProductType.SME2:
        if not cycles or frame is None:
            raise ValueError("SME2 requires cycles and frame.")
        return NisarSME2(
            cycles=cycles,
            track=track,
            frame=frame,
            composite_release_id=composite_release_id,
            radar_band=radar_band,
            processing_type=processing_type,
        )

    raise ValueError(f"No product class registered for type {product_type.code}")
